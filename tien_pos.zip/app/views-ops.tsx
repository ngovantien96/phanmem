"use client";
import React, { useEffect, useRef, useState } from "react";
import {
  Customer,
  Product,
  Purchase,
  Supplier,
  formatDate,
  money,
} from "./types";
import {
  Empty,
  Field,
  Kpi,
  Modal,
  MoneyInput,
  PanelTitle,
  SpinnerButton,
  Status,
} from "./ui";
import type { ViewProps } from "./views-main";

type QuickProductForm = {
  sku: string;
  name: string;
  category: string;
  brand: string;
  description: string;
  unit: string;
  warrantyMonths: string;
  tracking: "serial" | "quantity";
  cost: string;
  price: string;
  stock: string;
  min: string;
  serials: string;
};

type PurchaseDetailItem = {
  id: number;
  productId: number;
  productName: string;
  sku: string;
  unit: string;
  tracking: "serial" | "quantity";
  quantity: number;
  unitCost: number;
  discount: number;
  note: string;
  serialsJson: string;
};

type PurchaseDetail = {
  purchase: {
    supplierId?: string;
    supplierName?: string;
    subtotal: number;
    discount: number;
    otherCosts: number;
    tax: number;
    taxRate: number;
    total: number;
    note?: string;
    tags?: string;
    costsJson?: string;
    receivedAt?: string;
    returnedAmount?: number;
    returnReason?: string;
    returnedAt?: string | null;
    createdAt: string;
  };
  items: PurchaseDetailItem[];
  payments: Array<{
    id: string;
    amount: number;
    method: "cash" | "transfer";
  }>;
};

const freshQuickProduct = (name = ""): QuickProductForm => ({
  sku: "",
  name,
  category: "Laptop",
  brand: "",
  description: "",
  unit: "Chiếc",
  warrantyMonths: "12",
  tracking: "serial",
  cost: "",
  price: "",
  stock: "",
  min: "2",
  serials: "",
});

const toDateTimeLocalValue = (value?: string) => {
  const normalized = value
    ? /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(value)
      ? `${value.replace(" ", "T")}Z`
      : value
    : undefined;
  const date = normalized ? new Date(normalized) : new Date();
  const safeDate = Number.isNaN(date.getTime()) ? new Date() : date;
  return new Date(safeDate.getTime() - safeDate.getTimezoneOffset() * 60_000)
    .toISOString()
    .slice(0, 16);
};

export function Purchases(p: ViewProps) {
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [detailBusy, setDetailBusy] = useState<string | null>(null);
  const [details, setDetails] = useState<Record<string, PurchaseDetail>>({});
  const [busy, setBusy] = useState(false);
  const [supplierId, setSupplierId] = useState("");
  const [supplierQuery, setSupplierQuery] = useState("");
  const [supplierResultsOpen, setSupplierResultsOpen] = useState(false);
  const supplierPickerRef = useRef<HTMLDivElement>(null);
  const [supplierFormOpen, setSupplierFormOpen] = useState(false);
  const [dueDate, setDueDate] = useState("");
  const [receivedAt, setReceivedAt] = useState("");
  const [note, setNote] = useState("");
  const [tags, setTags] = useState("");
  const [productQuery, setProductQuery] = useState("");
  const [productResultsOpen, setProductResultsOpen] = useState(false);
  const productPickerRef = useRef<HTMLElement>(null);
  const [quickProductForm, setQuickProductForm] =
    useState<QuickProductForm | null>(null);
  const [quickProductBusy, setQuickProductBusy] = useState(false);
  const [quickOptionType, setQuickOptionType] = useState<
    "category" | "brand" | null
  >(null);
  const [quickOptionName, setQuickOptionName] = useState("");
  const [quickOptionBusy, setQuickOptionBusy] = useState(false);
  const [returningPurchase, setReturningPurchase] = useState<Purchase | null>(
    null,
  );
  const [purchaseReturnReason, setPurchaseReturnReason] = useState("");
  const [purchaseReturnBusy, setPurchaseReturnBusy] = useState(false);
  const [localProductOptions, setLocalProductOptions] = useState(
    p.data.productOptions,
  );
  const [splitLines, setSplitLines] = useState(false);
  const [multiSelect, setMultiSelect] = useState(false);
  const [selectedProductIds, setSelectedProductIds] = useState<number[]>([]);
  const [taxRate, setTaxRate] = useState(0);
  const [costs, setCosts] = useState<
    Array<{ id: string; name: string; amount: number }>
  >([]);
  const [payments, setPayments] = useState<
    Array<{ id: string; amount: number; method: "cash" | "transfer" }>
  >([]);
  const [items, setItems] = useState<
    Array<{
      rowId: string;
      productId: number;
      sku: string;
      name: string;
      unit: string;
      tracking: "serial" | "quantity";
      quantity: number;
      cost: number;
      discount: number;
      note: string;
      serials: string[];
    }>
  >([]);
  const addProduct = (product: Product) => {
    setItems((current) => {
      const existing = !splitLines
        ? current.find((x) => x.productId === product.id)
        : undefined;
      if (existing)
        return current.map((x) =>
          x.rowId === existing.rowId
            ? { ...x, quantity: x.quantity + 1 }
            : x,
        );
      return [
        ...current,
        {
          rowId: crypto.randomUUID(),
          productId: product.id,
          sku: product.sku,
          name: product.name,
          unit: product.unit || "Chiếc",
          tracking: product.tracking,
          quantity: 1,
          cost: product.cost,
          discount: 0,
          note: "",
          serials: [],
        },
      ];
    });
    if (!multiSelect) {
      setProductQuery("");
      setProductResultsOpen(false);
    }
  };
  const openQuickProductForm = () => {
    setProductResultsOpen(false);
    setQuickProductForm(freshQuickProduct(productQuery.trim()));
  };
  const quickOptionNames = (type: "category" | "brand") => {
    const current = quickProductForm?.[type]
      ? [quickProductForm[type]]
      : [];
    return [
      ...new Set(
        [
          ...p.data.productOptions
            .filter((option) => option.type === type)
            .map((option) => option.name),
          ...localProductOptions
            .filter((option) => option.type === type)
            .map((option) => option.name),
          ...p.data.products.map((product) => product[type]),
          ...current,
        ]
          .map((name) => name.trim())
          .filter(Boolean),
      ),
    ].sort((a, b) =>
      a.localeCompare(b, "vi", { sensitivity: "base" }),
    );
  };
  const saveQuickOption = async () => {
    if (!quickOptionType || !quickOptionName.trim() || !quickProductForm)
      return;
    setQuickOptionBusy(true);
    try {
      const result = await p.api(
        { type: quickOptionType, name: quickOptionName },
        "/api/product-options",
      );
      const option = result.option as {
        id: number;
        type: "category" | "brand";
        name: string;
      };
      setLocalProductOptions((current) =>
        current.some(
          (item) =>
            item.type === option.type &&
            item.name.localeCompare(option.name, "vi", {
              sensitivity: "base",
            }) === 0,
        )
          ? current
          : [...current, option],
      );
      setQuickProductForm({
        ...quickProductForm,
        [quickOptionType]: option.name,
      });
      setQuickOptionType(null);
      setQuickOptionName("");
      p.notify(
        result.created
          ? `Đã thêm ${quickOptionType === "category" ? "nhóm hàng" : "thương hiệu"}.`
          : "Tùy chọn này đã có trong danh sách.",
      );
    } catch (error) {
      p.notify(
        error instanceof Error ? error.message : "Không thể thêm tùy chọn.",
      );
    } finally {
      setQuickOptionBusy(false);
    }
  };
  const saveQuickProduct = async () => {
    if (!quickProductForm) return;
    setQuickProductBusy(true);
    try {
      const result = await p.api(
        {
          ...quickProductForm,
          cost: Number(quickProductForm.cost),
          price: Number(quickProductForm.price),
          stock: Number(quickProductForm.stock),
          min: Number(quickProductForm.min),
          warrantyMonths: Number(quickProductForm.warrantyMonths),
          serials: quickProductForm.serials.split(/[,\n]/),
        },
        "/api/products",
      );
      const created = result.product as Product;
      setQuickProductForm(null);
      setProductQuery("");
      addProduct({ ...created, active: true });
      p.notify(`Đã thêm ${created.name} vào phiếu nhập hiện tại.`);
      await p.reload();
    } catch (error) {
      p.notify(
        error instanceof Error ? error.message : "Không thể thêm sản phẩm.",
      );
    } finally {
      setQuickProductBusy(false);
    }
  };
  const updateItem = (
    rowId: string,
    patch: Partial<(typeof items)[number]>,
  ) =>
    setItems((current) =>
      current.map((item) =>
        item.rowId === rowId ? { ...item, ...patch } : item,
      ),
    );
  const matchingProducts = p.data.products
    .filter((product) =>
      `${product.name} ${product.sku} ${product.brand}`
        .toLowerCase()
        .includes(productQuery.trim().toLowerCase()),
    )
    .sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime() ||
        b.id - a.id,
    );
  useEffect(() => {
    const closeSearchResults = (event: PointerEvent) => {
      if (!productPickerRef.current?.contains(event.target as Node)) {
        setProductResultsOpen(false);
      }
      if (!supplierPickerRef.current?.contains(event.target as Node)) {
        setSupplierResultsOpen(false);
      }
    };
    document.addEventListener("pointerdown", closeSearchResults);
    return () => document.removeEventListener("pointerdown", closeSearchResults);
  }, []);
  const subtotal = items.reduce((s, x) => s + x.quantity * x.cost, 0);
  const discount = items.reduce(
    (s, x) => s + Math.min(x.quantity * x.cost, Math.max(0, x.discount)),
    0,
  );
  const otherCosts = costs.reduce((s, x) => s + Math.max(0, x.amount), 0);
  const beforeTax = Math.max(0, subtotal - discount + otherCosts);
  const tax = Math.round((beforeTax * Math.min(100, Math.max(0, taxRate))) / 100);
  const total = beforeTax + tax;
  const paid = payments.reduce((s, x) => s + Math.max(0, x.amount), 0);
  const quantity = items.reduce((s, x) => s + x.quantity, 0);
  const serialsValid = items.every(
    (item) => item.tracking !== "serial" || item.serials.length === item.quantity,
  );
  const selectedSupplier = p.data.suppliers.find((x) => x.id === supplierId);
  const normalizedSupplierQuery = supplierQuery.trim().toLowerCase();
  const matchingSuppliers = p.data.suppliers
    .filter((x) =>
      `${x.name} ${x.phone} ${x.code}`
        .toLowerCase()
        .includes(normalizedSupplierQuery),
    )
    .slice(0, 8);
  const selectSupplier = (supplier: Supplier) => {
    setSupplierId(supplier.id);
    setSupplierQuery(supplier.name);
    setSupplierResultsOpen(false);
  };
  const resetPurchaseForm = () => {
    setEditingId(null);
    setSupplierId("");
    setSupplierQuery("");
    setSupplierResultsOpen(false);
    setDueDate("");
    setReceivedAt(toDateTimeLocalValue());
    setNote("");
    setTags("");
    setProductQuery("");
    setProductResultsOpen(false);
    setQuickProductForm(null);
    setQuickOptionType(null);
    setQuickOptionName("");
    setSplitLines(false);
    setMultiSelect(false);
    setSelectedProductIds([]);
    setTaxRate(0);
    setCosts([]);
    setPayments([]);
    setItems([]);
  };
  const loadDetail = async (id: string) => {
    if (details[id]) return details[id];
    setDetailBusy(id);
    try {
      const response = await fetch(`/api/purchases?id=${encodeURIComponent(id)}`, { cache: "no-store" });
      const result = (await response.json()) as PurchaseDetail & {
        error?: string;
      };
      if (!response.ok) throw new Error(result.error || "Không thể tải chi tiết phiếu nhập");
      setDetails((current) => ({ ...current, [id]: result }));
      return result;
    } finally {
      setDetailBusy(null);
    }
  };
  const toggleDetail = async (id: string) => {
    if (expandedId === id) return setExpandedId(null);
    setExpandedId(id);
    try { await loadDetail(id); } catch (error) {
      setExpandedId(null);
      p.notify(error instanceof Error ? error.message : "Không thể tải chi tiết phiếu nhập");
    }
  };
  const editPurchase = async (id: string) => {
    const summary = p.data.purchases.find((purchase) => purchase.id === id);
    if (summary?.status === "purchase_returned") {
      p.notify("Phiếu đã hoàn trả nên không thể sửa.");
      return;
    }
    try {
      const result = await loadDetail(id);
      const purchase = result.purchase;
      setEditingId(id);
      setSupplierId(purchase.supplierId || "");
      setSupplierQuery(purchase.supplierName || "");
      setReceivedAt(
        toDateTimeLocalValue(purchase.receivedAt || purchase.createdAt),
      );
      setNote(purchase.note || "");
      setTags(purchase.tags || "");
      setTaxRate(Number(purchase.taxRate) || 0);
      const parsedCosts = JSON.parse(purchase.costsJson || "[]") as Array<{
        name: string;
        amount: number;
      }>;
      setCosts(parsedCosts.map((x) => ({ ...x, id: crypto.randomUUID() })));
      setPayments((result.payments || []).map((x) => ({ id: crypto.randomUUID(), amount: Number(x.amount), method: x.method === "transfer" ? "transfer" : "cash" })));
      setItems((result.items || []).map((x) => ({
        rowId: crypto.randomUUID(), productId: Number(x.productId), sku: x.sku || "", name: x.productName,
        unit: x.unit || "Chiếc", tracking: x.tracking, quantity: Number(x.quantity), cost: Number(x.unitCost),
        discount: Number(x.discount), note: x.note || "", serials: JSON.parse(x.serialsJson || "[]"),
      })));
      setOpen(true);
    } catch (error) {
      p.notify(error instanceof Error ? error.message : "Không thể mở phiếu nhập");
    }
  };
  const save = async () => {
    setBusy(true);
    try {
      const supplier = p.data.suppliers.find((x) => x.id === supplierId);
      const result = await p.api({
        action: editingId ? "purchase-update" : "purchase",
        purchaseId: editingId,
        supplierId,
        supplierName: supplier?.name || "Nhà cung cấp lẻ",
        payments,
        costs,
        taxRate,
        receivedAt: new Date(receivedAt).toISOString(),
        dueDate,
        note,
        tags,
        items,
      });
      setOpen(false);
      resetPurchaseForm();
      p.notify(editingId ? `Đã cập nhật phiếu nhập ${result.code}.` : `Đã hoàn tất phiếu nhập ${result.code}. Tồn kho và công nợ đã cập nhật.`);
      setDetails({});
      await p.reload();
    } catch (error) {
      p.notify(error instanceof Error ? error.message : "Không thể lưu phiếu nhập");
    } finally {
      setBusy(false);
    }
  };
  const openPurchaseReturn = (purchase: Purchase) => {
    setReturningPurchase(purchase);
    setPurchaseReturnReason("Hoàn trả hàng cho nhà cung cấp");
  };
  const returnPurchase = async () => {
    if (!returningPurchase || !purchaseReturnReason.trim()) {
      p.notify("Vui lòng nhập lý do hoàn trả phiếu nhập.");
      return;
    }
    setPurchaseReturnBusy(true);
    try {
      const result = await p.api({
        action: "purchase-return",
        purchaseId: returningPurchase.id,
        reason: purchaseReturnReason,
      });
      const refundedAmount = Number(result.refundedAmount) || 0;
      p.notify(
        refundedAmount > 0
          ? `Đã hoàn trả ${returningPurchase.code}, trừ hàng khỏi kho và tạo yêu cầu thu lại ${money(refundedAmount)} trong Sổ thu chi.`
          : `Đã hoàn trả ${returningPurchase.code} và trừ hàng khỏi kho.`,
      );
      setReturningPurchase(null);
      setPurchaseReturnReason("");
      setExpandedId(null);
      setDetails({});
      await p.reload();
    } catch (error) {
      p.notify(
        error instanceof Error
          ? error.message
          : "Không thể hoàn trả phiếu nhập.",
      );
    } finally {
      setPurchaseReturnBusy(false);
    }
  };
  return (
    <>
      <div className="three">
        <Kpi
          icon="⇩"
          label="Phiếu nhập"
          value={String(p.data.purchases.length)}
        />
        <Kpi
          icon="₫"
          label="Tổng tiền nhập"
          value={money(
            p.data.purchases
              .filter((purchase) => purchase.status !== "purchase_returned")
              .reduce((sum, purchase) => sum + purchase.total, 0),
          )}
          tone="purple"
        />
        <Kpi
          icon="!"
          label="Còn nợ NCC"
          value={money(
            p.data.debts
              .filter(
                (x) => x.partnerType === "supplier" && x.status !== "paid",
              )
              .reduce((s, x) => s + x.total - x.paid, 0),
          )}
          tone="orange"
        />
      </div>
      <article className="panel page">
        <PanelTitle
          text="Nhập hàng"
          sub="Tạo phiếu nhập, cập nhật giá vốn, tồn kho và serial"
          action="＋ Tạo phiếu nhập"
          onAction={() => {
            resetPurchaseForm();
            setOpen(true);
          }}
        />
        <div className="table">
          <table>
            <thead>
              <tr>
                <th aria-label="Mở chi tiết" />
                <th>Mã phiếu</th>
                <th>Nhà cung cấp</th>
                <th>Tổng tiền</th>
                <th>Đã trả</th>
                <th>Ngày nhập</th>
                <th>Trạng thái</th>
              </tr>
            </thead>
            <tbody>
              {p.data.purchases.length ? (
                p.data.purchases.map((x) => {
                  const expanded = expandedId === x.id;
                  const detail = details[x.id];
                  return <React.Fragment key={x.id}>
                  <tr className={`purchase-main-row${expanded ? " expanded" : ""}${x.status === "purchase_returned" ? " returned" : ""}`}>
                    <td><button type="button" className={`purchase-chevron${expanded ? " open" : ""}`} onClick={() => void toggleDetail(x.id)} aria-label={expanded ? `Thu gọn ${x.code}` : `Mở chi tiết ${x.code}`} aria-expanded={expanded}>⌄</button></td>
                    <td><button type="button" className="purchase-code-link" onClick={() => void editPurchase(x.id)} title={x.status === "purchase_returned" ? "Phiếu đã hoàn trả, chỉ có thể xem chi tiết" : "Sửa phiếu nhập"}>{x.code}</button></td>
                    <td>{x.supplierName}</td>
                    <td>{money(x.total)}</td>
                    <td>{money(x.paid)}</td>
                    <td>{formatDate(x.receivedAt || x.createdAt)}</td>
                    <td>
                      <Status value={x.status} />
                    </td>
                  </tr>
                  {expanded && <tr className="purchase-detail-row"><td colSpan={7}>
                    {detailBusy === x.id && !detail ? <div className="purchase-detail-loading">Đang tải chi tiết phiếu…</div> : detail ? <div className="purchase-inline-detail">
                      <div className="purchase-detail-meta">
                        <section><h4>Thông tin đơn nhập hàng</h4><p><span>Mã đơn</span><b>{x.code}</b></p><p><span>Ngày nhập</span><b>{formatDate(detail.purchase.receivedAt || x.receivedAt || x.createdAt)}</b></p><p><span>Ngày tạo đơn</span><b>{formatDate(x.createdAt)}</b></p><p><span>Nhà cung cấp</span><b>{x.supplierName}</b></p></section>
                        <section><h4>{x.status === "purchase_returned" ? "Thông tin hoàn trả" : "Ghi chú"}</h4>{x.status === "purchase_returned" ? <><p><span>Hoàn lúc</span><b>{formatDate(detail.purchase.returnedAt || x.returnedAt || "")}</b></p><p><span>Tiền thu lại</span><b>{money(Number(detail.purchase.returnedAmount) || x.returnedAmount)}</b></p><p><span>Lý do</span><b>{detail.purchase.returnReason || x.returnReason || "Không có lý do"}</b></p></> : <><p>{detail.purchase.note || "Không có ghi chú"}</p>{detail.purchase.tags && <><h4>Tags</h4><p>{detail.purchase.tags}</p></>}</>}</section>
                        <div className="purchase-detail-actions"><button type="button" className="primary" onClick={() => window.print()}>In đơn</button>{x.status !== "purchase_returned" && <><button type="button" onClick={() => void editPurchase(x.id)}>Sửa đơn</button><button type="button" className="purchase-return-button" onClick={() => openPurchaseReturn(x)}>Hoàn trả phiếu</button></>}</div>
                      </div>
                      <div className="purchase-detail-products"><table><thead><tr><th>STT</th><th>Mã SKU</th><th>Tên sản phẩm</th><th>Số lượng</th><th>Đơn giá</th><th>Chiết khấu</th><th>Thành tiền</th></tr></thead><tbody>
                        {detail.items.map((item, index) => <tr key={item.id}><td>{index + 1}</td><td className="link">{item.sku}</td><td>{item.productName}</td><td>{item.quantity}</td><td>{money(item.unitCost)}</td><td>{money(item.discount)}</td><td><b>{money(item.quantity * item.unitCost - item.discount)}</b></td></tr>)}
                      </tbody></table><div className="purchase-detail-total"><p><span>Số lượng</span><b>{detail.items.reduce((sum, item) => sum + item.quantity, 0)}</b></p><p><span>Tổng tiền</span><b>{money(detail.purchase.subtotal)}</b></p><p><span>Chiết khấu</span><b>{money(detail.purchase.discount)}</b></p><p><span>Chi phí nhập hàng</span><b>{money(detail.purchase.otherCosts)}</b></p><p><span>Thuế</span><b>{money(detail.purchase.tax)}</b></p><p className="payable"><span>Tiền cần trả</span><b>{money(detail.purchase.total)}</b></p></div></div>
                      <button type="button" className="purchase-collapse" onClick={() => setExpandedId(null)}>⌃ Thu gọn</button>
                    </div> : null}
                  </td></tr>}
                  </React.Fragment>;
                })
              ) : (
                <tr>
                    <td colSpan={7}>
                    <Empty text="Chưa có phiếu nhập" />
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </article>
      {open && (
        <Modal
          title={editingId ? `Sửa phiếu nhập ${p.data.purchases.find((x) => x.id === editingId)?.code || ""}` : "Tạo phiếu nhập hàng"}
          onClose={() => {
            setOpen(false);
            resetPurchaseForm();
          }}
          wide
          className="purchase-modal"
        >
          <div className="purchase-workspace">
          <section className="purchase-supplier-card purchase-supplier-compact">
            <div className="purchase-supplier-heading">
              <div>
                <h3>Thông tin nhà cung cấp</h3>
                <p>Tìm theo tên, số điện thoại hoặc mã nhà cung cấp</p>
              </div>
              <button type="button" onClick={() => setSupplierFormOpen(true)}>
                ＋ Tạo nhà cung cấp mới
              </button>
            </div>
            <div className="supplier-picker" ref={supplierPickerRef}>
              <label className="supplier-search-box">
                <span aria-hidden="true">⌕</span>
                <input
                  value={supplierQuery}
                  onFocus={() => {
                    setProductResultsOpen(false);
                    setSupplierResultsOpen(true);
                  }}
                  onChange={(e) => {
                    setSupplierQuery(e.target.value);
                    setSupplierId("");
                    setProductResultsOpen(false);
                    setSupplierResultsOpen(true);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Escape") setSupplierResultsOpen(false);
                    if (e.key === "Enter" && matchingSuppliers.length) {
                      e.preventDefault();
                      selectSupplier(matchingSuppliers[0]);
                    }
                  }}
                  placeholder="Tìm theo tên, SĐT, mã nhà cung cấp..."
                  aria-label="Tìm nhà cung cấp"
                  aria-expanded={supplierResultsOpen && !selectedSupplier}
                  aria-controls="purchase-supplier-results"
                  autoComplete="off"
                />
                {supplierQuery && (
                  <button
                    type="button"
                    aria-label="Xóa nhà cung cấp đã chọn"
                    onClick={() => {
                      setSupplierId("");
                      setSupplierQuery("");
                      setSupplierResultsOpen(false);
                    }}
                  >
                    ×
                  </button>
                )}
              </label>
              {supplierResultsOpen && !selectedSupplier && (
                <div className="supplier-results" id="purchase-supplier-results">
                  {matchingSuppliers.length ? (
                    matchingSuppliers.map((supplier) => (
                      <button
                        type="button"
                        key={supplier.id}
                        onClick={() => selectSupplier(supplier)}
                      >
                        <span>
                          <b>{supplier.name}</b>
                          <small>
                            {supplier.code} · {supplier.phone || "Chưa có SĐT"}
                          </small>
                        </span>
                        <em>Chọn</em>
                      </button>
                    ))
                  ) : (
                    <div className="supplier-no-result">
                      <span>Không tìm thấy nhà cung cấp phù hợp</span>
                      <button
                        type="button"
                        onClick={() => setSupplierFormOpen(true)}
                      >
                        ＋ Tạo nhà cung cấp mới
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
            {selectedSupplier ? (
              <div className="selected-supplier-info">
                <i>{selectedSupplier.name.slice(0, 1).toUpperCase()}</i>
                <div>
                  <b>{selectedSupplier.name}</b>
                  <span>
                    {selectedSupplier.code} · {selectedSupplier.phone || "Chưa có SĐT"}
                  </span>
                  <small>
                    {selectedSupplier.address || "Chưa có địa chỉ"}
                    {selectedSupplier.email ? ` · ${selectedSupplier.email}` : ""}
                  </small>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSupplierId("");
                    setSupplierQuery("");
                    setSupplierResultsOpen(false);
                  }}
                >
                  Đổi nhà cung cấp
                </button>
              </div>
            ) : (
              <div className="supplier-empty-state">
                <i aria-hidden="true">▱</i>
                <span>Chưa có thông tin nhà cung cấp</span>
              </div>
            )}
          </section>
          <section className="purchase-products-card" ref={productPickerRef}>
            <div className="purchase-product-heading">
              <h3>Thông tin sản phẩm</h3>
              <label>
                <input
                  type="checkbox"
                  checked={splitLines}
                  onChange={(e) => setSplitLines(e.target.checked)}
                />
                Tách dòng
              </label>
            </div>
            <div className="purchase-product-toolbar">
              <label className="purchase-product-search">
                <span aria-hidden="true">⌕</span>
                <input
                  value={productQuery}
                  onFocus={() => {
                    setSupplierResultsOpen(false);
                    setProductResultsOpen(true);
                  }}
                  onChange={(e) => {
                    setProductQuery(e.target.value);
                    setSupplierResultsOpen(false);
                    setProductResultsOpen(true);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Escape") setProductResultsOpen(false);
                    if (e.key === "Enter" && matchingProducts.length && !multiSelect) {
                      e.preventDefault();
                      addProduct(matchingProducts[0]);
                    }
                  }}
                  placeholder="Tìm theo tên, mã SKU hoặc quét mã Barcode… (F3)"
                  aria-label="Tìm sản phẩm nhập"
                  aria-expanded={productResultsOpen}
                  aria-controls="purchase-product-results"
                  autoComplete="off"
                />
                {productQuery && (
                  <button type="button" onClick={() => setProductQuery("")} aria-label="Xóa tìm kiếm">
                    ×
                  </button>
                )}
              </label>
              <button
                type="button"
                className={multiSelect ? "active" : ""}
                onClick={() => {
                  setMultiSelect((value) => !value);
                  setSelectedProductIds([]);
                }}
              >
                Chọn nhiều
              </button>
              <select aria-label="Loại giá hiển thị" defaultValue="cost">
                <option value="cost">Giá nhập</option>
              </select>
            </div>
            {productResultsOpen && (
              <div className="purchase-product-results" id="purchase-product-results">
                <button
                  type="button"
                  className="product-search-create"
                  onClick={openQuickProductForm}
                >
                  <i aria-hidden="true">＋</i>
                  <span>
                    <b>Thêm mới sản phẩm</b>
                    <small>
                      {productQuery.trim()
                        ? `Tạo sản phẩm “${productQuery.trim()}”`
                        : "Tạo sản phẩm nếu chưa có trong danh sách"}
                    </small>
                  </span>
                </button>
                {matchingProducts.length ? (
                  matchingProducts.map((product) => (
                    <button
                      type="button"
                      className="product-search-row"
                      key={product.id}
                      onClick={() => {
                        if (multiSelect) {
                          setSelectedProductIds((current) =>
                            current.includes(product.id)
                              ? current.filter((id) => id !== product.id)
                              : [...current, product.id],
                          );
                        } else addProduct(product);
                      }}
                    >
                      {multiSelect && (
                        <input
                          type="checkbox"
                          tabIndex={-1}
                          readOnly
                          checked={selectedProductIds.includes(product.id)}
                        />
                      )}
                      <i className="product-search-thumb" aria-hidden="true">▧</i>
                      <span className="product-search-main">
                        <b>{product.name}</b>
                        <small>
                          {product.sku} · {product.unit || "Chiếc"}
                          {product.brand ? ` · ${product.brand}` : ""}
                        </small>
                      </span>
                      <span className="product-search-value">
                        <strong>{money(product.cost)}</strong>
                        <small>
                          Tồn: {product.stock} | Có thể bán: {Math.max(0, product.stock)}
                        </small>
                      </span>
                    </button>
                  ))
                ) : (
                  <div className="purchase-product-empty">
                    <span>Không tìm thấy sản phẩm phù hợp</span>
                  </div>
                )}
                {multiSelect && matchingProducts.length > 0 && (
                  <div className="purchase-multi-actions">
                    <span>Đã chọn {selectedProductIds.length} sản phẩm</span>
                    <button
                      type="button"
                      disabled={!selectedProductIds.length}
                      onClick={() => {
                        selectedProductIds.forEach((id) => {
                          const product = p.data.products.find((x) => x.id === id);
                          if (product) addProduct(product);
                        });
                        setSelectedProductIds([]);
                        setMultiSelect(false);
                        setProductResultsOpen(false);
                      }}
                    >
                      Thêm vào phiếu
                    </button>
                  </div>
                )}
              </div>
            )}
            <div className="purchase-lines-wrap">
            <table className="purchase-lines-table">
              <thead>
                <tr>
                  <th>STT</th>
                  <th>Ảnh</th>
                  <th>Tên sản phẩm</th>
                  <th>Đơn vị</th>
                  <th>SL nhập</th>
                  <th>Đơn giá</th>
                  <th>Chiết khấu</th>
                  <th>Thành tiền</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {items.map((x, i) => (
                  <tr key={x.rowId}>
                    <td>{i + 1}</td>
                    <td><span className="purchase-image-placeholder">▧</span></td>
                    <td className="purchase-product-cell">
                      <b>{x.name}</b>
                      <small>{x.sku}</small>
                      <input
                        value={x.note}
                        onChange={(e) => updateItem(x.rowId, { note: e.target.value })}
                        placeholder="Ghi chú sản phẩm"
                      />
                      {x.tracking === "serial" && (
                        <label className={x.serials.length === x.quantity ? "serial-ok" : "serial-missing"}>
                          Serial {x.serials.length}/{x.quantity}
                          <textarea
                            value={x.serials.join("\n")}
                            onChange={(e) =>
                              updateItem(x.rowId, {
                                serials: e.target.value
                                  .split(/[,\n]/)
                                  .map((value) => value.trim())
                                  .filter(Boolean),
                              })
                            }
                            placeholder="Mỗi serial một dòng"
                          />
                        </label>
                      )}
                    </td>
                    <td><select value={x.unit} onChange={(e) => updateItem(x.rowId, { unit: e.target.value })}><option>{x.unit}</option></select></td>
                    <td>
                      <div className="purchase-qty-stepper">
                        <button type="button" onClick={() => updateItem(x.rowId, { quantity: Math.max(1, x.quantity - 1) })}>−</button>
                        <input type="number" min="1" value={x.quantity} onChange={(e) => updateItem(x.rowId, { quantity: Math.max(1, Math.trunc(Number(e.target.value) || 1)) })} />
                        <button type="button" onClick={() => updateItem(x.rowId, { quantity: x.quantity + 1 })}>＋</button>
                      </div>
                    </td>
                    <td><MoneyInput className="purchase-money-input" value={x.cost} ariaLabel={`Đơn giá nhập ${x.name}`} onValueChange={(cost) => updateItem(x.rowId, { cost })} /></td>
                    <td><input className="purchase-money-input" type="number" min="0" max={x.quantity * x.cost} value={x.discount} onChange={(e) => updateItem(x.rowId, { discount: Math.max(0, Number(e.target.value)) })} /></td>
                    <td className="purchase-line-total">{money(Math.max(0, x.quantity * x.cost - x.discount))}</td>
                    <td>
                      <button
                        className="danger-link"
                        type="button"
                        aria-label={`Xóa ${x.name}`}
                        onClick={() =>
                          setItems((v) => v.filter((item) => item.rowId !== x.rowId))
                        }
                      >
                        ×
                      </button>
                    </td>
                  </tr>
                ))}
                {!items.length && (
                  <tr><td colSpan={9}><div className="purchase-lines-empty">Tìm và chọn sản phẩm để thêm vào phiếu nhập</div></td></tr>
                )}
              </tbody>
            </table>
            </div>
          </section>
          <div className="purchase-footer-grid">
            <div className="purchase-notes-card">
              <label>
                Ghi chú đơn
                <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="VD: Hàng tặng gói riêng" />
              </label>
              <label>
                Tags
                <input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="Nhập ký tự và ấn Enter" />
              </label>
              <label>
                Ngày giờ nhập hàng
                <input
                  type="datetime-local"
                  value={receivedAt}
                  onChange={(e) => setReceivedAt(e.target.value)}
                />
              </label>
              <label>
                Hạn thanh toán
                <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
              </label>
            </div>
            <div className="purchase-summary-card">
              <p><span>Số lượng</span><b>{quantity}</b></p>
              <p><span>Tổng tiền</span><b>{money(subtotal)}</b></p>
              <p className="purchase-discount"><span>Chiết khấu</span><b>− {money(discount)}</b></p>
              <h4>Chi phí nhập hàng</h4>
              {costs.map((cost) => (
                <div className="purchase-cost-row" key={cost.id}>
                  <input value={cost.name} onChange={(e) => setCosts((current) => current.map((x) => x.id === cost.id ? { ...x, name: e.target.value } : x))} placeholder="Tên chi phí" />
                  <input type="number" min="0" value={cost.amount} onChange={(e) => setCosts((current) => current.map((x) => x.id === cost.id ? { ...x, amount: Math.max(0, Number(e.target.value)) } : x))} />
                  <button type="button" onClick={() => setCosts((current) => current.filter((x) => x.id !== cost.id))}>×</button>
                </div>
              ))}
              <button className="purchase-add-link" type="button" onClick={() => setCosts((current) => [...current, { id: crypto.randomUUID(), name: "Vận chuyển", amount: 0 }])}>⊕ Thêm chi phí</button>
              <div className="purchase-tax-row">
                <span>Thuế</span>
                <label><input type="number" min="0" max="100" value={taxRate} onChange={(e) => setTaxRate(Math.min(100, Math.max(0, Number(e.target.value))))} />%</label>
                <b>{money(tax)}</b>
              </div>
              <p className="purchase-payable"><span>Tiền cần trả</span><b>{money(total)}</b></p>
              <h4>Thanh toán cho NCC</h4>
              {payments.map((payment) => (
                <div className="purchase-payment-row" key={payment.id}>
                  <select value={payment.method} onChange={(e) => setPayments((current) => current.map((x) => x.id === payment.id ? { ...x, method: e.target.value === "transfer" ? "transfer" : "cash" } : x))}>
                    <option value="cash">Tiền mặt</option>
                    <option value="transfer">Chuyển khoản</option>
                  </select>
                  <input type="number" min="0" value={payment.amount} onChange={(e) => setPayments((current) => current.map((x) => x.id === payment.id ? { ...x, amount: Math.max(0, Number(e.target.value)) } : x))} />
                  <button type="button" onClick={() => setPayments((current) => current.filter((x) => x.id !== payment.id))}>×</button>
                </div>
              ))}
              <button className="purchase-add-link" type="button" onClick={() => setPayments((current) => [...current, { id: crypto.randomUUID(), method: "cash", amount: Math.max(0, total - paid) }])}>⊕ Thêm phương thức</button>
              <p className={`purchase-remaining ${paid > total ? "overpaid" : ""}`}><span>{paid > total ? "Thanh toán vượt" : "Còn phải trả"}</span><b>{money(Math.abs(total - paid))}</b></p>
            </div>
          </div>
          {!serialsValid && <div className="purchase-form-warning">Hàng quản lý serial phải nhập đủ số serial tương ứng với số lượng.</div>}
          {paid > total && <div className="purchase-form-warning">Tổng thanh toán không được vượt quá tiền cần trả.</div>}
          <div className="purchase-form-actions">
            <button type="button" onClick={() => { setOpen(false); resetPurchaseForm(); }}>Hủy</button>
            <SpinnerButton
            className="primary"
            busy={busy}
            disabled={!items.length || !supplierId || !serialsValid || paid > total}
            onClick={save}
          >
            {editingId ? "Lưu thay đổi" : "Hoàn tất nhập hàng"}
          </SpinnerButton>
          </div>
          </div>
        </Modal>
      )}
      {returningPurchase && (
        <Modal
          title={`Hoàn trả phiếu nhập · ${returningPurchase.code}`}
          onClose={() => {
            if (!purchaseReturnBusy) setReturningPurchase(null);
          }}
          className="purchase-return-modal"
        >
          <div className="purchase-return-warning">
            <b>Hệ thống sẽ thực hiện đồng thời:</b>
            <ul>
              <li>Đánh dấu phiếu nhập là Đã hoàn trả và khóa chỉnh sửa.</li>
              <li>Trừ toàn bộ hàng hóa và serial của phiếu khỏi kho.</li>
              <li>
                {returningPurchase.paid > 0
                  ? `Ghi khoản thu lại ${money(returningPurchase.paid)} vào Sổ thu chi theo đúng phương thức đã thanh toán.`
                  : "Phiếu chưa thanh toán nên không phát sinh khoản thu lại."}
              </li>
              <li>Đóng công nợ còn lại với nhà cung cấp.</li>
            </ul>
            <p>
              Nếu một phần hàng hoặc serial đã xuất kho, thao tác sẽ bị chặn để
              tránh sai lệch tồn kho.
            </p>
          </div>
          <Field label="Lý do hoàn trả">
            <textarea
              autoFocus
              value={purchaseReturnReason}
              maxLength={500}
              onChange={(event) => setPurchaseReturnReason(event.target.value)}
              placeholder="Nhập lý do để lưu lịch sử hoàn trả"
            />
          </Field>
          <div className="purchase-return-actions">
            <button
              className="secondary"
              type="button"
              disabled={purchaseReturnBusy}
              onClick={() => setReturningPurchase(null)}
            >
              Quay lại
            </button>
            <SpinnerButton
              className="purchase-return-submit"
              busy={purchaseReturnBusy}
              disabled={!purchaseReturnReason.trim()}
              onClick={returnPurchase}
            >
              Xác nhận hoàn trả
            </SpinnerButton>
          </div>
        </Modal>
      )}
      {supplierFormOpen && (
        <PeopleModal
          kind="supplier"
          onClose={() => setSupplierFormOpen(false)}
          onSaved={(id, name) => {
            setSupplierId(id);
            setSupplierQuery(name);
            setSupplierResultsOpen(false);
          }}
          p={p}
        />
      )}
      {quickProductForm && (
        <Modal
          title="Thêm sản phẩm mới"
          onClose={() => {
            if (!quickProductBusy) setQuickProductForm(null);
          }}
          wide
          className="quick-product-modal"
        >
          <div className="form-grid">
            <Field label="Tên sản phẩm *">
              <input
                autoFocus
                value={quickProductForm.name}
                onChange={(e) =>
                  setQuickProductForm({
                    ...quickProductForm,
                    name: e.target.value,
                  })
                }
              />
            </Field>
            <Field label="SKU">
              <input
                value={quickProductForm.sku}
                onChange={(e) =>
                  setQuickProductForm({
                    ...quickProductForm,
                    sku: e.target.value,
                  })
                }
              />
            </Field>
            <Field label="Nhóm hàng">
              <div className="catalog-option-control">
                <select
                  value={quickProductForm.category}
                  onChange={(e) =>
                    setQuickProductForm({
                      ...quickProductForm,
                      category: e.target.value,
                    })
                  }
                  aria-label="Chọn nhóm hàng"
                >
                  <option value="" disabled>
                    Chọn nhóm hàng
                  </option>
                  {quickOptionNames("category").map((name) => (
                    <option key={name} value={name}>
                      {name}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => {
                    setQuickOptionType("category");
                    setQuickOptionName("");
                  }}
                  title="Thêm nhóm hàng mới"
                  aria-label="Thêm nhóm hàng mới"
                >
                  ＋
                </button>
              </div>
            </Field>
            <Field label="Thương hiệu">
              <div className="catalog-option-control">
                <select
                  value={quickProductForm.brand}
                  onChange={(e) =>
                    setQuickProductForm({
                      ...quickProductForm,
                      brand: e.target.value,
                    })
                  }
                  aria-label="Chọn thương hiệu"
                >
                  <option value="">Chưa chọn thương hiệu</option>
                  {quickOptionNames("brand").map((name) => (
                    <option key={name} value={name}>
                      {name}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => {
                    setQuickOptionType("brand");
                    setQuickOptionName("");
                  }}
                  title="Thêm thương hiệu mới"
                  aria-label="Thêm thương hiệu mới"
                >
                  ＋
                </button>
              </div>
            </Field>
            <Field label="Đơn vị">
              <input
                value={quickProductForm.unit}
                onChange={(e) =>
                  setQuickProductForm({
                    ...quickProductForm,
                    unit: e.target.value,
                  })
                }
              />
            </Field>
            <Field label="Bảo hành (tháng)">
              <input
                type="number"
                min="0"
                value={quickProductForm.warrantyMonths}
                onChange={(e) =>
                  setQuickProductForm({
                    ...quickProductForm,
                    warrantyMonths: e.target.value,
                  })
                }
              />
            </Field>
            <Field label="Quản lý kho">
              <select
                value={quickProductForm.tracking}
                onChange={(e) =>
                  setQuickProductForm({
                    ...quickProductForm,
                    tracking: e.target.value as "serial" | "quantity",
                    stock: "",
                    serials: "",
                  })
                }
              >
                <option value="serial">Theo serial</option>
                <option value="quantity">Theo số lượng</option>
              </select>
            </Field>
            <Field label="Tồn tối thiểu">
              <input
                type="number"
                min="0"
                value={quickProductForm.min}
                onChange={(e) =>
                  setQuickProductForm({
                    ...quickProductForm,
                    min: e.target.value,
                  })
                }
              />
            </Field>
            <Field label="Giá vốn">
              <MoneyInput
                value={Number(quickProductForm.cost)}
                ariaLabel="Giá vốn sản phẩm"
                onValueChange={(cost) =>
                  setQuickProductForm({
                    ...quickProductForm,
                    cost: String(cost),
                  })
                }
              />
            </Field>
            <Field label="Giá bán">
              <MoneyInput
                value={Number(quickProductForm.price)}
                ariaLabel="Giá bán sản phẩm"
                onValueChange={(price) =>
                  setQuickProductForm({
                    ...quickProductForm,
                    price: String(price),
                  })
                }
              />
            </Field>
            {quickProductForm.tracking === "quantity" ? (
              <Field label="Số lượng nhập">
                <input
                  type="number"
                  min="0"
                  value={quickProductForm.stock}
                  onChange={(e) =>
                    setQuickProductForm({
                      ...quickProductForm,
                      stock: e.target.value,
                    })
                  }
                />
              </Field>
            ) : (
              <Field label="Danh sách serial" wide>
                <textarea
                  value={quickProductForm.serials}
                  onChange={(e) =>
                    setQuickProductForm({
                      ...quickProductForm,
                      serials: e.target.value,
                    })
                  }
                  placeholder="Mỗi serial một dòng"
                />
              </Field>
            )}
            <Field label="Mô tả sản phẩm" wide>
              <textarea
                value={quickProductForm.description}
                onChange={(e) =>
                  setQuickProductForm({
                    ...quickProductForm,
                    description: e.target.value,
                  })
                }
              />
            </Field>
          </div>
          <p className="quick-product-return-note">
            Sau khi lưu, sản phẩm sẽ được chọn vào phiếu nhập đang làm. Số
            lượng và serial của lần nhập này có thể chỉnh tiếp ngay trên phiếu.
          </p>
          <div className="people-modal-actions">
            <button
              type="button"
              disabled={quickProductBusy}
              onClick={() => setQuickProductForm(null)}
            >
              Hủy
            </button>
            <SpinnerButton
              className="primary"
              busy={quickProductBusy}
              disabled={
                !quickProductForm.name.trim()
              }
              onClick={saveQuickProduct}
            >
              Lưu và thêm vào phiếu
            </SpinnerButton>
          </div>
        </Modal>
      )}
      {quickOptionType && quickProductForm && (
        <Modal
          title={`Thêm ${quickOptionType === "category" ? "nhóm hàng" : "thương hiệu"} mới`}
          onClose={() => {
            if (!quickOptionBusy) setQuickOptionType(null);
          }}
        >
          <Field
            label={
              quickOptionType === "category"
                ? "Tên nhóm hàng"
                : "Tên thương hiệu"
            }
          >
            <input
              autoFocus
              value={quickOptionName}
              maxLength={80}
              onChange={(e) => setQuickOptionName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  void saveQuickOption();
                }
              }}
            />
          </Field>
          <SpinnerButton
            className="primary modal-submit"
            busy={quickOptionBusy}
            disabled={!quickOptionName.trim()}
            onClick={saveQuickOption}
          >
            Lưu và chọn
          </SpinnerButton>
        </Modal>
      )}
    </>
  );
}

export function Returns(p: ViewProps) {
  const [open, setOpen] = useState(false);
  const [orderId, setOrderId] = useState("");
  const [itemId, setItemId] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [reason, setReason] = useState("");
  const order = p.data.orders.find((x) => x.id === orderId);
  const items = p.data.orderItems.filter((x) => x.orderId === orderId);
  const save = async () => {
    const result = await p.api({
      action: "return",
      orderId,
      reason,
      refund: true,
      items: [{ itemId: Number(itemId), quantity }],
    });
    setOpen(false);
    p.notify(
      `Đã tạo phiếu ${result.code} và hoàn ${money(Number(result.amount))}.`,
    );
    await p.reload();
  };
  return (
    <>
      <article className="panel page">
        <PanelTitle
          text="Đổi trả hàng"
          sub="Hoàn kho, serial và tiền theo đơn bán gốc"
          action="＋ Tạo phiếu đổi trả"
          onAction={() => setOpen(true)}
        />
        <div className="table">
          <table>
            <thead>
              <tr>
                <th>Mã phiếu</th>
                <th>Đơn gốc</th>
                <th>Khách hàng</th>
                <th>Hoàn tiền</th>
                <th>Lý do</th>
                <th>Thời gian</th>
              </tr>
            </thead>
            <tbody>
              {p.data.returns.length ? (
                p.data.returns.map((x) => (
                  <tr key={x.id}>
                    <td className="link">{x.code}</td>
                    <td>{x.orderCode}</td>
                    <td>{x.customerName}</td>
                    <td>{money(x.amount)}</td>
                    <td>{x.reason}</td>
                    <td>{formatDate(x.createdAt)}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6}>
                    <Empty text="Chưa có phiếu đổi trả" />
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </article>
      {open && (
        <Modal title="Tạo phiếu đổi trả" onClose={() => setOpen(false)}>
          <Field label="Đơn bán gốc">
            <select
              value={orderId}
              onChange={(e) => {
                setOrderId(e.target.value);
                setItemId("");
              }}
            >
              <option value="">Chọn đơn hàng</option>
              {p.data.orders
                .filter((x) => x.status !== "cancelled")
                .map((x) => (
                  <option key={x.id} value={x.id}>
                    {x.code} · {x.customerName}
                  </option>
                ))}
            </select>
          </Field>
          {order && (
            <>
              <Field label="Sản phẩm trả">
                <select
                  value={itemId}
                  onChange={(e) => setItemId(e.target.value)}
                >
                  <option value="">Chọn sản phẩm</option>
                  {items.map((x) => (
                    <option key={x.id} value={x.id}>
                      {x.productName} · tối đa {x.quantity}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Số lượng trả">
                <input
                  type="number"
                  min="1"
                  max={
                    items.find((x) => x.id === Number(itemId))?.quantity || 1
                  }
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                />
              </Field>
            </>
          )}
          <Field label="Lý do đổi trả">
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Lỗi sản phẩm, đổi nhu cầu..."
            />
          </Field>
          <button
            className="primary modal-submit"
            disabled={!itemId || !reason}
            onClick={save}
          >
            Xác nhận đổi trả và hoàn tiền
          </button>
        </Modal>
      )}
    </>
  );
}

export function Warranties(p: ViewProps) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    customerName: "",
    phone: "",
    productName: "",
    serial: "",
    issue: "",
    expectedAt: "",
    note: "",
  });
  const create = async () => {
    const result = await p.api({ action: "warranty-create", ...form });
    setOpen(false);
    p.notify(`Đã tiếp nhận phiếu bảo hành ${result.code}.`);
    await p.reload();
  };
  const update = async (id: string, status: string) => {
    await p.api({
      action: "warranty-update",
      id,
      status,
      note: "Cập nhật từ màn hình bảo hành",
    });
    p.notify("Đã cập nhật trạng thái bảo hành.");
    await p.reload();
  };
  return (
    <>
      <div className="three">
        <Kpi
          icon="♧"
          label="Đang tiếp nhận"
          value={String(
            p.data.warranties.filter((x) => x.status === "received").length,
          )}
        />
        <Kpi
          icon="◌"
          label="Đang xử lý"
          value={String(
            p.data.warranties.filter((x) =>
              ["processing", "waiting"].includes(x.status),
            ).length,
          )}
          tone="orange"
        />
        <Kpi
          icon="✓"
          label="Đã hoàn tất"
          value={String(
            p.data.warranties.filter((x) =>
              ["completed", "returned"].includes(x.status),
            ).length,
          )}
          tone="green"
        />
      </div>
      <article className="panel page">
        <PanelTitle
          text="Bảo hành – sửa chữa"
          sub="Theo dõi từ tiếp nhận đến khi trả khách"
          action="＋ Tiếp nhận bảo hành"
          onAction={() => setOpen(true)}
        />
        <div className="table">
          <table>
            <thead>
              <tr>
                <th>Mã phiếu</th>
                <th>Khách hàng</th>
                <th>Sản phẩm / Serial</th>
                <th>Tình trạng lỗi</th>
                <th>Hẹn trả</th>
                <th>Trạng thái</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {p.data.warranties.length ? (
                p.data.warranties.map((x) => (
                  <tr key={x.id}>
                    <td className="link">{x.code}</td>
                    <td>
                      <b>{x.customerName}</b>
                      <small>{x.phone}</small>
                    </td>
                    <td>
                      <b>{x.productName}</b>
                      <small>{x.serial || "Không serial"}</small>
                    </td>
                    <td>{x.issue}</td>
                    <td>{x.expectedAt || "—"}</td>
                    <td>
                      <Status value={x.status} />
                    </td>
                    <td>
                      <select
                        aria-label="Cập nhật trạng thái"
                        value={x.status}
                        onChange={(e) => update(x.id, e.target.value)}
                      >
                        <option value="received">Đã tiếp nhận</option>
                        <option value="processing">Đang xử lý</option>
                        <option value="waiting">Chờ linh kiện</option>
                        <option value="completed">Đã hoàn tất</option>
                        <option value="returned">Đã trả khách</option>
                      </select>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7}>
                    <Empty text="Chưa có phiếu bảo hành" />
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </article>
      {open && (
        <Modal title="Tiếp nhận bảo hành" onClose={() => setOpen(false)}>
          <div className="form-grid">
            <Field label="Tên khách hàng">
              <input
                value={form.customerName}
                onChange={(e) =>
                  setForm({ ...form, customerName: e.target.value })
                }
              />
            </Field>
            <Field label="Số điện thoại">
              <input
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
              />
            </Field>
            <Field label="Sản phẩm">
              <input
                value={form.productName}
                onChange={(e) =>
                  setForm({ ...form, productName: e.target.value })
                }
              />
            </Field>
            <Field label="Serial / IMEI">
              <input
                list="sold-serials"
                value={form.serial}
                onChange={(e) => setForm({ ...form, serial: e.target.value })}
              />
              <datalist id="sold-serials">
                {p.data.serials
                  .filter((x) => x.status === "sold")
                  .map((x) => (
                    <option key={x.id} value={x.serial}>
                      {x.productName}
                    </option>
                  ))}
              </datalist>
            </Field>
            <Field label="Tình trạng lỗi" wide>
              <textarea
                value={form.issue}
                onChange={(e) => setForm({ ...form, issue: e.target.value })}
              />
            </Field>
            <Field label="Ngày hẹn trả">
              <input
                type="date"
                value={form.expectedAt}
                onChange={(e) =>
                  setForm({ ...form, expectedAt: e.target.value })
                }
              />
            </Field>
            <Field label="Ghi chú">
              <input
                value={form.note}
                onChange={(e) => setForm({ ...form, note: e.target.value })}
              />
            </Field>
          </div>
          <button className="primary modal-submit" onClick={create}>
            Tạo phiếu bảo hành
          </button>
        </Modal>
      )}
    </>
  );
}

function PeopleModal({
  kind,
  item,
  onClose,
  onSaved,
  p,
}: {
  kind: "customer" | "supplier";
  item?: Customer | Supplier;
  onClose: () => void;
  onSaved?: (id: string, name: string) => void;
  p: ViewProps;
}) {
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [form, setForm] = useState({
    name: item?.name || "",
    phone: item?.phone || "",
    email: item?.email || "",
    address: item?.address || "",
    code: (item as Supplier)?.code || "",
  });
  const save = async () => {
    if (saving || deleting) return;
    setSaving(true);
    try {
      const result = await p.api({ action: kind, id: item?.id, ...form });
      const savedId = String(result.id || item?.id || "");
      await p.reload();
      onSaved?.(savedId, form.name.trim());
      onClose();
      p.notify(
        kind === "customer" ? "Đã lưu khách hàng." : "Đã lưu nhà cung cấp.",
      );
    } catch (error) {
      p.notify(error instanceof Error ? error.message : "Không thể lưu thông tin.");
    } finally {
      setSaving(false);
    }
  };
  const removePerson = async () => {
    if (!item || saving || deleting) return;
    setDeleting(true);
    try {
      await p.api({
        action: kind === "customer" ? "customer-delete" : "supplier-delete",
        id: item.id,
      });
      await p.reload();
      onClose();
      p.notify(
        `Đã xóa ${kind === "customer" ? "khách hàng" : "nhà cung cấp"} ${item.name}.`,
      );
    } catch (error) {
      setConfirmDelete(false);
      p.notify(
        error instanceof Error
          ? error.message
          : `Không thể xóa ${kind === "customer" ? "khách hàng" : "nhà cung cấp"}.`,
      );
    } finally {
      setDeleting(false);
    }
  };
  return (
    <Modal
      title={`${item ? "Sửa" : "Thêm"} ${kind === "customer" ? "khách hàng" : "nhà cung cấp"}`}
      onClose={onClose}
    >
      <div className="form-grid">
        {kind === "supplier" && (
          <Field label="Mã NCC">
            <input
              value={form.code}
              onChange={(e) => setForm({ ...form, code: e.target.value })}
            />
          </Field>
        )}
        <Field label="Tên">
          <input
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
        </Field>
        <Field label="Số điện thoại">
          <input
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
          />
        </Field>
        <Field label="Email">
          <input
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
          />
        </Field>
        <Field label="Địa chỉ" wide>
          <input
            value={form.address}
            onChange={(e) => setForm({ ...form, address: e.target.value })}
          />
        </Field>
      </div>
      {item && confirmDelete && (
        <div className="supplier-delete-confirm" role="alert">
          <div>
            <b>
              Xóa {kind === "customer" ? "khách hàng" : "nhà cung cấp"} này?
            </b>
            <span>
              <strong>{item.name}</strong> sẽ bị xóa khỏi danh sách nếu chưa
              phát sinh giao dịch. Thao tác này không thể hoàn tác.
            </span>
          </div>
          <div>
            <button
              type="button"
              className="secondary"
              disabled={deleting}
              onClick={() => setConfirmDelete(false)}
            >
              Không xóa
            </button>
            <button
              type="button"
              className="danger-button supplier-delete-final"
              disabled={deleting}
              onClick={removePerson}
            >
              {deleting ? "Đang xóa..." : "Xác nhận xóa"}
            </button>
          </div>
        </div>
      )}
      <div className={`people-modal-actions ${item ? "has-delete" : ""}`}>
        {item && (
          <button
            type="button"
            className="danger-button"
            disabled={saving || deleting}
            onClick={() => setConfirmDelete(true)}
          >
            Xóa {kind === "customer" ? "khách hàng" : "nhà cung cấp"}
          </button>
        )}
        <button
          className="primary"
          disabled={saving || deleting}
          onClick={save}
        >
          {saving ? "Đang lưu..." : "Lưu thông tin"}
        </button>
      </div>
    </Modal>
  );
}

type PartnerDetailsTarget = {
  type: "customer" | "supplier";
  id?: string;
  name: string;
};

type PartnerDetailsData = {
  partner: {
    id: string;
    code?: string;
    name: string;
    phone: string;
    email: string;
    address: string;
    createdAt: string;
  };
  documents: Array<{
    id: string;
    code: string;
    total: number;
    paid: number;
    status: string;
    happenedAt: string;
  }>;
};

function PartnerDetailsModal({
  target,
  onClose,
}: {
  target: PartnerDetailsTarget;
  onClose: () => void;
}) {
  const [data, setData] = useState<PartnerDetailsData | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const controller = new AbortController();
    const params = new URLSearchParams({
      type: target.type,
      name: target.name,
    });
    if (target.id) params.set("id", target.id);

    void fetch(`/api/partner-details?${params.toString()}`, {
      cache: "no-store",
      signal: controller.signal,
    })
      .then(async (response) => {
        const result = (await response.json()) as PartnerDetailsData & {
          error?: string;
        };
        if (!response.ok) throw new Error(result.error || "Không thể tải dữ liệu.");
        setData(result);
      })
      .catch((reason: unknown) => {
        if (reason instanceof DOMException && reason.name === "AbortError") return;
        setError(
          reason instanceof Error
            ? reason.message
            : "Không thể tải thông tin đối tượng.",
        );
      });

    return () => controller.abort();
  }, [target.id, target.name, target.type]);

  const partnerLabel =
    target.type === "customer" ? "Khách hàng" : "Nhà cung cấp";
  const documentLabel =
    target.type === "customer" ? "đơn hàng" : "phiếu nhập";

  return (
    <Modal
      title={`Chi tiết ${partnerLabel.toLocaleLowerCase("vi")}`}
      onClose={onClose}
      wide
      className="partner-details-modal"
    >
      {!data && !error && (
        <div className="partner-details-loading">Đang tải thông tin và lịch sử…</div>
      )}
      {error && (
        <div className="partner-details-error" role="alert">
          {error}
        </div>
      )}
      {data && (
        <>
          <section className="partner-profile">
            <i>{data.partner.name.slice(0, 1).toUpperCase()}</i>
            <div className="partner-profile-main">
              <span className={`partner-type-badge ${target.type}`}>
                {partnerLabel}
              </span>
              <h3>{data.partner.name}</h3>
              {target.type === "supplier" && data.partner.code && (
                <small>Mã NCC: {data.partner.code}</small>
              )}
            </div>
            <div className="partner-profile-meta">
              <p>
                <small>Số điện thoại</small>
                <b>{data.partner.phone || "Chưa cập nhật"}</b>
              </p>
              <p>
                <small>Email</small>
                <b>{data.partner.email || "Chưa cập nhật"}</b>
              </p>
              <p>
                <small>Địa chỉ</small>
                <b>{data.partner.address || "Chưa cập nhật"}</b>
              </p>
              <p>
                <small>Ngày tạo hồ sơ</small>
                <b>{data.partner.createdAt ? formatDate(data.partner.createdAt) : "Chưa có hồ sơ"}</b>
              </p>
            </div>
          </section>

          <div className="partner-history-heading">
            <div>
              <h3>Lịch sử {documentLabel}</h3>
              <p>Mới nhất trước · {data.documents.length} chứng từ</p>
            </div>
            <span>Tối đa 10 dòng trong khung, cuộn để xem thêm</span>
          </div>
          <div className="partner-history-scroll">
            <table>
              <thead>
                <tr>
                  <th>{target.type === "customer" ? "Mã đơn" : "Mã phiếu"}</th>
                  <th>Ngày giờ</th>
                  <th>Tổng tiền</th>
                  <th>Đã thanh toán</th>
                  <th>Còn lại</th>
                  <th>Trạng thái</th>
                </tr>
              </thead>
              <tbody>
                {data.documents.map((document) => (
                  <tr key={document.id}>
                    <td className="link">{document.code}</td>
                    <td>{formatDate(document.happenedAt)}</td>
                    <td>{money(document.total)}</td>
                    <td>{money(document.paid)}</td>
                    <td className={document.total > document.paid ? "red" : ""}>
                      {money(Math.max(0, document.total - document.paid))}
                    </td>
                    <td>
                      <Status value={document.status} />
                    </td>
                  </tr>
                ))}
                {!data.documents.length && (
                  <tr>
                    <td className="partner-history-empty" colSpan={6}>
                      Chưa có {documentLabel} liên quan đến đối tượng này.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </>
      )}
    </Modal>
  );
}

export function Customers(p: ViewProps) {
  const [open, setOpen] = useState<Customer | true | false>(false);
  const [details, setDetails] = useState<PartnerDetailsTarget | null>(null);
  const remove = async (customer: Customer) => {
    if (!confirm(`Xóa khách hàng ${customer.name}?\n\nChỉ khách hàng chưa phát sinh giao dịch mới được phép xóa.`)) return;
    try {
      await p.api({ action: "customer-delete", id: customer.id });
      p.notify(`Đã xóa khách hàng ${customer.name}.`);
      await p.reload();
    } catch (error) {
      p.notify(error instanceof Error ? error.message : "Không thể xóa khách hàng.");
    }
  };
  return (
    <>
      <article className="panel page">
        <PanelTitle
          text="Khách hàng"
          sub="Thông tin và lịch sử mua hàng"
          action="＋ Thêm khách hàng"
          onAction={() => setOpen(true)}
        />
        <div className="cards-grid">
          {p.data.customers.length ? (
            p.data.customers.map((x) => {
              const orders = p.data.orders.filter(
                (o) => o.customerId === x.id && o.status !== "cancelled",
              );
              return (
                <article key={x.id}>
                  <i>{x.name.slice(0, 1).toUpperCase()}</i>
                  <div>
                    <h3>
                      <button
                        type="button"
                        className="partner-name-button"
                        onClick={() =>
                          setDetails({ type: "customer", id: x.id, name: x.name })
                        }
                      >
                        {x.name}
                      </button>
                    </h3>
                    <p>
                      {x.phone} · {x.email || "Chưa có email"}
                    </p>
                    <small>
                      {orders.length} đơn ·{" "}
                      {money(orders.reduce((s, o) => s + o.total, 0))}
                    </small>
                  </div>
                  <div className="people-card-actions">
                    <button onClick={() => setOpen(x)}>Sửa</button>
                    <button className="danger-link" onClick={() => void remove(x)}>
                      Xóa
                    </button>
                  </div>
                </article>
              );
            })
          ) : (
            <Empty text="Chưa có khách hàng" />
          )}
        </div>
      </article>
      {open && (
        <PeopleModal
          kind="customer"
          item={open === true ? undefined : open}
          onClose={() => setOpen(false)}
          p={p}
        />
      )}
      {details && (
        <PartnerDetailsModal target={details} onClose={() => setDetails(null)} />
      )}
    </>
  );
}
export function Suppliers(p: ViewProps) {
  const [open, setOpen] = useState<Supplier | true | false>(false);
  const [details, setDetails] = useState<PartnerDetailsTarget | null>(null);
  const remove = async (supplier: Supplier) => {
    if (!confirm(`Xóa nhà cung cấp ${supplier.name}?\n\nChỉ nhà cung cấp chưa phát sinh giao dịch mới được phép xóa.`)) return;
    try {
      await p.api({ action: "supplier-delete", id: supplier.id });
      p.notify(`Đã xóa nhà cung cấp ${supplier.name}.`);
      await p.reload();
    } catch (error) {
      p.notify(error instanceof Error ? error.message : "Không thể xóa nhà cung cấp.");
    }
  };
  return (
    <>
      <article className="panel page">
        <PanelTitle
          text="Nhà cung cấp"
          sub="Danh bạ và lịch sử nhập hàng"
          action="＋ Thêm nhà cung cấp"
          onAction={() => setOpen(true)}
        />
        <div className="table">
          <table>
            <thead>
              <tr>
                <th>Mã NCC</th>
                <th>Tên nhà cung cấp</th>
                <th>Liên hệ</th>
                <th>Số phiếu nhập</th>
                <th>Tổng nhập</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {p.data.suppliers.map((x) => {
                const rows = p.data.purchases.filter(
                  (y) =>
                    y.supplierId === x.id &&
                    y.status !== "purchase_returned",
                );
                return (
                  <tr key={x.id}>
                    <td>{x.code}</td>
                    <td>
                      <button
                        type="button"
                        className="partner-name-button"
                        onClick={() =>
                          setDetails({ type: "supplier", id: x.id, name: x.name })
                        }
                      >
                        {x.name}
                      </button>
                      <small>{x.address}</small>
                    </td>
                    <td>
                      {x.phone}
                      <small>{x.email}</small>
                    </td>
                    <td>{rows.length}</td>
                    <td>{money(rows.reduce((s, y) => s + y.total, 0))}</td>
                    <td>
                      <div className="row-actions">
                        <button
                          className="link-button"
                          onClick={() => setOpen(x)}
                        >
                          Sửa
                        </button>
                        <button
                          className="danger-link"
                          onClick={() => void remove(x)}
                        >
                          Xóa
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </article>
      {open && (
        <PeopleModal
          kind="supplier"
          item={open === true ? undefined : open}
          onClose={() => setOpen(false)}
          p={p}
        />
      )}
      {details && (
        <PartnerDetailsModal target={details} onClose={() => setDetails(null)} />
      )}
    </>
  );
}

export function Debts(p: ViewProps) {
  const [open, setOpen] = useState(false);
  const [details, setDetails] = useState<PartnerDetailsTarget | null>(null);
  const [payId, setPayId] = useState("");
  const [pay, setPay] = useState(0);
  const [payMethod, setPayMethod] = useState("cash");
  const [form, setForm] = useState({
    partnerType: "customer",
    partnerName: "",
    reference: "",
    total: 0,
    paid: 0,
    dueDate: "",
  });
  const activeDebt = p.data.debts.find((item) => item.id === payId);
  const create = async () => {
    await p.api({ action: "debt-create", ...form });
    setOpen(false);
    p.notify("Đã tạo khoản công nợ.");
    await p.reload();
  };
  const settle = async () => {
    await p.api({
      action: "debt-pay",
      id: payId,
      amount: pay,
      paymentMethod: payMethod,
    });
    setPayId("");
    p.notify("Đã ghi nhận thanh toán công nợ và cập nhật sổ quỹ.");
    await p.reload();
  };
  return (
    <>
      <div className="three">
        <Kpi
          icon="↓"
          label="Khách còn nợ"
          value={money(
            p.data.debts
              .filter((x) => x.settlementType === "income")
              .reduce((s, x) => s + x.total - x.paid, 0),
          )}
          tone="orange"
        />
        <Kpi
          icon="↑"
          label="Còn nợ NCC"
          value={money(
            p.data.debts
              .filter((x) => x.settlementType === "expense")
              .reduce((s, x) => s + x.total - x.paid, 0),
          )}
          tone="purple"
        />
        <Kpi
          icon="✓"
          label="Đã tất toán"
          value={String(p.data.debts.filter((x) => x.status === "paid").length)}
          tone="green"
        />
      </div>
      <article className="panel page">
        <PanelTitle
          text="Công nợ"
          sub="Theo dõi phải thu và phải trả"
          action="＋ Thêm công nợ"
          onAction={() => setOpen(true)}
        />
        <div className="table">
          <table>
            <thead>
              <tr>
                <th>Đối tác</th>
                <th>Đối tượng</th>
                <th>Loại công nợ</th>
                <th>Tham chiếu</th>
                <th>Tổng</th>
                <th>Đã trả</th>
                <th>Còn lại</th>
                <th>Hạn trả</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {p.data.debts.map((x) => (
                <tr key={x.id}>
                  <td>
                    <button
                      type="button"
                      className="partner-name-button"
                      onClick={() =>
                        setDetails({
                          type:
                            x.partnerType === "supplier"
                              ? "supplier"
                              : "customer",
                          name: x.partnerName,
                        })
                      }
                    >
                      {x.partnerName}
                    </button>
                  </td>
                  <td>
                    <span
                      className={`partner-type-badge ${
                        x.partnerType === "supplier" ? "supplier" : "customer"
                      }`}
                    >
                      {x.partnerType === "supplier"
                        ? "Nhà cung cấp"
                        : "Khách hàng"}
                    </span>
                  </td>
                  <td>
                    {x.settlementType === "income" ? "Phải thu" : "Phải trả"}
                  </td>
                  <td>{x.reference || "—"}</td>
                  <td>{money(x.total)}</td>
                  <td>{money(x.paid)}</td>
                  <td className="red">{money(x.total - x.paid)}</td>
                  <td>{x.dueDate || "—"}</td>
                  <td>
                    {x.status !== "paid" ? (
                      <button
                        className="link-button"
                        onClick={() => {
                          setPayId(x.id);
                          setPay(x.total - x.paid);
                        }}
                      >
                        {x.settlementType === "income" ? "Thu tiền" : "Trả tiền"}
                      </button>
                    ) : (
                      <Status value="paid" />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </article>
      {open && (
        <Modal title="Thêm khoản công nợ" onClose={() => setOpen(false)}>
          <div className="form-grid">
            <Field label="Loại công nợ">
              <select
                value={form.partnerType}
                onChange={(e) =>
                  setForm({ ...form, partnerType: e.target.value })
                }
              >
                <option value="customer">Khách hàng nợ</option>
                <option value="supplier">Nợ nhà cung cấp</option>
              </select>
            </Field>
            <Field label="Tên đối tác">
              <input
                value={form.partnerName}
                onChange={(e) =>
                  setForm({ ...form, partnerName: e.target.value })
                }
              />
            </Field>
            <Field label="Tham chiếu">
              <input
                value={form.reference}
                onChange={(e) =>
                  setForm({ ...form, reference: e.target.value })
                }
              />
            </Field>
            <Field label="Hạn thanh toán">
              <input
                type="date"
                value={form.dueDate}
                onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
              />
            </Field>
            <Field label="Tổng tiền">
              <input
                type="number"
                value={form.total}
                onChange={(e) =>
                  setForm({ ...form, total: Number(e.target.value) })
                }
              />
            </Field>
            <Field label="Đã trả">
              <input
                type="number"
                value={form.paid}
                onChange={(e) =>
                  setForm({ ...form, paid: Number(e.target.value) })
                }
              />
            </Field>
          </div>
          <button className="primary modal-submit" onClick={create}>
            Lưu công nợ
          </button>
        </Modal>
      )}
      {payId && (
        <Modal
          title={activeDebt?.settlementType === "income" ? "Thu công nợ" : "Trả công nợ"}
          onClose={() => setPayId("")}
        >
          {activeDebt && (
            <div className="debt-settlement-summary">
              <span>{activeDebt.partnerName}</span>
              <b>{money(activeDebt.total - activeDebt.paid)}</b>
              <small>{activeDebt.reference || "Công nợ không có tham chiếu"}</small>
            </div>
          )}
          <Field label={activeDebt?.settlementType === "income" ? "Số tiền thực thu" : "Số tiền thực trả"}>
            <input
              type="number"
              value={pay}
              onChange={(e) => setPay(Number(e.target.value))}
            />
          </Field>
          <Field label="Phương thức thanh toán">
            <select
              value={payMethod}
              onChange={(e) => setPayMethod(e.target.value)}
            >
              <option value="cash">Tiền mặt</option>
              <option value="transfer">Chuyển khoản</option>
            </select>
          </Field>
          <button className="primary modal-submit" onClick={settle}>
            {activeDebt?.settlementType === "income" ? "Xác nhận đã thu" : "Xác nhận đã trả"}
          </button>
        </Modal>
      )}
      {details && (
        <PartnerDetailsModal target={details} onClose={() => setDetails(null)} />
      )}
    </>
  );
}

export function Cash(p: ViewProps) {
  const [open, setOpen] = useState(false);
  const [filter, setFilter] = useState<"all" | "cash" | "transfer">("all");
  const [confirmId, setConfirmId] = useState("");
  const [settlementMode, setSettlementMode] = useState<
    "full" | "partial" | "none"
  >("full");
  const [settlementAmount, setSettlementAmount] = useState(0);
  const [settlementMethod, setSettlementMethod] = useState<"cash" | "transfer">(
    "cash",
  );
  const [form, setForm] = useState({
    type: "expense",
    category: "Chi phí vận hành",
    note: "",
    amount: 0,
    paymentMethod: "cash",
  });
  const balance = (method?: "cash" | "transfer") =>
    p.data.cashTransactions
      .filter(
        (x) =>
          ["completed", "partial"].includes(x.status) &&
          (!method || x.paymentMethod === method),
      )
      .reduce(
        (sum, transaction) =>
          sum +
          (transaction.type === "income"
            ? transaction.amount
            : -transaction.amount),
        0,
      );
  const filteredTransactions = p.data.cashTransactions.filter(
    (transaction) =>
      filter === "all" || transaction.paymentMethod === filter,
  );
  const save = async () => {
    await p.api({ action: "cash", ...form });
    setOpen(false);
    p.notify("Đã ghi sổ thu chi.");
    await p.reload();
  };
  const confirming = p.data.cashTransactions.find((x) => x.id === confirmId);
  const expectedAmount = confirming
    ? confirming.expectedAmount || confirming.amount
    : 0;
  const actualAmount =
    settlementMode === "full"
      ? expectedAmount
      : settlementMode === "none"
        ? 0
        : Math.min(expectedAmount, Math.max(0, settlementAmount));
  const debtAmount = Math.max(0, expectedAmount - actualAmount);
  const openConfirmation = (id: string) => {
    const transaction = p.data.cashTransactions.find((x) => x.id === id);
    if (!transaction) return;
    const expected = transaction.expectedAmount || transaction.amount;
    setConfirmId(id);
    setSettlementMode("full");
    setSettlementAmount(expected);
    setSettlementMethod(transaction.paymentMethod);
  };
  const confirmSettlement = async () => {
    if (!confirming) return;
    await p.api({
      action: "cash-confirm",
      id: confirming.id,
      amount: actualAmount,
      paymentMethod: settlementMethod,
    });
    setConfirmId("");
    p.notify(
      debtAmount > 0
        ? `Đã ghi nhận ${money(actualAmount)} và chuyển ${money(debtAmount)} còn lại vào công nợ.`
        : `Đã xác nhận ${confirming.type === "income" ? "thu" : "trả"} đủ ${money(actualAmount)}.`,
    );
    await p.reload();
  };
  return (
    <>
      <div className="three">
        <Kpi
          icon="₫"
          label="Quỹ tiền mặt"
          value={money(balance("cash"))}
          tone="green"
        />
        <Kpi
          icon="⇄"
          label="Quỹ chuyển khoản"
          value={money(balance("transfer"))}
          tone="purple"
        />
        <Kpi
          icon="Σ"
          label="Tổng cả hai quỹ"
          value={money(balance())}
          tone="blue"
        />
      </div>
      <article className="panel cash-page">
        <PanelTitle
          text="Sổ quỹ"
          sub="Theo dõi riêng tiền mặt, chuyển khoản hoặc tổng hợp cả hai"
          action="＋ Lập phiếu thu/chi"
          onAction={() => setOpen(true)}
        />
        <div className="cash-filters" role="group" aria-label="Lọc sổ quỹ">
          {[
            ["all", "Tổng cả hai"],
            ["cash", "Tiền mặt"],
            ["transfer", "Chuyển khoản"],
          ].map(([value, label]) => (
            <button
              key={value}
              type="button"
              className={filter === value ? "selected" : ""}
              onClick={() =>
                setFilter(value as "all" | "cash" | "transfer")
              }
            >
              {label}
            </button>
          ))}
        </div>
        <div className="table cash-table">
          <table>
            <thead>
              <tr>
                <th>Thời gian</th>
                <th>Loại</th>
                <th>Trạng thái</th>
                <th>Nhóm</th>
                <th>Quỹ</th>
                <th>Nội dung</th>
                <th>Số tiền</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.map((x) => (
                <tr key={x.id}>
                  <td>{formatDate(x.createdAt)}</td>
                  <td>
                    <span className={`cash-kind ${x.type}`}>
                      {x.type === "income" ? "Phiếu thu" : "Phiếu chi"}
                    </span>
                  </td>
                  <td><Status value={x.status} /></td>
                  <td>{x.category}</td>
                  <td>
                    <span className={`fund-badge ${x.paymentMethod}`}>
                      {x.paymentMethod === "transfer"
                        ? "Chuyển khoản"
                        : "Tiền mặt"}
                    </span>
                  </td>
                  <td>
                    <b>{x.note}</b>
                    {(x.partnerName || x.reference) && (
                      <small>
                        {[x.partnerName, x.reference].filter(Boolean).join(" · ")}
                      </small>
                    )}
                  </td>
                  <td className={x.type === "income" ? "green" : "red"}>
                    {x.type === "income" ? "+" : "−"}
                    {money(x.status === "pending" ? x.expectedAmount || x.amount : x.amount)}
                    {x.status === "partial" && (
                      <small>Công nợ {money(Math.max(0, (x.expectedAmount || x.amount) - x.amount))}</small>
                    )}
                  </td>
                  <td>
                    {x.status === "pending" && (
                      <button
                        type="button"
                        className={`cash-confirm-button ${x.type}`}
                        onClick={() => openConfirmation(x.id)}
                      >
                        {x.type === "income" ? "Xác nhận thu" : "Xác nhận trả"}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </article>
      {open && (
        <Modal title="Lập phiếu thu / chi" onClose={() => setOpen(false)}>
          <Field label="Loại phiếu">
            <select
              value={form.type}
              onChange={(e) => setForm({ ...form, type: e.target.value })}
            >
              <option value="income">Phiếu thu</option>
              <option value="expense">Phiếu chi</option>
            </select>
          </Field>
          <Field label="Nhóm khoản">
            <input
              value={form.category}
              onChange={(e) => setForm({ ...form, category: e.target.value })}
            />
          </Field>
          <Field label="Ghi nhận vào quỹ">
            <select
              value={form.paymentMethod}
              onChange={(e) =>
                setForm({ ...form, paymentMethod: e.target.value })
              }
            >
              <option value="cash">Tiền mặt</option>
              <option value="transfer">Chuyển khoản</option>
            </select>
          </Field>
          <Field label="Nội dung">
            <textarea
              value={form.note}
              onChange={(e) => setForm({ ...form, note: e.target.value })}
            />
          </Field>
          <Field label="Số tiền">
            <input
              type="number"
              value={form.amount}
              onChange={(e) =>
                setForm({ ...form, amount: Number(e.target.value) })
              }
            />
          </Field>
          <button className="primary modal-submit" onClick={save}>
            Ghi sổ
          </button>
        </Modal>
      )}
      {confirming && (
        <Modal
          title={confirming.type === "income" ? "Xác nhận thu tiền" : "Xác nhận trả tiền"}
          onClose={() => setConfirmId("")}
          className="cash-confirm-modal"
        >
          <div className={`cash-confirm-summary ${confirming.type}`}>
            <span>
              {confirming.type === "income" ? "Cần thu" : "Cần trả"}
            </span>
            <b>{money(expectedAmount)}</b>
            <small>
              {confirming.partnerName || "Chưa có tên đối tác"}
              {confirming.reference ? ` · ${confirming.reference}` : ""}
            </small>
          </div>

          <div className="settlement-options" role="radiogroup" aria-label="Mức tiền xác nhận">
            {[
              ["full", confirming.type === "income" ? "Thu đủ" : "Trả đủ"],
              ["partial", confirming.type === "income" ? "Thu một phần" : "Trả một phần"],
              ["none", confirming.type === "income" ? "Chưa thu" : "Chưa trả"],
            ].map(([value, label]) => (
              <button
                type="button"
                role="radio"
                aria-checked={settlementMode === value}
                className={settlementMode === value ? "selected" : ""}
                key={value}
                onClick={() => setSettlementMode(value as "full" | "partial" | "none")}
              >
                {label}
              </button>
            ))}
          </div>

          {settlementMode === "partial" && (
            <Field label={confirming.type === "income" ? "Số tiền thực thu" : "Số tiền thực trả"}>
              <input
                autoFocus
                type="number"
                min={0}
                max={expectedAmount}
                value={settlementAmount}
                onChange={(event) => setSettlementAmount(Number(event.target.value))}
              />
            </Field>
          )}
          {actualAmount > 0 && (
            <Field label="Ghi nhận vào quỹ">
              <select
                value={settlementMethod}
                onChange={(event) =>
                  setSettlementMethod(event.target.value === "transfer" ? "transfer" : "cash")
                }
              >
                <option value="cash">Tiền mặt</option>
                <option value="transfer">Chuyển khoản</option>
              </select>
            </Field>
          )}

          <div className="settlement-result">
            <p>
              <span>{confirming.type === "income" ? "Ghi thu vào quỹ" : "Ghi chi khỏi quỹ"}</span>
              <b>{money(actualAmount)}</b>
            </p>
            <p className={debtAmount > 0 ? "has-debt" : ""}>
              <span>Chuyển vào công nợ</span>
              <b>{money(debtAmount)}</b>
            </p>
          </div>
          {debtAmount > 0 && (
            <div className="settlement-note">
              {confirming.type === "income"
                ? `${confirming.partnerName || "Đối tác"} còn phải trả ${money(debtAmount)}.`
                : `Cửa hàng còn phải trả ${confirming.partnerName || "đối tác"} ${money(debtAmount)}.`}
            </div>
          )}
          <div className="cash-confirm-actions">
            <button type="button" onClick={() => setConfirmId("")}>Để sau</button>
            <button type="button" className="primary" onClick={() => void confirmSettlement()}>
              Xác nhận và cập nhật công nợ
            </button>
          </div>
        </Modal>
      )}
    </>
  );
}

export function Reports(p: ViewProps) {
  const valid = p.data.orders.filter((x) => x.status !== "cancelled");
  const revenue = valid.reduce((s, x) => s + x.total, 0);
  const cost = p.data.orderItems
    .filter((i) => valid.some((o) => o.id === i.orderId))
    .reduce((s, x) => s + x.unitCost * x.quantity, 0);
  const exportCsv = () => {
    const rows = [
      ["Mã đơn", "Khách hàng", "Kênh", "Doanh thu", "Trạng thái", "Ngày"],
      ...valid.map((x) => [
        x.code,
        x.customerName,
        x.channel,
        String(x.total),
        x.status,
        x.createdAt,
      ]),
    ];
    const csv =
      "\uFEFF" +
      rows
        .map((r) =>
          r.map((v) => `"${String(v).replaceAll('"', '""')}"`).join(","),
        )
        .join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(
      new Blob([csv], { type: "text/csv;charset=utf-8" }),
    );
    a.download = `bao-cao-tien-computer-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  };
  const byProduct = (() => {
    const map = new Map<
      string,
      { name: string; qty: number; revenue: number }
    >();
    p.data.orderItems.forEach((i) => {
      if (!valid.some((o) => o.id === i.orderId)) return;
      const old = map.get(i.sku) || { name: i.productName, qty: 0, revenue: 0 };
      old.qty += i.quantity;
      old.revenue += i.quantity * i.unitPrice;
      map.set(i.sku, old);
    });
    return [...map.entries()].sort((a, b) => b[1].revenue - a[1].revenue);
  })();
  return (
    <>
      <div className="report-actions">
        <button onClick={exportCsv}>⇩ Xuất Excel/CSV</button>
        <button onClick={() => window.print()}>▤ In báo cáo</button>
      </div>
      <div className="kpis">
        <Kpi icon="₫" label="Doanh thu" value={money(revenue)} />
        <Kpi
          icon="↗"
          label="Lợi nhuận gộp"
          value={money(revenue - cost)}
          tone="green"
        />
        <Kpi
          icon="%"
          label="Biên lợi nhuận"
          value={`${revenue ? Math.round(((revenue - cost) / revenue) * 100) : 0}%`}
          tone="purple"
        />
        <Kpi
          icon="▣"
          label="Giá trị tồn"
          value={money(
            p.data.products.reduce((s, x) => s + x.cost * x.stock, 0),
          )}
          tone="orange"
        />
      </div>
      <div className="cols">
        <article className="panel">
          <PanelTitle text="Sản phẩm bán chạy" sub="Theo doanh thu" />
          <div className="rank-list">
            {byProduct.slice(0, 8).map(([sku, x], i) => (
              <div key={sku}>
                <i>{i + 1}</i>
                <span>
                  <b>{x.name}</b>
                  <small>{x.qty} sản phẩm</small>
                </span>
                <strong>{money(x.revenue)}</strong>
              </div>
            ))}
          </div>
        </article>
        <article className="panel">
          <PanelTitle text="Hiệu quả vận hành" />
          <div className="metrics">
            <p>
              <span>Giá trị đơn trung bình</span>
              <b>
                {money(valid.length ? Math.round(revenue / valid.length) : 0)}
              </b>
            </p>
            <p>
              <span>Tỷ lệ đơn online</span>
              <b>
                {valid.length
                  ? Math.round(
                      (valid.filter((x) => x.channel === "online").length /
                        valid.length) *
                        100,
                    )
                  : 0}
                %
              </b>
            </p>
            <p>
              <span>Tổng khách hàng</span>
              <b>{p.data.customers.length}</b>
            </p>
            <p>
              <span>Đơn bảo hành đang mở</span>
              <b>
                {
                  p.data.warranties.filter(
                    (x) => !["completed", "returned"].includes(x.status),
                  ).length
                }
              </b>
            </p>
          </div>
        </article>
      </div>
    </>
  );
}

export function OnlineStore(p: ViewProps) {
  const [checkout, setCheckout] = useState(false);
  const [busy, setBusy] = useState(false);
  const [customer, setCustomer] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
  });
  const [note, setNote] = useState("");
  const total = p.cart.reduce((s, x) => s + x.price * x.qty, 0);
  const order = async () => {
    setBusy(true);
    try {
      const result = await p.api(
        {
          channel: "online",
          customer,
          shippingAddress: customer.address,
          note,
          paid: 0,
          paymentMethod: "cash",
          items: p.cart.map((x) => ({ productId: x.id, quantity: x.qty })),
        },
        "/api/orders",
      );
      p.setCart([]);
      setCheckout(false);
      p.notify(
        `Đã gửi đơn ${(result.order as { code: string }).code}. Đơn đang chờ cửa hàng xác nhận.`,
      );
      await p.reload();
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <div className="store">
        <div className="store-head">
          <b>TC</b>
          <strong>{p.data.settings.storeName.toUpperCase()}</strong>
          <nav>Laptop　 Linh kiện　 Phụ kiện　 Khuyến mãi</nav>
          <button onClick={() => setCheckout(true)}>
            Giỏ hàng ({p.cart.reduce((s, x) => s + x.qty, 0)})
          </button>
        </div>
        <div className="hero">
          <div>
            <small>LAPTOP CHÍNH HÃNG · KIỂM TRA SERIAL</small>
            <h2>
              Máy tính phù hợp,
              <br />
              giá thật dễ chọn.
            </h2>
            <p>
              Tư vấn đúng nhu cầu, bảo hành rõ ràng và hỗ trợ cài đặt tận tình.
            </p>
            <button
              className="primary"
              onClick={() =>
                document
                  .getElementById("shop-products")
                  ?.scrollIntoView({ behavior: "smooth" })
              }
            >
              Xem sản phẩm
            </button>
          </div>
          <i>▱</i>
        </div>
        <div className="shop" id="shop-products">
          <h2>Sản phẩm nổi bật</h2>
          <div>
            {p.products.map((x) => (
              <article key={x.id}>
                <i>{x.category === "Laptop" ? "▱" : "◇"}</i>
                <small>{x.brand || x.category}</small>
                <h3>{x.name}</h3>
                <p>{x.description || `Bảo hành ${x.warrantyMonths} tháng`}</p>
                <b>{money(x.price)}</b>
                <button onClick={() => p.add(x)} disabled={!x.stock}>
                  {x.stock ? "Thêm vào giỏ" : "Hết hàng"}
                </button>
              </article>
            ))}
          </div>
        </div>
      </div>
      {checkout && (
        <Modal
          title="Giỏ hàng và đặt mua"
          onClose={() => setCheckout(false)}
          wide
        >
          <div className="cart-list checkout-cart">
            {p.cart.map((x) => (
              <div className="cart-row" key={x.id}>
                <span>
                  <b>{x.name}</b>
                  <small>{money(x.price)}</small>
                </span>
                <div>
                  <button
                    onClick={() =>
                      p.setCart((c) =>
                        c.flatMap((i) =>
                          i.id === x.id
                            ? i.qty === 1
                              ? []
                              : [{ ...i, qty: i.qty - 1 }]
                            : [i],
                        ),
                      )
                    }
                  >
                    −
                  </button>
                  {x.qty}
                  <button onClick={() => p.add(x)}>＋</button>
                </div>
              </div>
            ))}
          </div>
          <div className="form-grid">
            <Field label="Họ tên">
              <input
                value={customer.name}
                onChange={(e) =>
                  setCustomer({ ...customer, name: e.target.value })
                }
              />
            </Field>
            <Field label="Số điện thoại">
              <input
                value={customer.phone}
                onChange={(e) =>
                  setCustomer({ ...customer, phone: e.target.value })
                }
              />
            </Field>
            <Field label="Email">
              <input
                value={customer.email}
                onChange={(e) =>
                  setCustomer({ ...customer, email: e.target.value })
                }
              />
            </Field>
            <Field label="Địa chỉ giao hàng">
              <input
                value={customer.address}
                onChange={(e) =>
                  setCustomer({ ...customer, address: e.target.value })
                }
              />
            </Field>
            <Field label="Ghi chú" wide>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />
            </Field>
          </div>
          <div className="checkout-total">
            <span>Tổng đơn hàng</span>
            <b>{money(total)}</b>
          </div>
          <SpinnerButton
            className="primary modal-submit"
            busy={busy}
            disabled={
              !p.cart.length ||
              !customer.name ||
              !customer.phone ||
              !customer.address
            }
            onClick={order}
          >
            Đặt hàng – thanh toán khi nhận
          </SpinnerButton>
        </Modal>
      )}
    </>
  );
}

export function SettingsView(p: ViewProps) {
  const [form, setForm] = useState(p.data.settings);
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    try {
      await p.api({ action: "settings", ...form });
      p.notify("Đã lưu cấu hình cửa hàng.");
      await p.reload();
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="cols">
      <article className="panel settings">
        <h2>Thông tin cửa hàng</h2>
        <Field label="Tên cửa hàng">
          <input
            value={form.storeName}
            onChange={(e) => setForm({ ...form, storeName: e.target.value })}
          />
        </Field>
        <Field label="Số điện thoại">
          <input
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
          />
        </Field>
        <Field label="Địa chỉ">
          <input
            value={form.address}
            onChange={(e) => setForm({ ...form, address: e.target.value })}
          />
        </Field>
        <Field label="Mã số thuế">
          <input
            value={form.taxCode}
            onChange={(e) => setForm({ ...form, taxCode: e.target.value })}
          />
        </Field>
        <Field label="Dòng cuối hóa đơn">
          <input
            value={form.receiptFooter}
            onChange={(e) =>
              setForm({ ...form, receiptFooter: e.target.value })
            }
          />
        </Field>
        <SpinnerButton className="primary" busy={busy} onClick={save}>
          Lưu thay đổi
        </SpinnerButton>
      </article>
      <article className="panel settings">
        <h2>Thiết lập bán hàng</h2>
        <label className="toggle">
          <span>
            Cho phép bán âm kho
            <small>Khuyến nghị tắt để kiểm soát serial</small>
          </span>
          <input
            type="checkbox"
            checked={form.allowNegativeStock}
            onChange={(e) =>
              setForm({ ...form, allowNegativeStock: e.target.checked })
            }
          />
        </label>
        <label className="toggle">
          <span>
            Tự động in hóa đơn<small>Mở hộp thoại in sau khi thanh toán</small>
          </span>
          <input
            type="checkbox"
            checked={form.autoPrint}
            onChange={(e) => setForm({ ...form, autoPrint: e.target.checked })}
          />
        </label>
        <label className="toggle">
          <span>
            Nhắc hàng sắp hết
            <small>Hiển thị trên tổng quan và chuông thông báo</small>
          </span>
          <input
            type="checkbox"
            checked={form.lowStockAlert}
            onChange={(e) =>
              setForm({ ...form, lowStockAlert: e.target.checked })
            }
          />
        </label>
        <button
          className="secondary full"
          onClick={() => {
            if (confirm("Tải lại dữ liệu mới nhất từ hệ thống?")) p.reload();
          }}
        >
          ↻ Đồng bộ dữ liệu ngay
        </button>
      </article>
    </div>
  );
}
