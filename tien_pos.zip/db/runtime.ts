import Database from "better-sqlite3";
import { existsSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";

/**
 * Small compatibility layer for the Cloudflare D1 API used by the existing
 * route handlers.  It keeps all business logic unchanged while persisting to
 * a local SQLite file on the VPS.
 */
export class SQLiteStatement {
  private values: unknown[] = [];

  constructor(
    private readonly database: Database.Database,
    private readonly query: string,
  ) {}

  bind(...values: unknown[]) {
    this.values = values;
    return this;
  }

  async all<T = Record<string, unknown>>(): Promise<{ results: T[] }> {
    return { results: this.database.prepare(this.query).all(...this.values) as T[] };
  }

  async first<T = Record<string, unknown>>(): Promise<T | null> {
    return (this.database.prepare(this.query).get(...this.values) as T | undefined) ?? null;
  }

  async run(): Promise<{ success: true; meta: { changes: number; last_row_id: number | bigint } }> {
    const result = this.database.prepare(this.query).run(...this.values);
    return { success: true, meta: { changes: result.changes, last_row_id: result.lastInsertRowid } };
  }

  execute() {
    return this.database.prepare(this.query).run(...this.values);
  }
}

export class SQLiteD1Compat {
  constructor(private readonly database: Database.Database) {}

  prepare(query: string) {
    return new SQLiteStatement(this.database, query);
  }

  async batch(statements: SQLiteStatement[]) {
    const run = this.database.transaction((items: SQLiteStatement[]) =>
      items.map((statement) => statement.execute()),
    );
    return run(statements);
  }
}

let connection: Database.Database | undefined;

export function databasePath() {
  return resolve(process.env.DATABASE_PATH || "./data/sales.db");
}

export function getSQLite() {
  if (!connection) {
    const path = databasePath();
    if (!existsSync(dirname(path))) mkdirSync(dirname(path), { recursive: true });
    connection = new Database(path);
    connection.pragma("journal_mode = WAL");
    connection.pragma("foreign_keys = ON");
    connection.pragma("busy_timeout = 5000");
  }
  return connection;
}

export function getD1() {
  return new SQLiteD1Compat(getSQLite());
}
