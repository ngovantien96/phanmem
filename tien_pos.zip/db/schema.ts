import { sql } from "drizzle-orm";
import {
  index,
  integer,
  sqliteTable,
  text,
  uniqueIndex,
} from "drizzle-orm/sqlite-core";

export const products = sqliteTable(
  "products",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    sku: text("sku").notNull().unique(),
    name: text("name").notNull(),
    category: text("category").notNull(),
    brand: text("brand").notNull().default(""),
    description: text("description").notNull().default(""),
    unit: text("unit").notNull().default("Chiếc"),
    warrantyMonths: integer("warranty_months").notNull().default(12),
    tracking: text("tracking", { enum: ["serial", "quantity"] }).notNull(),
    cost: integer("cost").notNull().default(0),
    price: integer("price").notNull(),
    stock: integer("stock").notNull().default(0),
    minStock: integer("min_stock").notNull().default(0),
    active: integer("active", { mode: "boolean" }).notNull().default(true),
    createdAt: text("created_at")
      .notNull()
      .default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [index("products_created_at_idx").on(table.createdAt)],
);

export const productOptions = sqliteTable(
  "product_options",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    type: text("type", { enum: ["category", "brand"] }).notNull(),
    name: text("name").notNull(),
    createdAt: text("created_at")
      .notNull()
      .default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    uniqueIndex("product_options_type_name_idx").on(table.type, table.name),
  ],
);

export const serials = sqliteTable("serials", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  productId: integer("product_id")
    .notNull()
    .references(() => products.id),
  serial: text("serial").notNull().unique(),
  status: text("status", { enum: ["available", "sold", "warranty"] })
    .notNull()
    .default("available"),
  orderId: text("order_id"),
  createdAt: text("created_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("serials_product_status_idx").on(table.productId, table.status),
  index("serials_order_idx").on(table.orderId),
]);

export const customers = sqliteTable("customers", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull().default(""),
  email: text("email").notNull().default(""),
  address: text("address").notNull().default(""),
  createdAt: text("created_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
});

export const orders = sqliteTable("orders", {
  id: text("id").primaryKey(),
  code: text("code").notNull().unique(),
  customerId: text("customer_id").references(() => customers.id),
  customerName: text("customer_name").notNull().default("Khách lẻ"),
  subtotal: integer("subtotal").notNull(),
  discount: integer("discount").notNull().default(0),
  total: integer("total").notNull(),
  paid: integer("paid").notNull().default(0),
  refunded: integer("refunded").notNull().default(0),
  paymentMethod: text("payment_method", { enum: ["cash", "transfer", "card"] })
    .notNull()
    .default("cash"),
  status: text("status", {
    enum: ["completed", "processing", "pending", "cancelled"],
  })
    .notNull()
    .default("completed"),
  channel: text("channel", { enum: ["pos", "online"] })
    .notNull()
    .default("pos"),
  shippingAddress: text("shipping_address").notNull().default(""),
  note: text("note").notNull().default(""),
  cancellationReason: text("cancellation_reason").notNull().default(""),
  cancelledAt: text("cancelled_at"),
  createdAt: text("created_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("orders_created_at_idx").on(table.createdAt),
  index("orders_status_created_at_idx").on(table.status, table.createdAt),
  index("orders_customer_idx").on(table.customerId),
]);

export const orderItems = sqliteTable("order_items", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  orderId: text("order_id")
    .notNull()
    .references(() => orders.id),
  productId: integer("product_id")
    .notNull()
    .references(() => products.id),
  productName: text("product_name").notNull(),
  sku: text("sku").notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: integer("unit_price").notNull(),
  unitCost: integer("unit_cost").notNull(),
  discount: integer("discount").notNull().default(0),
  note: text("note").notNull().default(""),
  serialsJson: text("serials_json").notNull().default("[]"),
}, (table) => [
  index("order_items_order_idx").on(table.orderId),
  index("order_items_product_idx").on(table.productId),
]);

export const cashTransactions = sqliteTable("cash_transactions", {
  id: text("id").primaryKey(),
  type: text("type", { enum: ["income", "expense"] }).notNull(),
  category: text("category").notNull(),
  note: text("note").notNull().default(""),
  amount: integer("amount").notNull(),
  expectedAmount: integer("expected_amount").notNull().default(0),
  paymentMethod: text("payment_method", { enum: ["cash", "transfer"] })
    .notNull()
    .default("cash"),
  status: text("status", {
    enum: ["completed", "pending", "partial", "deferred"],
  })
    .notNull()
    .default("completed"),
  partnerType: text("partner_type", { enum: ["customer", "supplier"] }),
  partnerName: text("partner_name").notNull().default(""),
  reference: text("reference").notNull().default(""),
  sourceType: text("source_type").notNull().default(""),
  sourceId: text("source_id").notNull().default(""),
  settledAt: text("settled_at"),
  orderId: text("order_id").references(() => orders.id),
  createdAt: text("created_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("cash_transactions_created_at_idx").on(table.createdAt),
  index("cash_transactions_order_idx").on(table.orderId),
  index("cash_transactions_status_idx").on(table.status),
  index("cash_transactions_source_idx").on(table.sourceType, table.sourceId),
]);

export const suppliers = sqliteTable("suppliers", {
  id: text("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  phone: text("phone").notNull().default(""),
  email: text("email").notNull().default(""),
  address: text("address").notNull().default(""),
  createdAt: text("created_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
});

export const purchases = sqliteTable("purchases", {
  id: text("id").primaryKey(),
  code: text("code").notNull().unique(),
  supplierId: text("supplier_id").references(() => suppliers.id),
  supplierName: text("supplier_name").notNull(),
  subtotal: integer("subtotal").notNull().default(0),
  discount: integer("discount").notNull().default(0),
  otherCosts: integer("other_costs").notNull().default(0),
  tax: integer("tax").notNull().default(0),
  taxRate: integer("tax_rate").notNull().default(0),
  total: integer("total").notNull(),
  paid: integer("paid").notNull().default(0),
  status: text("status", {
    enum: ["completed", "partial", "unpaid", "purchase_returned"],
  })
    .notNull()
    .default("completed"),
  note: text("note").notNull().default(""),
  tags: text("tags").notNull().default(""),
  costsJson: text("costs_json").notNull().default("[]"),
  receivedAt: text("received_at"),
  returnedAmount: integer("returned_amount").notNull().default(0),
  returnReason: text("return_reason").notNull().default(""),
  returnedAt: text("returned_at"),
  createdAt: text("created_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("purchases_created_at_idx").on(table.createdAt),
  index("purchases_supplier_idx").on(table.supplierId),
]);

export const purchaseReturns = sqliteTable(
  "purchase_returns",
  {
    id: text("id").primaryKey(),
    purchaseId: text("purchase_id")
      .notNull()
      .references(() => purchases.id),
    purchaseCode: text("purchase_code").notNull(),
    supplierName: text("supplier_name").notNull(),
    amount: integer("amount").notNull().default(0),
    reason: text("reason").notNull(),
    createdAt: text("created_at")
      .notNull()
      .default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    uniqueIndex("purchase_returns_purchase_idx").on(table.purchaseId),
    index("purchase_returns_created_at_idx").on(table.createdAt),
  ],
);

export const purchaseItems = sqliteTable("purchase_items", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  purchaseId: text("purchase_id")
    .notNull()
    .references(() => purchases.id),
  productId: integer("product_id")
    .notNull()
    .references(() => products.id),
  productName: text("product_name").notNull(),
  quantity: integer("quantity").notNull(),
  unitCost: integer("unit_cost").notNull(),
  discount: integer("discount").notNull().default(0),
  note: text("note").notNull().default(""),
  serialsJson: text("serials_json").notNull().default("[]"),
}, (table) => [
  index("purchase_items_purchase_idx").on(table.purchaseId),
  index("purchase_items_product_idx").on(table.productId),
]);

export const inventoryMovements = sqliteTable("inventory_movements", {
  id: text("id").primaryKey(),
  productId: integer("product_id")
    .notNull()
    .references(() => products.id),
  productName: text("product_name").notNull(),
  type: text("type", {
    enum: ["purchase", "sale", "return", "purchase_return", "adjustment"],
  }).notNull(),
  quantity: integer("quantity").notNull(),
  reference: text("reference").notNull().default(""),
  note: text("note").notNull().default(""),
  createdAt: text("created_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("inventory_movements_created_at_idx").on(table.createdAt),
  index("inventory_movements_product_idx").on(table.productId),
]);

export const returns = sqliteTable("returns", {
  id: text("id").primaryKey(),
  code: text("code").notNull().unique(),
  orderId: text("order_id")
    .notNull()
    .references(() => orders.id),
  orderCode: text("order_code").notNull(),
  customerName: text("customer_name").notNull(),
  amount: integer("amount").notNull(),
  reason: text("reason").notNull(),
  itemsJson: text("items_json").notNull().default("[]"),
  status: text("status", { enum: ["completed", "pending"] })
    .notNull()
    .default("completed"),
  createdAt: text("created_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("returns_created_at_idx").on(table.createdAt),
  index("returns_order_idx").on(table.orderId),
]);

export const warranties = sqliteTable("warranties", {
  id: text("id").primaryKey(),
  code: text("code").notNull().unique(),
  customerName: text("customer_name").notNull(),
  phone: text("phone").notNull().default(""),
  productName: text("product_name").notNull(),
  serial: text("serial").notNull().default(""),
  issue: text("issue").notNull(),
  status: text("status", {
    enum: ["received", "processing", "waiting", "completed", "returned"],
  })
    .notNull()
    .default("received"),
  expectedAt: text("expected_at").notNull().default(""),
  note: text("note").notNull().default(""),
  createdAt: text("created_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("warranties_updated_at_idx").on(table.updatedAt),
  index("warranties_status_idx").on(table.status),
  index("warranties_serial_idx").on(table.serial),
]);

export const debts = sqliteTable("debts", {
  id: text("id").primaryKey(),
  partnerType: text("partner_type", {
    enum: ["customer", "supplier"],
  }).notNull(),
  partnerName: text("partner_name").notNull(),
  reference: text("reference").notNull().default(""),
  total: integer("total").notNull(),
  paid: integer("paid").notNull().default(0),
  dueDate: text("due_date").notNull().default(""),
  status: text("status", { enum: ["open", "partial", "paid"] })
    .notNull()
    .default("open"),
  settlementType: text("settlement_type", {
    enum: ["income", "expense"],
  })
    .notNull()
    .default("income"),
  sourceTransactionId: text("source_transaction_id").notNull().default(""),
  createdAt: text("created_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("debts_created_at_idx").on(table.createdAt),
  index("debts_status_partner_idx").on(table.status, table.partnerType),
  index("debts_source_transaction_idx").on(table.sourceTransactionId),
]);

export const storeSettings = sqliteTable("store_settings", {
  id: integer("id").primaryKey(),
  storeName: text("store_name").notNull().default("Tiến Computer"),
  phone: text("phone").notNull().default(""),
  address: text("address").notNull().default(""),
  taxCode: text("tax_code").notNull().default(""),
  receiptFooter: text("receipt_footer").notNull().default("Cảm ơn quý khách!"),
  allowNegativeStock: integer("allow_negative_stock", { mode: "boolean" })
    .notNull()
    .default(false),
  autoPrint: integer("auto_print", { mode: "boolean" })
    .notNull()
    .default(false),
  lowStockAlert: integer("low_stock_alert", { mode: "boolean" })
    .notNull()
    .default(true),
  updatedAt: text("updated_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
});
