# Tiến Computer POS — bản VPS + SQLite

Đây là bản chạy độc lập trên Ubuntu/VPS, không dùng Cloudflare D1, Vinext hoặc
Cloudflare Worker.  Ứng dụng là Next.js, Nginx làm reverse proxy, dữ liệu nằm
trong một file SQLite tại `data/sales.db`.

## Yêu cầu

- Ubuntu 22.04/24.04, Nginx và Node.js 22 LTS hoặc mới hơn.
- Dùng một thư mục riêng, ví dụ `/var/www/tien-computer-pos`.
- Node chỉ lắng nghe `127.0.0.1:3000`; không mở cổng 3000 ra Internet.

## Cài lần đầu

```bash
cd /var/www/tien-computer-pos
cp .env.example .env
npm ci
set -a && . ./.env && set +a
npm run migrate
npm run build
sudo chown -R www-data:www-data data
sudo cp deploy/tien-computer-pos.service /etc/systemd/system/
sudo cp deploy/nginx.conf /etc/nginx/sites-available/tien-computer-pos
sudo ln -s /etc/nginx/sites-available/tien-computer-pos /etc/nginx/sites-enabled/tien-computer-pos
sudo nginx -t && sudo systemctl reload nginx
sudo systemctl daemon-reload
sudo systemctl enable --now tien-computer-pos
```

Sửa `server_name _;` trong `deploy/nginx.conf` thành tên miền trước khi bật
HTTPS. Sau đó có thể dùng Certbot để cấp chứng chỉ.

## Nâng cấp hoặc thay source trên VPS

Không ghi đè database. Luôn sao lưu trước:

```bash
sudo systemctl stop tien-computer-pos
cp /var/www/tien-computer-pos/data/sales.db /var/backups/tien-pos-$(date +%F-%H%M).db
# chép source mới đè lên, nhưng giữ nguyên thư mục data/
cd /var/www/tien-computer-pos
npm ci
set -a && . ./.env && set +a
npm run migrate
npm run build
sudo chown -R www-data:www-data data
sudo systemctl start tien-computer-pos
```

`npm run migrate` chỉ chạy các migration chưa có trong bảng
`__tien_migrations`; không xóa dữ liệu.

## Sao lưu hằng ngày

SQLite dùng WAL, vì vậy hãy tạo bản backup nhất quán bằng lệnh sau thay vì chỉ
copy riêng file `.db` khi app đang chạy:

```bash
sqlite3 /var/www/tien-computer-pos/data/sales.db ".backup '/var/backups/tien-pos-$(date +%F).db'"
```

Giữ cả thư mục `data/` có quyền ghi cho `www-data`; nếu không ứng dụng sẽ báo
`SQLITE_READONLY_DIRECTORY`.
