ALTER TABLE `warranties` ADD `service_type` text DEFAULT 'warranty' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `source_type` text DEFAULT 'manual' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `customer_id` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `order_id` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `order_code` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `product_id` integer;--> statement-breakpoint
ALTER TABLE `warranties` ADD `product_sku` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `brand` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `model` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `sold_at` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `warranty_months` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `warranty_until` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `coverage_status` text DEFAULT 'unknown' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `sale_note` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `priority` text DEFAULT 'normal' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `accessories` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `received_condition` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `diagnosis` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `resolution` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `technician` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `estimated_cost` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `final_cost` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `completed_at` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `warranties` ADD `returned_at` text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE INDEX `warranties_service_type_idx` ON `warranties` (`service_type`);--> statement-breakpoint
CREATE INDEX `warranties_phone_idx` ON `warranties` (`phone`);--> statement-breakpoint
CREATE INDEX `warranties_order_id_idx` ON `warranties` (`order_id`);
