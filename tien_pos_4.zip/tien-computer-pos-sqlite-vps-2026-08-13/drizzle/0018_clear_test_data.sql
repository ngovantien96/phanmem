-- Clear all operational data so the store can be tested from a clean state.
-- Store settings remain intact.
DELETE FROM `cash_transactions`;--> statement-breakpoint
DELETE FROM `returns`;--> statement-breakpoint
DELETE FROM `purchase_returns`;--> statement-breakpoint
DELETE FROM `order_items`;--> statement-breakpoint
DELETE FROM `purchase_items`;--> statement-breakpoint
DELETE FROM `inventory_movements`;--> statement-breakpoint
DELETE FROM `serials`;--> statement-breakpoint
DELETE FROM `debts`;--> statement-breakpoint
DELETE FROM `warranties`;--> statement-breakpoint
DELETE FROM `orders`;--> statement-breakpoint
DELETE FROM `purchases`;--> statement-breakpoint
DELETE FROM `customers`;--> statement-breakpoint
DELETE FROM `suppliers`;--> statement-breakpoint
DELETE FROM `products`;--> statement-breakpoint
DELETE FROM `product_options`;--> statement-breakpoint
UPDATE `code_counters` SET `last_value` = 0;
