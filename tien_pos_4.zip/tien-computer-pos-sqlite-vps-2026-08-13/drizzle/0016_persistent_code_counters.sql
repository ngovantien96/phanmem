-- Codes are business identifiers.  They have a dedicated counter so a deleted
-- record never makes its old number available again.
CREATE TABLE `code_counters` (
  `kind` text PRIMARY KEY NOT NULL,
  `last_value` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint

INSERT INTO `code_counters` (`kind`, `last_value`) VALUES
  ('customer', 0),
  ('supplier', 0),
  ('product', 0),
  ('order', 0),
  ('purchase', 0),
  ('return', 0),
  ('warranty', 0);
--> statement-breakpoint

-- Start each counter at the highest code already issued before this upgrade.
UPDATE `code_counters`
SET `last_value` = MAX(`last_value`, COALESCE((
  SELECT MAX(CAST(SUBSTR(`id`, 3) AS INTEGER))
  FROM `customers`
  WHERE `id` GLOB 'KH[0-9]*'
), 0))
WHERE `kind` = 'customer';
--> statement-breakpoint
UPDATE `code_counters`
SET `last_value` = MAX(`last_value`, COALESCE((
  SELECT MAX(CAST(SUBSTR(`code`, 3) AS INTEGER))
  FROM `suppliers`
  WHERE `code` GLOB 'NC[0-9]*'
), 0))
WHERE `kind` = 'supplier';
--> statement-breakpoint
UPDATE `code_counters`
SET `last_value` = MAX(`last_value`, COALESCE((
  SELECT MAX(CAST(SUBSTR(`sku`, 3) AS INTEGER))
  FROM `products`
  WHERE `sku` GLOB 'SP[0-9]*'
), 0))
WHERE `kind` = 'product';
--> statement-breakpoint
UPDATE `code_counters`
SET `last_value` = MAX(`last_value`, COALESCE((
  SELECT MAX(CAST(SUBSTR(`code`, 3) AS INTEGER))
  FROM `orders`
  WHERE `code` GLOB 'DH[0-9]*'
), 0))
WHERE `kind` = 'order';
--> statement-breakpoint
UPDATE `code_counters`
SET `last_value` = MAX(`last_value`, COALESCE((
  SELECT MAX(CAST(SUBSTR(`code`, 3) AS INTEGER))
  FROM `purchases`
  WHERE `code` GLOB 'PN[0-9]*'
), 0))
WHERE `kind` = 'purchase';
--> statement-breakpoint
UPDATE `code_counters`
SET `last_value` = MAX(`last_value`, COALESCE((
  SELECT MAX(CAST(SUBSTR(`code`, 3) AS INTEGER))
  FROM `returns`
  WHERE `code` GLOB 'TH[0-9]*'
), 0))
WHERE `kind` = 'return';
--> statement-breakpoint
UPDATE `code_counters`
SET `last_value` = MAX(`last_value`, COALESCE((
  SELECT MAX(CAST(SUBSTR(`code`, 3) AS INTEGER))
  FROM `warranties`
  WHERE `code` GLOB 'BH[0-9]*'
), 0))
WHERE `kind` = 'warranty';
