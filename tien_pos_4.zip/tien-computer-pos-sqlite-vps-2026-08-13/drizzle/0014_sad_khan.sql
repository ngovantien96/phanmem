ALTER TABLE `purchase_returns` ADD `paid` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `returns` ADD `paid` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
-- Phiếu đổi trả cũ luôn đã ghi phiếu chi ngay khi tạo.
UPDATE `returns` SET `paid` = `amount`;--> statement-breakpoint
-- Phiếu hoàn trả NCC cũ chỉ được xem là đã thu khi khoản thu đã được xác nhận.
UPDATE `purchase_returns`
SET `paid` = COALESCE((
  SELECT SUM(`amount`) FROM `cash_transactions`
  WHERE `source_type` = 'purchase_return'
    AND `source_id` = `purchase_returns`.`purchase_id`
    AND `status` = 'completed'
), 0);
