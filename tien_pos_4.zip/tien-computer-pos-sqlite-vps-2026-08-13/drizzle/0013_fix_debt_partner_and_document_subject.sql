-- Historical purchase debts were created without settlement_type and therefore
-- inherited the old default "income".  The partner type is authoritative:
-- suppliers are payables, customers are receivables.
UPDATE `debts`
SET `settlement_type` = CASE
  WHEN `partner_type` = 'supplier' THEN 'expense'
  ELSE 'income'
END
WHERE (`partner_type` = 'supplier' AND `settlement_type` <> 'expense')
   OR (`partner_type` = 'customer' AND `settlement_type` <> 'income');
--> statement-breakpoint

-- Documents must be associated with a real counterparty even when an API is
-- called directly instead of through the web form.
CREATE TRIGGER `orders_require_customer_on_insert`
BEFORE INSERT ON `orders`
WHEN NEW.`customer_id` IS NULL
  OR NOT EXISTS (SELECT 1 FROM `customers` WHERE `id` = NEW.`customer_id`)
BEGIN
  SELECT RAISE(ABORT, 'Đơn bán phải có khách hàng hợp lệ');
END;
--> statement-breakpoint
CREATE TRIGGER `orders_require_customer_on_subject_update`
BEFORE UPDATE OF `customer_id` ON `orders`
WHEN NEW.`customer_id` IS NULL
  OR NOT EXISTS (SELECT 1 FROM `customers` WHERE `id` = NEW.`customer_id`)
BEGIN
  SELECT RAISE(ABORT, 'Đơn bán phải có khách hàng hợp lệ');
END;
--> statement-breakpoint
CREATE TRIGGER `purchases_require_supplier_on_insert`
BEFORE INSERT ON `purchases`
WHEN NEW.`supplier_id` IS NULL
  OR NOT EXISTS (SELECT 1 FROM `suppliers` WHERE `id` = NEW.`supplier_id`)
BEGIN
  SELECT RAISE(ABORT, 'Phiếu nhập phải có nhà cung cấp hợp lệ');
END;
--> statement-breakpoint
CREATE TRIGGER `purchases_require_supplier_on_subject_update`
BEFORE UPDATE OF `supplier_id` ON `purchases`
WHEN NEW.`supplier_id` IS NULL
  OR NOT EXISTS (SELECT 1 FROM `suppliers` WHERE `id` = NEW.`supplier_id`)
BEGIN
  SELECT RAISE(ABORT, 'Phiếu nhập phải có nhà cung cấp hợp lệ');
END;
