-- Customer IDs are used internally by orders. Keep them stable and store the
-- visible customer code separately, so correcting a code never rewrites order
-- history or changes a customer's identity.
ALTER TABLE `customers` ADD `code` text DEFAULT '' NOT NULL;
--> statement-breakpoint

-- Existing customers are assigned in their original insertion order. This
-- replaces the former screen-only row number that changed whenever the list
-- was sorted or a customer was added.
WITH ranked AS (
  SELECT `id`, ROW_NUMBER() OVER (ORDER BY `rowid`) AS `number`
  FROM `customers`
)
UPDATE `customers`
SET `code` = 'KH' || printf('%04d', (
  SELECT `number` FROM ranked WHERE ranked.`id` = customers.`id`
));
--> statement-breakpoint

CREATE UNIQUE INDEX `customers_code_unique` ON `customers` (`code`);
--> statement-breakpoint

UPDATE `code_counters`
SET `last_value` = MAX(`last_value`, COALESCE((
  SELECT MAX(CAST(SUBSTR(`code`, 3) AS INTEGER))
  FROM `customers`
  WHERE `code` GLOB 'KH[0-9]*'
), 0))
WHERE `kind` = 'customer';
