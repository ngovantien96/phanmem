"use client";

import type { Customer, Settings, Warranty } from "./types";

const escapeHtml = (value: unknown) => String(value ?? "")
  .replaceAll("&", "&amp;")
  .replaceAll("<", "&lt;")
  .replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;")
  .replaceAll("'", "&#039;");

const formatPrintDate = (value: string) => {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "—"
    : new Intl.DateTimeFormat("vi-VN", {
      day: "2-digit", month: "2-digit", year: "numeric",
    }).format(date);
};

const formatPrintMoney = (value: number) => new Intl.NumberFormat("vi-VN")
  .format(Math.max(0, Math.round(value || 0)));

const formatPrintCost = (value: number) => value > 0
  ? `${formatPrintMoney(value)}đ`
  : "—";

const statusText = (status: string) => ({
  received: "Đã tiếp nhận",
  diagnosing: "Đang chẩn đoán",
  waiting_customer: "Chờ khách xác nhận",
  waiting_parts: "Chờ linh kiện",
  repairing: "Đang sửa chữa",
  completed: "Đã hoàn tất",
  returned: "Đã trả khách",
  cancelled: "Đã hủy",
} as Record<string, string>)[status] || status;

const coverageText = (coverage: string) => coverage === "in_warranty"
  ? "Còn bảo hành"
  : coverage === "out_of_warranty" ? "Hết bảo hành" : "Chưa xác định";

const priorityText = (priority: string) => priority === "urgent"
  ? "Khẩn"
  : priority === "high" ? "Cao" : "Bình thường";

export function printWarrantyReceipt(
  settings: Settings,
  warranty: Warranty,
  customer?: Customer | null,
) {
  const popup = window.open("", "_blank", "width=900,height=1100");
  if (!popup) return false;
  const saleInfo = warranty.orderCode
    ? `Đơn ${warranty.orderCode}${warranty.soldAt ? ` · Bán ${formatPrintDate(warranty.soldAt)}` : ""}`
    : "Máy nhận ngoài hệ thống";
  const warrantyInfo = warranty.warrantyUntil
    ? `${coverageText(warranty.coverageStatus)} · đến ${formatPrintDate(warranty.warrantyUntil)}`
    : warranty.warrantyMonths > 0
      ? `${warranty.warrantyMonths} tháng · ${coverageText(warranty.coverageStatus)}`
      : coverageText(warranty.coverageStatus);
  const processRows = [
    ["Kỹ thuật viên", warranty.technician],
    ["Chẩn đoán", warranty.diagnosis],
    ["Phương án / kết quả xử lý", warranty.resolution],
  ].filter(([, value]) => value);
  popup.opener = null;
  popup.document.open();
  popup.document.write(`<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>${escapeHtml(warranty.code)}</title><style>
    @page{size:A4 portrait;margin:10mm 11mm 12mm}*{box-sizing:border-box}html,body{margin:0;padding:0;color:#111;font-family:"Times New Roman",serif;font-size:13px}.page{width:100%;max-width:188mm;margin:0 auto}.top{display:grid;grid-template-columns:1fr 1fr;gap:28px;padding-bottom:14px;border-bottom:1px solid #777}.store b{font-size:15px}.store p,.ticket-meta p{margin:3px 0;line-height:1.35}.ticket-meta{text-align:right}.ticket-meta strong{font-size:14px}.title{text-align:center;font-size:22px;font-weight:700;margin:20px 0 5px;text-transform:uppercase}.subtitle{text-align:center;margin:0 0 24px;font-style:italic}.section-title{margin:17px 0 7px;font-size:14px;font-weight:700;text-transform:uppercase}.info{display:grid;grid-template-columns:125px 1fr;gap:7px 5px;margin:0 0 17px}.info b{font-weight:700}.info span{min-height:18px;white-space:pre-wrap}table{width:100%;border-collapse:collapse;font-size:12px;table-layout:fixed}th,td{border:1px solid #777;padding:7px 8px;vertical-align:top;overflow-wrap:anywhere}th{width:28%;text-align:left;font-weight:700;background:#f5f5f5}.muted{color:#444}.device-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.device-grid table th{width:43%}.intake-grid{display:grid;grid-template-columns:1fr 1fr;border-top:1px solid #777;border-left:1px solid #777}.intake-item{min-height:66px;border-right:1px solid #777;border-bottom:1px solid #777;padding:8px}.intake-item b,.intake-item span{display:block}.intake-item b{margin-bottom:5px;font-size:12px}.intake-item span{line-height:1.4;white-space:pre-wrap}.two-col{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px}.two-col table th{width:47%}.notes{margin-top:18px;white-space:pre-line;line-height:1.45}.notes h3{font-size:14px;margin:0 0 4px;text-transform:uppercase}.signatures{display:grid;grid-template-columns:repeat(3,1fr);text-align:center;margin-top:30px;gap:18px}.signatures b,.signatures i{display:block}.signatures i{font-weight:400;margin-top:3px}.sign-space{height:76px}.footer{text-align:center;margin-top:8px;font-style:italic}.print{position:fixed;right:16px;top:16px;padding:9px 14px;border:0;border-radius:6px;background:#0b5cab;color:#fff;font:600 14px Arial;cursor:pointer}@media print{.print{display:none}.page{max-width:none;margin:0}}
  </style></head><body><button class="print" onclick="window.print()">In phiếu A4</button><main class="page"><section class="top"><div class="store"><b>${escapeHtml(settings.storeName)}</b>${settings.address ? `<p>${escapeHtml(settings.address)}</p>` : ""}${settings.phone ? `<p><b>Hotline:</b> ${escapeHtml(settings.phone)}</p>` : ""}${settings.taxCode ? `<p>MST: ${escapeHtml(settings.taxCode)}</p>` : ""}</div><div class="ticket-meta"><p>Mã phiếu: <strong>${escapeHtml(warranty.code)}</strong></p><p>Ngày tiếp nhận: <strong>${formatPrintDate(warranty.createdAt)}</strong></p><p>Loại dịch vụ: <strong>${warranty.serviceType === "repair" ? "Sửa chữa" : "Bảo hành"}</strong></p></div></section><h1 class="title">PHIẾU TIẾP NHẬN BẢO HÀNH – SỬA CHỮA</h1><p class="subtitle">Vui lòng mang theo phiếu khi nhận lại thiết bị</p><h2 class="section-title">1. Thông tin khách hàng</h2><section class="info"><b>Khách hàng:</b><span>${escapeHtml(warranty.customerName || "Khách lẻ")}</span><b>Điện thoại:</b><span>${escapeHtml(warranty.phone || "—")}</span><b>Địa chỉ:</b><span>${escapeHtml(customer?.address || "—")}</span></section><h2 class="section-title">2. Thông tin thiết bị</h2><section class="device-grid"><table><tbody><tr><th>Tên thiết bị</th><td>${escapeHtml(warranty.productName)}</td></tr><tr><th>Mã / Hãng / Model</th><td>${escapeHtml([warranty.productSku, warranty.brand, warranty.model].filter(Boolean).join(" · ") || "—")}</td></tr><tr><th>Serial / IMEI</th><td>${escapeHtml(warranty.serial || "Không có serial")}</td></tr></tbody></table><table><tbody><tr><th>Nguồn máy</th><td>${escapeHtml(saleInfo)}</td></tr><tr><th>Thông tin bảo hành</th><td>${escapeHtml(warrantyInfo)}</td></tr>${warranty.saleNote ? `<tr><th>Ghi chú đơn bán</th><td>${escapeHtml(warranty.saleNote)}</td></tr>` : ""}</tbody></table></section><h2 class="section-title">3. Thông tin tiếp nhận</h2><section class="intake-grid"><div class="intake-item"><b>Tình trạng / lỗi khách báo</b><span>${escapeHtml(warranty.issue)}</span></div><div class="intake-item"><b>Ngoại quan khi nhận</b><span>${escapeHtml(warranty.receivedCondition || "Không ghi nhận")}</span></div><div class="intake-item"><b>Phụ kiện nhận kèm</b><span>${escapeHtml(warranty.accessories || "Không có")}</span></div><div class="intake-item"><b>Ngày hẹn trả</b><span>${formatPrintDate(warranty.expectedAt)}</span></div></section><div class="two-col"><table><tbody><tr><th>Trạng thái</th><td>${escapeHtml(statusText(warranty.status))}</td></tr><tr><th>Mức ưu tiên</th><td>${escapeHtml(priorityText(warranty.priority))}</td></tr></tbody></table><table><tbody><tr><th>Chi phí dự kiến</th><td>${formatPrintCost(warranty.estimatedCost)}</td></tr><tr><th>Chi phí thực tế</th><td>${formatPrintCost(warranty.finalCost)}</td></tr></tbody></table></div>${processRows.length ? `<h2 class="section-title">4. Cập nhật kỹ thuật</h2><table><tbody>${processRows.map(([label, value]) => `<tr><th>${escapeHtml(label)}</th><td>${escapeHtml(value)}</td></tr>`).join("")}</tbody></table>` : ""}${warranty.note ? `<section class="notes"><h3>Ghi chú</h3>${escapeHtml(warranty.note)}</section>` : ""}${settings.printRegulations ? `<section class="notes"><h3>Quy định bảo hành</h3>${escapeHtml(settings.printRegulations)}</section>` : ""}<section class="signatures"><div><b>${escapeHtml(settings.printCustomerSigner || "Khách hàng")}</b><i>(Ký, ghi rõ họ tên)</i><div class="sign-space"></div></div><div><b>Nhân viên tiếp nhận</b><i>(Ký, ghi rõ họ tên)</i><div class="sign-space"></div></div><div><b>Kỹ thuật viên</b><i>(Ký, ghi rõ họ tên)</i><div class="sign-space"></div></div></section>${settings.printFooter ? `<p class="footer">${escapeHtml(settings.printFooter)}</p>` : ""}</main><script>window.onload=()=>setTimeout(()=>window.print(),250)</script></body></html>`);
  popup.document.close();
  return true;
}
