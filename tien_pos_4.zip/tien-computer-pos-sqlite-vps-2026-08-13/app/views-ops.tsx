"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Customer,
  Product,
  Purchase,
  ReturnRow,
  Supplier,
  formatDate,
  inventoryValue,
  money,
} from "./types";
import {
  Empty,
  Field,
  Kpi,
  Modal,
  MoneyInput,
  PanelTitle,
  ProductImage,
  SpinnerButton,
  Status,
} from "./ui";
import type { ViewProps } from "./views-main";
import { printWarrantyReceipt } from "./warranty-print";

type QuickProductForm = {
  sku: string;
  name: string;
  category: string;
  brand: string;
  description: string;
  unit: string;
  tracking: "serial" | "quantity";
  cost: string;
  price: string;
  stock: string;
  min: string;
};

type PurchaseDetailItem = {
  id: number;
  productId: number;
  productName: string;
  sku: string;
  unit: string;
  tracking: "serial" | "quantity";
  quantity: number;
  unitCost: number;
  discount: number;
  note: string;
  serialsJson: string;
};

type PurchaseDetail = {
  purchase: {
    supplierId?: string;
    supplierName?: string;
    subtotal: number;
    discount: number;
    otherCosts: number;
    tax: number;
    taxRate: number;
    total: number;
    note?: string;
    tags?: string;
    costsJson?: string;
    receivedAt?: string;
    returnedAmount?: number;
    returnReason?: string;
    returnedAt?: string | null;
    createdAt: string;
  };
  items: PurchaseDetailItem[];
  payments: Array<{
    id: string;
    amount: number;
    method: "cash" | "transfer";
  }>;
};

const freshQuickProduct = (name = ""): QuickProductForm => ({
  sku: "",
  name,
  category: "Laptop",
  brand: "",
  description: "",
  unit: "Chiếc",
  tracking: "serial",
  cost: "",
  price: "",
  stock: "",
  min: "0",
});

const toDateTimeLocalValue = (value?: string) => {
  const normalized = value
    ? /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(value)
      ? `${value.replace(" ", "T")}Z`
      : value
    : undefined;
  const date = normalized ? new Date(normalized) : new Date();
  const safeDate = Number.isNaN(date.getTime()) ? new Date() : date;
  return new Date(safeDate.getTime() - safeDate.getTimezoneOffset() * 60_000)
    .toISOString()
    .slice(0, 16);
};

export function Purchases(p: ViewProps) {
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [detailBusy, setDetailBusy] = useState<string | null>(null);
  const [details, setDetails] = useState<Record<string, PurchaseDetail>>({});
  const [busy, setBusy] = useState(false);
  const [supplierId, setSupplierId] = useState("");
  const [supplierQuery, setSupplierQuery] = useState("");
  const [supplierResultsOpen, setSupplierResultsOpen] = useState(false);
  const supplierPickerRef = useRef<HTMLDivElement>(null);
  const [supplierFormOpen, setSupplierFormOpen] = useState(false);
  const [dueDate, setDueDate] = useState("");
  const [receivedAt, setReceivedAt] = useState("");
  const [note, setNote] = useState("");
  const [tags, setTags] = useState("");
  const [productQuery, setProductQuery] = useState("");
  const [productResultsOpen, setProductResultsOpen] = useState(false);
  const productPickerRef = useRef<HTMLElement>(null);
  const [quickProductForm, setQuickProductForm] =
    useState<QuickProductForm | null>(null);
  const [quickProductBusy, setQuickProductBusy] = useState(false);
  const [quickProductError, setQuickProductError] = useState("");
  const [quickOptionType, setQuickOptionType] = useState<
    "category" | "brand" | null
  >(null);
  const [quickOptionName, setQuickOptionName] = useState("");
  const [quickOptionBusy, setQuickOptionBusy] = useState(false);
  const [returningPurchase, setReturningPurchase] = useState<Purchase | null>(
    null,
  );
  const [purchaseReturnReason, setPurchaseReturnReason] = useState("");
  const [purchaseReturnReceived, setPurchaseReturnReceived] = useState(0);
  const [purchaseReturnMethod, setPurchaseReturnMethod] = useState<"cash" | "transfer">("transfer");
  const [purchaseReturnBusy, setPurchaseReturnBusy] = useState(false);
  const [paymentPurchase, setPaymentPurchase] = useState<Purchase | null>(null);
  const [purchasePaymentAmount, setPurchasePaymentAmount] = useState(0);
  const [purchasePaymentMethod, setPurchasePaymentMethod] = useState<"cash" | "transfer">("transfer");
  const [purchasePaymentBusy, setPurchasePaymentBusy] = useState(false);
  const [receiptPurchase, setReceiptPurchase] = useState<Purchase | null>(null);
  const [purchaseReceiptAmount, setPurchaseReceiptAmount] = useState(0);
  const [purchaseReceiptMethod, setPurchaseReceiptMethod] = useState<"cash" | "transfer">("transfer");
  const [purchaseReceiptBusy, setPurchaseReceiptBusy] = useState(false);
  const [localProductOptions, setLocalProductOptions] = useState(
    p.data.productOptions,
  );
  const [splitLines, setSplitLines] = useState(false);
  const [multiSelect, setMultiSelect] = useState(false);
  const [selectedProductIds, setSelectedProductIds] = useState<number[]>([]);
  const [taxRate, setTaxRate] = useState(0);
  const [costs, setCosts] = useState<
    Array<{ id: string; name: string; amount: number }>
  >([]);
  const [payments, setPayments] = useState<
    Array<{ id: string; amount: number; method: "cash" | "transfer" }>
  >([]);
  const [items, setItems] = useState<
    Array<{
      rowId: string;
      productId: number;
      sku: string;
      name: string;
      imageKey: string;
      unit: string;
      tracking: "serial" | "quantity";
      quantity: number;
      cost: number;
      discount: number;
      note: string;
      serials: string[];
    }>
  >([]);
  const [serialDrafts, setSerialDrafts] = useState<Record<string, string>>({});
  const serialInputRefs = useRef<Record<string, HTMLInputElement | null>>({});
  const focusSerialInput = (rowId: string) => {
    requestAnimationFrame(() => serialInputRefs.current[rowId]?.focus());
  };
  const addProduct = (product: Product) => {
    let serialRowToFocus: string | null = null;
    setItems((current) => {
      const existing = !splitLines
        ? current.find((x) => x.productId === product.id)
        : undefined;
      if (existing) {
        if (product.tracking === "serial") serialRowToFocus = existing.rowId;
        else
          return current.map((x) =>
            x.rowId === existing.rowId
              ? { ...x, quantity: x.quantity + 1 }
              : x,
          );
        return current;
      }
      const rowId = crypto.randomUUID();
      if (product.tracking === "serial") serialRowToFocus = rowId;
      return [
        ...current,
        {
          rowId,
          productId: product.id,
          sku: product.sku,
          name: product.name,
          imageKey: product.imageKey || "",
          unit: product.unit || "Chiếc",
          tracking: product.tracking,
          quantity: product.tracking === "serial" ? 0 : 1,
          cost: product.cost,
          discount: 0,
          note: "",
          serials: [],
        },
      ];
    });
    if (serialRowToFocus) focusSerialInput(serialRowToFocus);
    if (!multiSelect) {
      setProductQuery("");
      setProductResultsOpen(false);
    }
  };
  const openQuickProductForm = () => {
    setProductResultsOpen(false);
    setQuickProductError("");
    setQuickProductForm(freshQuickProduct(productQuery.trim()));
  };
  const quickOptionNames = (type: "category" | "brand") => {
    const current = quickProductForm?.[type]
      ? [quickProductForm[type]]
      : [];
    return [
      ...new Set(
        [
          ...p.data.productOptions
            .filter((option) => option.type === type)
            .map((option) => option.name),
          ...localProductOptions
            .filter((option) => option.type === type)
            .map((option) => option.name),
          ...p.data.products.map((product) => product[type]),
          ...current,
        ]
          .map((name) => name.trim())
          .filter(Boolean),
      ),
    ].sort((a, b) =>
      a.localeCompare(b, "vi", { sensitivity: "base" }),
    );
  };
  const saveQuickOption = async () => {
    if (!quickOptionType || !quickOptionName.trim() || !quickProductForm)
      return;
    setQuickOptionBusy(true);
    try {
      const result = await p.api(
        { type: quickOptionType, name: quickOptionName },
        "/api/product-options",
      );
      const option = result.option as {
        id: number;
        type: "category" | "brand";
        name: string;
      };
      setLocalProductOptions((current) =>
        current.some(
          (item) =>
            item.type === option.type &&
            item.name.localeCompare(option.name, "vi", {
              sensitivity: "base",
            }) === 0,
        )
          ? current
          : [...current, option],
      );
      setQuickProductForm({
        ...quickProductForm,
        [quickOptionType]: option.name,
      });
      setQuickOptionType(null);
      setQuickOptionName("");
      p.notify(
        result.created
          ? `Đã thêm ${quickOptionType === "category" ? "nhóm hàng" : "thương hiệu"}.`
          : "Tùy chọn này đã có trong danh sách.",
      );
    } catch (error) {
      p.notify(
        error instanceof Error ? error.message : "Không thể thêm tùy chọn.",
      );
    } finally {
      setQuickOptionBusy(false);
    }
  };
  const saveQuickProduct = async () => {
    if (!quickProductForm) return;
    setQuickProductBusy(true);
    setQuickProductError("");
    try {
      const result = await p.api(
        {
          ...quickProductForm,
          cost: Number(quickProductForm.cost),
          price: Number(quickProductForm.price),
          stock: 0,
          min: 0,
          serials: [],
        },
        "/api/products",
      );
      const created = result.product as Product;
      setQuickProductForm(null);
      addProduct({ ...created, active: true });
      await p.reload();
      setProductQuery(created.name);
      setProductResultsOpen(true);
      p.notify(`Đã thêm ${created.name} vào phiếu nhập hiện tại.`);
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Không thể thêm sản phẩm.";
      setQuickProductError(message);
      p.notify(message);
    } finally {
      setQuickProductBusy(false);
    }
  };
  const updateItem = (
    rowId: string,
    patch: Partial<(typeof items)[number]>,
  ) =>
    setItems((current) =>
      current.map((item) =>
        item.rowId === rowId ? { ...item, ...patch } : item,
      ),
    );
  const saveSerial = (rowId: string) => {
    const serial = (serialDrafts[rowId] || "").trim();
    if (!serial) return;
    const duplicate = items.some((item) =>
      item.serials.some(
        (saved) => saved.localeCompare(serial, undefined, { sensitivity: "accent" }) === 0,
      ),
    );
    if (duplicate) {
      p.notify(`Serial/IMEI “${serial}” đã có trong phiếu nhập.`);
      return;
    }
    setItems((current) =>
      current.map((item) => {
        if (item.rowId !== rowId) return item;
        const serials = [...item.serials, serial];
        return { ...item, serials, quantity: serials.length };
      }),
    );
    setSerialDrafts((current) => ({ ...current, [rowId]: "" }));
    focusSerialInput(rowId);
  };
  const removeSerial = (rowId: string, serial: string) =>
    setItems((current) =>
      current.map((item) => {
        if (item.rowId !== rowId) return item;
        const serials = item.serials.filter((value) => value !== serial);
        return { ...item, serials, quantity: serials.length };
      }),
    );
  const matchingProducts = p.data.products
    .filter((product) =>
      `${product.name} ${product.sku} ${product.brand}`
        .toLowerCase()
        .includes(productQuery.trim().toLowerCase()),
    )
    .sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime() ||
        b.id - a.id,
    );
  useEffect(() => {
    const closeSearchResults = (event: PointerEvent) => {
      if (!productPickerRef.current?.contains(event.target as Node)) {
        setProductResultsOpen(false);
      }
      if (!supplierPickerRef.current?.contains(event.target as Node)) {
        setSupplierResultsOpen(false);
      }
    };
    document.addEventListener("pointerdown", closeSearchResults);
    return () => document.removeEventListener("pointerdown", closeSearchResults);
  }, []);
  const subtotal = items.reduce((s, x) => s + x.quantity * x.cost, 0);
  const discount = items.reduce(
    (s, x) => s + Math.min(x.quantity * x.cost, Math.max(0, x.discount)),
    0,
  );
  const otherCosts = costs.reduce((s, x) => s + Math.max(0, x.amount), 0);
  const beforeTax = Math.max(0, subtotal - discount + otherCosts);
  const tax = Math.round((beforeTax * Math.min(100, Math.max(0, taxRate))) / 100);
  const total = beforeTax + tax;
  const paid = payments.reduce((s, x) => s + Math.max(0, x.amount), 0);
  const entryPaymentMethod = payments[0]?.method || "transfer";
  const setEntryPaymentMethod = (method: "cash" | "transfer") => {
    setPayments((current) =>
      current.length
        ? current.map((payment, index) =>
            index === 0 ? { ...payment, method } : payment,
          )
        : [{ id: crypto.randomUUID(), method, amount: 0 }],
    );
  };
  const setPurchasePaidAmount = (amount: number) => {
    setPayments((current) => [
      {
        id: current[0]?.id || crypto.randomUUID(),
        method: current[0]?.method || "transfer",
        amount,
      },
    ]);
  };
  const serialsValid = items.every(
    (item) =>
      item.tracking !== "serial" ||
      (item.quantity > 0 && item.serials.length === item.quantity),
  );
  const selectedSupplier = p.data.suppliers.find((x) => x.id === supplierId);
  const normalizedSupplierQuery = supplierQuery.trim().toLowerCase();
  const matchingSuppliers = p.data.suppliers
    .filter((x) =>
      `${x.name} ${x.phone} ${x.code}`
        .toLowerCase()
        .includes(normalizedSupplierQuery),
    )
    .slice(0, 8);
  const selectSupplier = (supplier: Supplier) => {
    setSupplierId(supplier.id);
    setSupplierQuery(supplier.name);
    setSupplierResultsOpen(false);
  };
  const resetPurchaseForm = () => {
    setEditingId(null);
    setSupplierId("");
    setSupplierQuery("");
    setSupplierResultsOpen(false);
    setDueDate("");
    setReceivedAt(toDateTimeLocalValue());
    setNote("");
    setTags("");
    setProductQuery("");
    setProductResultsOpen(false);
    setQuickProductForm(null);
    setQuickOptionType(null);
    setQuickOptionName("");
    setSplitLines(false);
    setMultiSelect(false);
    setSelectedProductIds([]);
    setTaxRate(0);
    setCosts([]);
    setPayments([]);
    setItems([]);
    setSerialDrafts({});
  };
  const loadDetail = async (id: string) => {
    if (details[id]) return details[id];
    setDetailBusy(id);
    try {
      const response = await fetch(`/api/purchases?id=${encodeURIComponent(id)}`, { cache: "no-store" });
      const result = (await response.json()) as PurchaseDetail & {
        error?: string;
      };
      if (!response.ok) throw new Error(result.error || "Không thể tải chi tiết phiếu nhập");
      setDetails((current) => ({ ...current, [id]: result }));
      return result;
    } finally {
      setDetailBusy(null);
    }
  };
  const toggleDetail = async (id: string) => {
    if (expandedId === id) return setExpandedId(null);
    setExpandedId(id);
    try { await loadDetail(id); } catch (error) {
      setExpandedId(null);
      p.notify(error instanceof Error ? error.message : "Không thể tải chi tiết phiếu nhập");
    }
  };
  useEffect(() => {
    if (p.documentToOpen?.type !== "purchase") return;
    void toggleDetail(p.documentToOpen.id);
    p.consumeDocumentToOpen();
  }, [p.documentToOpen, p.consumeDocumentToOpen]);
  useEffect(() => {
    if (!p.purchaseFormRequested) return;
    resetPurchaseForm();
    setOpen(true);
    p.consumePurchaseFormRequest();
  }, [p.purchaseFormRequested, p.consumePurchaseFormRequest]);
  const editPurchase = async (id: string) => {
    const summary = p.data.purchases.find((purchase) => purchase.id === id);
    if (summary?.status === "purchase_returned") {
      p.notify("Phiếu đã hoàn trả nên không thể sửa.");
      return;
    }
    try {
      const result = await loadDetail(id);
      const purchase = result.purchase;
      setEditingId(id);
      setSupplierId(purchase.supplierId || "");
      setSupplierQuery(purchase.supplierName || "");
      setReceivedAt(
        toDateTimeLocalValue(purchase.receivedAt || purchase.createdAt),
      );
      setNote(purchase.note || "");
      setTags(purchase.tags || "");
      setTaxRate(Number(purchase.taxRate) || 0);
      const parsedCosts = JSON.parse(purchase.costsJson || "[]") as Array<{
        name: string;
        amount: number;
      }>;
      setCosts(parsedCosts.map((x) => ({ ...x, id: crypto.randomUUID() })));
      setPayments((result.payments || []).map((x) => ({ id: crypto.randomUUID(), amount: Number(x.amount), method: x.method === "cash" ? "cash" : "transfer" })));
      setItems((result.items || []).map((x) => ({
        rowId: crypto.randomUUID(), productId: Number(x.productId), sku: x.sku || "", name: x.productName,
        imageKey: p.data.products.find((product) => product.id === Number(x.productId))?.imageKey || "",
        unit: x.unit || "Chiếc", tracking: x.tracking, quantity: Number(x.quantity), cost: Number(x.unitCost),
        discount: Number(x.discount), note: x.note || "", serials: JSON.parse(x.serialsJson || "[]"),
      })));
      setSerialDrafts({});
      setOpen(true);
    } catch (error) {
      p.notify(error instanceof Error ? error.message : "Không thể mở phiếu nhập");
    }
  };
  const save = async () => {
    setBusy(true);
    try {
      const supplier = p.data.suppliers.find((x) => x.id === supplierId);
      const result = await p.api({
        action: editingId ? "purchase-update" : "purchase",
        purchaseId: editingId,
        supplierId,
        supplierName: supplier?.name || "Nhà cung cấp lẻ",
        payments,
        costs,
        taxRate,
        receivedAt: new Date(receivedAt).toISOString(),
        dueDate,
        note,
        tags,
        items,
      });
      setOpen(false);
      resetPurchaseForm();
      p.notify(editingId ? `Đã cập nhật phiếu nhập ${result.code}.` : `Đã hoàn tất phiếu nhập ${result.code}. Tồn kho và công nợ đã cập nhật.`);
      setDetails({});
      await p.reload();
    } catch (error) {
      p.notify(error instanceof Error ? error.message : "Không thể lưu phiếu nhập");
    } finally {
      setBusy(false);
    }
  };
  const openPurchaseReturn = (purchase: Purchase) => {
    setReturningPurchase(purchase);
    setPurchaseReturnReason("Hoàn trả hàng cho nhà cung cấp");
    setPurchaseReturnReceived(Math.max(0, purchase.paid));
    setPurchaseReturnMethod("transfer");
  };
  const openPurchasePayment = (purchase: Purchase) => {
    setPaymentPurchase(purchase);
    setPurchasePaymentAmount(Math.max(0, purchase.total - purchase.paid));
    setPurchasePaymentMethod("transfer");
  };
  const addPurchasePayment = async () => {
    if (!paymentPurchase || purchasePaymentBusy) return;
    const remaining = Math.max(0, paymentPurchase.total - paymentPurchase.paid);
    if (!purchasePaymentAmount || purchasePaymentAmount > remaining) {
      p.notify("Số tiền trả thêm phải lớn hơn 0 và không vượt quá số còn phải trả.");
      return;
    }
    setPurchasePaymentBusy(true);
    try {
      const result = await p.api({ action: "purchase-payment", purchaseId: paymentPurchase.id, paymentAmount: purchasePaymentAmount, paymentMethod: purchasePaymentMethod });
      if (result.ok !== true) throw new Error("Không thể ghi nhận thanh toán thêm.");
      p.notify(`Đã trả thêm ${money(purchasePaymentAmount)} cho phiếu ${paymentPurchase.code}.`);
      setPaymentPurchase(null);
      await p.reload();
    } catch (error) {
      p.notify(error instanceof Error ? error.message : "Không thể ghi nhận thanh toán thêm.");
    } finally {
      setPurchasePaymentBusy(false);
    }
  };
  const openPurchaseReceipt = (purchase: Purchase) => {
    setReceiptPurchase(purchase);
    setPurchaseReceiptAmount(Math.max(0, purchase.returnedTotal - purchase.returnedAmount));
    setPurchaseReceiptMethod("transfer");
  };
  const addPurchaseReceipt = async () => {
    if (!receiptPurchase) return;
    setPurchaseReceiptBusy(true);
    try {
      await p.api({ action: "purchase-return-payment", purchaseId: receiptPurchase.id, paymentAmount: purchaseReceiptAmount, paymentMethod: purchaseReceiptMethod });
      p.notify(`Đã thu thêm ${money(purchaseReceiptAmount)} từ NCC cho phiếu ${receiptPurchase.code}.`);
      setReceiptPurchase(null);
      await p.reload();
    } finally {
      setPurchaseReceiptBusy(false);
    }
  };
  const returnPurchase = async () => {
    if (!returningPurchase || !purchaseReturnReason.trim()) {
      p.notify("Vui lòng nhập lý do hoàn trả phiếu nhập.");
      return;
    }
    setPurchaseReturnBusy(true);
    try {
      const result = await p.api({
        action: "purchase-return",
        purchaseId: returningPurchase.id,
        reason: purchaseReturnReason,
        receivedAmount: purchaseReturnReceived,
        receivedMethod: purchaseReturnMethod,
      });
      const refundedAmount = Number(result.refundedAmount) || 0;
      p.notify(
        refundedAmount > 0
          ? `Đã hoàn trả ${returningPurchase.code}, trừ hàng khỏi kho và ghi nhận đã thu ${money(refundedAmount)}.`
          : `Đã hoàn trả ${returningPurchase.code} và trừ hàng khỏi kho.`,
      );
      setReturningPurchase(null);
      setPurchaseReturnReason("");
      setExpandedId(null);
      setDetails({});
      await p.reload();
    } catch (error) {
      p.notify(
        error instanceof Error
          ? error.message
          : "Không thể hoàn trả phiếu nhập.",
      );
    } finally {
      setPurchaseReturnBusy(false);
    }
  };
  return (
    <>
      <div className="three">
        <Kpi
          icon="⇩"
          label="Phiếu nhập"
          value={String(p.data.purchases.length)}
        />
        <Kpi
          icon="₫"
          label="Tổng tiền nhập"
          value={money(
            p.data.purchases
              .filter((purchase) => purchase.status !== "purchase_returned")
              .reduce((sum, purchase) => sum + purchase.total, 0),
          )}
          tone="purple"
        />
        <Kpi
          icon="!"
          label="Còn nợ NCC"
          value={money(
            p.data.debts
              .filter(
                (x) => x.partnerType === "supplier" && x.status !== "paid",
              )
              .reduce((s, x) => s + x.total - x.paid, 0),
          )}
          tone="orange"
        />
      </div>
      <article className="panel page">
        <PanelTitle
          text="Nhập hàng"
          sub="Tạo phiếu nhập, cập nhật giá vốn, tồn kho và serial"
          action="＋ Tạo phiếu nhập"
          onAction={() => {
            resetPurchaseForm();
            setOpen(true);
          }}
        />
        <div className="table">
          <table>
            <thead>
              <tr>
                <th aria-label="Mở chi tiết" />
                <th>Mã phiếu</th>
                <th>Nhà cung cấp</th>
                <th>Tổng tiền</th>
                <th>Đã trả</th>
                <th>Ngày nhập</th>
                <th>Trạng thái</th>
              </tr>
            </thead>
            <tbody>
              {p.data.purchases.length ? (
                p.data.purchases.map((x) => {
                  const expanded = expandedId === x.id;
                  const detail = details[x.id];
                  return <React.Fragment key={x.id}>
                  <tr className={`purchase-main-row${expanded ? " expanded" : ""}${x.status === "purchase_returned" ? " returned" : ""}`}>
                    <td><button type="button" className={`purchase-chevron${expanded ? " open" : ""}`} onClick={() => void toggleDetail(x.id)} aria-label={expanded ? `Thu gọn ${x.code}` : `Mở chi tiết ${x.code}`} aria-expanded={expanded}>⌄</button></td>
                    <td><button type="button" className="purchase-code-link" onClick={() => void editPurchase(x.id)} title={x.status === "purchase_returned" ? "Phiếu đã hoàn trả, chỉ có thể xem chi tiết" : "Sửa phiếu nhập"}>{x.code}</button></td>
                    <td>{x.supplierName}</td>
                    <td>{money(x.total)}</td>
                    <td>{money(x.paid)}</td>
                    <td>{formatDate(x.receivedAt || x.createdAt)}</td>
                    <td>
                      <Status value={x.status} />
                    </td>
                  </tr>
                  {expanded && <tr className="purchase-detail-row"><td colSpan={7}>
                    {detailBusy === x.id && !detail ? <div className="purchase-detail-loading">Đang tải chi tiết phiếu…</div> : detail ? <div className="purchase-inline-detail">
                      <div className="purchase-detail-meta">
                        <section><h4>Thông tin đơn nhập hàng</h4><p><span>Mã đơn</span><b>{x.code}</b></p><p><span>Ngày nhập</span><b>{formatDate(detail.purchase.receivedAt || x.receivedAt || x.createdAt)}</b></p><p><span>Ngày tạo đơn</span><b>{formatDate(x.createdAt)}</b></p><p><span>Nhà cung cấp</span><b>{x.supplierName}</b></p></section>
                        <section><h4>{x.status === "purchase_returned" ? "Thông tin hoàn trả" : "Ghi chú"}</h4>{x.status === "purchase_returned" ? <><p><span>Hoàn lúc</span><b>{formatDate(detail.purchase.returnedAt || x.returnedAt || "")}</b></p><p><span>Tiền thu lại</span><b>{money(Number(detail.purchase.returnedAmount) || x.returnedAmount)}</b></p><p><span>Lý do</span><b>{detail.purchase.returnReason || x.returnReason || "Không có lý do"}</b></p></> : <><p>{detail.purchase.note || "Không có ghi chú"}</p>{detail.purchase.tags && <><h4>Tags</h4><p>{detail.purchase.tags}</p></>}</>}</section>
                      </div>
                      <div className="purchase-detail-products"><table><thead><tr><th>STT</th><th>Mã SKU</th><th>Tên sản phẩm</th><th>Số lượng</th><th>Đơn giá</th><th>Chiết khấu</th><th>Thành tiền</th></tr></thead><tbody>
                        {detail.items.map((item, index) => <tr key={item.id}><td>{index + 1}</td><td className="link">{item.sku}</td><td className="product-name-cell" title={item.productName}><b>{item.productName}</b></td><td>{item.quantity}</td><td>{money(item.unitCost)}</td><td>{money(item.discount)}</td><td><b>{money(item.quantity * item.unitCost - item.discount)}</b></td></tr>)}
                      </tbody></table><div className="purchase-detail-total"><p><span>Số lượng</span><b>{detail.items.reduce((sum, item) => sum + item.quantity, 0)}</b></p><p><span>Tổng tiền</span><b>{money(detail.purchase.subtotal)}</b></p><p><span>Chiết khấu</span><b>{money(detail.purchase.discount)}</b></p><p><span>Chi phí nhập hàng</span><b>{money(detail.purchase.otherCosts)}</b></p><p><span>Thuế</span><b>{money(detail.purchase.tax)}</b></p><p className="payable"><span>Tiền cần trả</span><b>{money(detail.purchase.total)}</b></p></div></div>
                      <div className="inline-order-actions purchase-detail-actions">
                        <button type="button" onClick={() => window.print()}>In đơn A4</button>
                        {x.status === "purchase_returned" && x.returnedAmount < x.returnedTotal && (
                          <button type="button" className="primary" onClick={() => openPurchaseReceipt(x)}>Thu tiền thêm</button>
                        )}
                        {x.status !== "purchase_returned" && (
                          <>
                            <button type="button" onClick={() => void editPurchase(x.id)}>Sửa đơn hàng</button>
                            {x.paid < x.total && (
                              <button type="button" className="primary" onClick={() => openPurchasePayment(x)}>Thanh toán thêm</button>
                            )}
                            <button type="button" className="danger-button purchase-return-button" onClick={() => openPurchaseReturn(x)}>Hoàn trả phiếu</button>
                          </>
                        )}
                      </div>
                      <button type="button" className="purchase-collapse" onClick={() => setExpandedId(null)}>⌃ Thu gọn</button>
                    </div> : null}
                  </td></tr>}
                  </React.Fragment>;
                })
              ) : (
                <tr>
                    <td colSpan={7}>
                    <Empty text="Chưa có phiếu nhập" />
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </article>
      {open && (
        <Modal
          title={editingId ? `Sửa phiếu nhập ${p.data.purchases.find((x) => x.id === editingId)?.code || ""}` : "Tạo phiếu nhập hàng"}
          onClose={() => {
            setOpen(false);
            resetPurchaseForm();
          }}
          wide
          className="purchase-modal"
        >
          <div className="purchase-workspace">
          <section className="purchase-supplier-card purchase-supplier-compact">
            <div className="purchase-supplier-heading">
              <div>
                <h3>Thông tin nhà cung cấp</h3>
                <p>Tìm theo tên, số điện thoại hoặc mã nhà cung cấp</p>
              </div>
              <button type="button" onClick={() => setSupplierFormOpen(true)}>
                ＋ Tạo nhà cung cấp mới
              </button>
            </div>
            <div className="supplier-picker" ref={supplierPickerRef}>
              <label className="supplier-search-box">
                <span aria-hidden="true">⌕</span>
                <input
                  value={supplierQuery}
                  onFocus={() => {
                    setProductResultsOpen(false);
                    setSupplierResultsOpen(true);
                  }}
                  onChange={(e) => {
                    setSupplierQuery(e.target.value);
                    setSupplierId("");
                    setProductResultsOpen(false);
                    setSupplierResultsOpen(true);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Escape") setSupplierResultsOpen(false);
                    if (e.key === "Enter" && matchingSuppliers.length) {
                      e.preventDefault();
                      selectSupplier(matchingSuppliers[0]);
                    }
                  }}
                  placeholder="Tìm theo tên, SĐT, mã nhà cung cấp..."
                  aria-label="Tìm nhà cung cấp"
                  aria-expanded={supplierResultsOpen && !selectedSupplier}
                  aria-controls="purchase-supplier-results"
                  autoComplete="off"
                />
                {supplierQuery && (
                  <button
                    type="button"
                    aria-label="Xóa nhà cung cấp đã chọn"
                    onClick={() => {
                      setSupplierId("");
                      setSupplierQuery("");
                      setSupplierResultsOpen(false);
                    }}
                  >
                    ×
                  </button>
                )}
              </label>
              {supplierResultsOpen && !selectedSupplier && (
                <div className="supplier-results" id="purchase-supplier-results">
                  {matchingSuppliers.length ? (
                    matchingSuppliers.map((supplier) => (
                      <button
                        type="button"
                        key={supplier.id}
                        onClick={() => selectSupplier(supplier)}
                      >
                        <span>
                          <b>{supplier.name}</b>
                          <small>
                            {supplier.code} · {supplier.phone || "Chưa có SĐT"}
                          </small>
                        </span>
                        <em>Chọn</em>
                      </button>
                    ))
                  ) : (
                    <div className="supplier-no-result">
                      <span>Không tìm thấy nhà cung cấp phù hợp</span>
                      <button
                        type="button"
                        onClick={() => setSupplierFormOpen(true)}
                      >
                        ＋ Tạo nhà cung cấp mới
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
            {selectedSupplier ? (
              <div className="selected-supplier-info">
                <i>{selectedSupplier.name.slice(0, 1).toUpperCase()}</i>
                <div>
                  <b>{selectedSupplier.name}</b>
                  <span>
                    {selectedSupplier.code} · {selectedSupplier.phone || "Chưa có SĐT"}
                  </span>
                  <small>
                    {selectedSupplier.address || "Chưa có địa chỉ"}
                    {selectedSupplier.email ? ` · ${selectedSupplier.email}` : ""}
                  </small>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSupplierId("");
                    setSupplierQuery("");
                    setSupplierResultsOpen(false);
                  }}
                >
                  Đổi nhà cung cấp
                </button>
              </div>
            ) : (
              <div className="supplier-empty-state">
                <i aria-hidden="true">▱</i>
                <span>Chưa có thông tin nhà cung cấp</span>
              </div>
            )}
          </section>
          <section className="purchase-products-card" ref={productPickerRef}>
            <div className="purchase-product-heading">
              <h3>Thông tin sản phẩm</h3>
              <label>
                <input
                  type="checkbox"
                  checked={splitLines}
                  onChange={(e) => setSplitLines(e.target.checked)}
                />
                Tách dòng
              </label>
            </div>
            <div className="purchase-product-toolbar">
              <label className="purchase-product-search">
                <span aria-hidden="true">⌕</span>
                <input
                  value={productQuery}
                  onFocus={() => {
                    setSupplierResultsOpen(false);
                    setProductResultsOpen(true);
                  }}
                  onChange={(e) => {
                    setProductQuery(e.target.value);
                    setSupplierResultsOpen(false);
                    setProductResultsOpen(true);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Escape") setProductResultsOpen(false);
                    if (e.key === "Enter" && matchingProducts.length && !multiSelect) {
                      e.preventDefault();
                      addProduct(matchingProducts[0]);
                    }
                  }}
                  placeholder="Tìm theo tên, mã SKU hoặc quét mã Barcode… (F3)"
                  aria-label="Tìm sản phẩm nhập"
                  aria-expanded={productResultsOpen}
                  aria-controls="purchase-product-results"
                  autoComplete="off"
                />
                {productQuery && (
                  <button type="button" onClick={() => setProductQuery("")} aria-label="Xóa tìm kiếm">
                    ×
                  </button>
                )}
              </label>
              <button
                type="button"
                className={multiSelect ? "active" : ""}
                onClick={() => {
                  setMultiSelect((value) => !value);
                  setSelectedProductIds([]);
                }}
              >
                Chọn nhiều
              </button>
              <select aria-label="Loại giá hiển thị" defaultValue="cost">
                <option value="cost">Giá nhập</option>
              </select>
            </div>
            {productResultsOpen && (
              <div className="purchase-product-results" id="purchase-product-results">
                <button
                  type="button"
                  className="product-search-create"
                  onClick={openQuickProductForm}
                >
                  <i aria-hidden="true">＋</i>
                  <span>
                    <b>Thêm mới sản phẩm</b>
                    <small>
                      {productQuery.trim()
                        ? `Tạo sản phẩm “${productQuery.trim()}”`
                        : "Tạo sản phẩm nếu chưa có trong danh sách"}
                    </small>
                  </span>
                </button>
                {matchingProducts.length ? (
                  matchingProducts.map((product) => (
                    <button
                      type="button"
                      className="product-search-row"
                      key={product.id}
                      onClick={() => {
                        if (multiSelect) {
                          setSelectedProductIds((current) =>
                            current.includes(product.id)
                              ? current.filter((id) => id !== product.id)
                              : [...current, product.id],
                          );
                        } else addProduct(product);
                      }}
                    >
                      {multiSelect && (
                        <input
                          type="checkbox"
                          tabIndex={-1}
                          readOnly
                          checked={selectedProductIds.includes(product.id)}
                        />
                      )}
                      <ProductImage
                        imageKey={product.imageKey}
                        alt={product.name}
                        className="product-search-thumb"
                      />
                      <span className="product-search-main">
                        <b>{product.name}</b>
                        <small>
                          {product.sku} · {product.unit || "Chiếc"}
                          {product.brand ? ` · ${product.brand}` : ""}
                        </small>
                      </span>
                      <span className="product-search-value">
                        <strong>{money(product.cost)}</strong>
                        <small>
                          Tồn: {product.stock} | Có thể bán: {Math.max(0, product.stock)}
                        </small>
                      </span>
                    </button>
                  ))
                ) : (
                  <div className="purchase-product-empty">
                    <span>Không tìm thấy sản phẩm phù hợp</span>
                  </div>
                )}
                {multiSelect && matchingProducts.length > 0 && (
                  <div className="purchase-multi-actions">
                    <span>Đã chọn {selectedProductIds.length} sản phẩm</span>
                    <button
                      type="button"
                      disabled={!selectedProductIds.length}
                      onClick={() => {
                        selectedProductIds.forEach((id) => {
                          const product = p.data.products.find((x) => x.id === id);
                          if (product) addProduct(product);
                        });
                        setSelectedProductIds([]);
                        setMultiSelect(false);
                        setProductResultsOpen(false);
                      }}
                    >
                      Thêm vào phiếu
                    </button>
                  </div>
                )}
              </div>
            )}
            <div className="purchase-lines-wrap">
            <table className="purchase-lines-table">
              <thead>
                <tr>
                  <th>STT</th>
                  <th>Ảnh</th>
                  <th>Tên sản phẩm</th>
                  <th>Đơn vị</th>
                  <th>SL nhập</th>
                  <th>Đơn giá</th>
                  <th>Chiết khấu</th>
                  <th>Thành tiền</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {items.map((x, i) => (
                  <tr key={x.rowId}>
                    <td>{i + 1}</td>
                    <td>
                      <ProductImage
                        imageKey={x.imageKey}
                        alt={x.name}
                        className="purchase-image-placeholder"
                      />
                    </td>
                    <td className="purchase-product-cell product-name-cell" title={x.name}>
                      <b>{x.name}</b>
                      <small>{x.sku}</small>
                      <input
                        value={x.note}
                        onChange={(e) => updateItem(x.rowId, { note: e.target.value })}
                        placeholder="Ghi chú sản phẩm"
                      />
                      {x.tracking === "serial" && (
                        <div className="purchase-serial-entry">
                          <label className={x.serials.length ? "serial-ok" : "serial-missing"}>
                            Serial / IMEI · {x.serials.length} đã nhập
                            <input
                              ref={(element) => { serialInputRefs.current[x.rowId] = element; }}
                              value={serialDrafts[x.rowId] || ""}
                              onChange={(event) => setSerialDrafts((current) => ({ ...current, [x.rowId]: event.target.value }))}
                              onKeyDown={(event) => {
                                if (event.key !== "Enter") return;
                                event.preventDefault();
                                saveSerial(x.rowId);
                              }}
                              placeholder="Nhập & Enter / quét mã số Serial/IMEI"
                              aria-label={`Nhập serial hoặc IMEI cho ${x.name}`}
                            />
                          </label>
                          {x.serials.length > 0 && (
                            <div className="purchase-serial-tags" aria-label={`Serial đã nhập cho ${x.name}`}>
                              {x.serials.map((serial) => (
                                <span key={serial}>
                                  {serial}
                                  <button type="button" aria-label={`Xóa serial ${serial}`} onClick={() => removeSerial(x.rowId, serial)}>×</button>
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </td>
                    <td><select value={x.unit} onChange={(e) => updateItem(x.rowId, { unit: e.target.value })}><option>{x.unit}</option></select></td>
                    <td>
                      {x.tracking === "serial" ? (
                        <div className="purchase-serial-quantity" title="Số lượng tự tính theo serial đã nhập">{x.quantity}</div>
                      ) : (
                        <div className="purchase-qty-stepper">
                          <button type="button" onClick={() => updateItem(x.rowId, { quantity: Math.max(1, x.quantity - 1) })}>−</button>
                          <input type="number" min="1" value={x.quantity} onChange={(e) => updateItem(x.rowId, { quantity: Math.max(1, Math.trunc(Number(e.target.value) || 1)) })} />
                          <button type="button" onClick={() => updateItem(x.rowId, { quantity: x.quantity + 1 })}>＋</button>
                        </div>
                      )}
                    </td>
                    <td><MoneyInput className="purchase-money-input" value={x.cost} ariaLabel={`Đơn giá nhập ${x.name}`} onValueChange={(cost) => updateItem(x.rowId, { cost })} /></td>
                    <td><MoneyInput className="purchase-money-input" max={x.quantity * x.cost} value={x.discount} ariaLabel={`Chiết khấu nhập ${x.name}`} onValueChange={(discount) => updateItem(x.rowId, { discount })} /></td>
                    <td className="purchase-line-total">{money(Math.max(0, x.quantity * x.cost - x.discount))}</td>
                    <td>
                      <button
                        className="danger-link"
                        type="button"
                        aria-label={`Xóa ${x.name}`}
                        onClick={() =>
                          setItems((v) => v.filter((item) => item.rowId !== x.rowId))
                        }
                      >
                        ×
                      </button>
                    </td>
                  </tr>
                ))}
                {!items.length && (
                  <tr><td colSpan={9}><div className="purchase-lines-empty">Tìm và chọn sản phẩm để thêm vào phiếu nhập</div></td></tr>
                )}
              </tbody>
            </table>
            </div>
          </section>
          <div className="purchase-footer-grid">
            <div className="purchase-notes-card">
              <label>
                Ghi chú đơn
                <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="VD: Hàng tặng gói riêng" />
              </label>
              <label>
                Ngày giờ nhập hàng
                <input
                  type="datetime-local"
                  value={receivedAt}
                  onChange={(e) => setReceivedAt(e.target.value)}
                />
              </label>
            </div>
          </div>
          <div className="purchase-payment-panel">
            <div className="payment-entry">
              <span className="picker-label">Hình thức đã thanh toán</span>
              <div className="payment-methods compact-payment-methods">
                <button
                  type="button"
                  className={entryPaymentMethod === "cash" ? "selected" : ""}
                  onClick={() => setEntryPaymentMethod("cash")}
                >
                  <i>₫</i>
                  <span>Tiền mặt</span>
                </button>
                <button
                  type="button"
                  className={entryPaymentMethod === "transfer" ? "selected" : ""}
                  onClick={() => setEntryPaymentMethod("transfer")}
                >
                  <i>⇄</i>
                  <span>Chuyển khoản</span>
                </button>
              </div>
            </div>
            <label className="paid-entry">
              <span>Đã trả cho nhà cung cấp</span>
              <div>
                <MoneyInput
                  max={total}
                  value={paid}
                  ariaLabel="Số tiền đã trả cho nhà cung cấp"
                  onValueChange={setPurchasePaidAmount}
                />
                <button type="button" onClick={() => setPurchasePaidAmount(total)}>
                  Trả đủ
                </button>
              </div>
              <small>Có thể nhập lại số tiền thực tế đã thanh toán</small>
            </label>
            <div className="sale-totals purchase-payment-totals">
              <p><span>Tổng tiền hàng</span><b>{money(subtotal)}</b></p>
              {discount > 0 && <p><span>Tổng chiết khấu</span><b>− {money(discount)}</b></p>}
              {otherCosts > 0 && <p><span>Chi phí nhập hàng</span><b>+ {money(otherCosts)}</b></p>}
              {tax > 0 && <p><span>Thuế</span><b>+ {money(tax)}</b></p>}
              <p className="customer-payable"><span>Tiền cần trả</span><b>{money(total)}</b></p>
              <p><span>Đã thanh toán</span><b>{money(paid)}</b></p>
              <p className={`remaining-payment ${paid > total ? "overpaid" : ""}`}>
                <span>{paid > total ? "Thanh toán vượt" : "Còn phải trả"}</span>
                <b>{money(Math.abs(total - paid))}</b>
              </p>
            </div>
          </div>
          {!serialsValid && <div className="purchase-form-warning">Hàng quản lý serial cần nhập ít nhất một Serial/IMEI. Số lượng sẽ tự tính theo các serial đã lưu.</div>}
          {paid > total && <div className="purchase-form-warning">Tổng thanh toán không được vượt quá tiền cần trả.</div>}
          <div className="purchase-form-actions">
            <button type="button" onClick={() => { setOpen(false); resetPurchaseForm(); }}>Hủy</button>
            <SpinnerButton
            className="primary"
            busy={busy}
            disabled={!items.length || !supplierId || !serialsValid || paid > total}
            onClick={save}
          >
            {editingId ? "Lưu thay đổi" : "Hoàn tất nhập hàng"}
          </SpinnerButton>
          </div>
          </div>
        </Modal>
      )}
      {returningPurchase && (
        <Modal
          title={`Hoàn trả phiếu nhập · ${returningPurchase.code}`}
          onClose={() => {
            if (!purchaseReturnBusy) setReturningPurchase(null);
          }}
          className="purchase-return-modal"
        >
          <div className="purchase-return-warning">
            <b>Hệ thống sẽ thực hiện đồng thời:</b>
            <ul>
              <li>Đánh dấu phiếu nhập là Đã hoàn trả và khóa chỉnh sửa.</li>
              <li>Trừ toàn bộ hàng hóa và serial của phiếu khỏi kho.</li>
              <li>
                {returningPurchase.paid > 0
                  ? `Ghi khoản thu lại ${money(returningPurchase.paid)} vào Sổ thu chi theo đúng phương thức đã thanh toán.`
                  : "Phiếu chưa thanh toán nên không phát sinh khoản thu lại."}
              </li>
              <li>Đóng công nợ còn lại với nhà cung cấp.</li>
            </ul>
            <p>
              Nếu một phần hàng hoặc serial đã xuất kho, thao tác sẽ bị chặn để
              tránh sai lệch tồn kho.
            </p>
          </div>
          <div className="additional-payment-summary">
            <p><span>Đã trả cho NCC</span><b>{money(returningPurchase.paid)}</b></p>
            <p className="due"><span>NCC cần hoàn lại</span><b>{money(returningPurchase.paid)}</b></p>
          </div>
          <Field label="Số tiền NCC đã hoàn ngay">
            <MoneyInput max={returningPurchase.paid} value={purchaseReturnReceived} ariaLabel="Số tiền NCC đã hoàn" onValueChange={setPurchaseReturnReceived} />
          </Field>
          <span className="picker-label">Nhận vào quỹ</span>
          <div className="payment-methods additional-payment-methods">
            <button type="button" className={purchaseReturnMethod === "cash" ? "selected" : ""} onClick={() => setPurchaseReturnMethod("cash")}><i>₫</i><span>Tiền mặt</span></button>
            <button type="button" className={purchaseReturnMethod === "transfer" ? "selected" : ""} onClick={() => setPurchaseReturnMethod("transfer")}><i>⇄</i><span>Chuyển khoản</span></button>
          </div>
          {purchaseReturnReceived < returningPurchase.paid && <div className="additional-payment-after">Còn phải thu NCC <b>{money(returningPurchase.paid - purchaseReturnReceived)}</b></div>}
          <Field label="Lý do hoàn trả">
            <textarea
              autoFocus
              value={purchaseReturnReason}
              maxLength={500}
              onChange={(event) => setPurchaseReturnReason(event.target.value)}
              placeholder="Nhập lý do để lưu lịch sử hoàn trả"
            />
          </Field>
          <div className="purchase-return-actions">
            <button
              className="secondary"
              type="button"
              disabled={purchaseReturnBusy}
              onClick={() => setReturningPurchase(null)}
            >
              Quay lại
            </button>
            <SpinnerButton
              className="purchase-return-submit"
              busy={purchaseReturnBusy}
              disabled={!purchaseReturnReason.trim()}
              onClick={returnPurchase}
            >
              Xác nhận hoàn trả
            </SpinnerButton>
          </div>
        </Modal>
      )}
      {paymentPurchase && (
        <Modal title={`Thanh toán thêm · ${paymentPurchase.code}`} onClose={() => setPaymentPurchase(null)}>
          <div className="additional-payment-summary">
            <p><span>Tiền cần trả NCC</span><b>{money(paymentPurchase.total)}</b></p>
            <p><span>Đã trả</span><b>{money(paymentPurchase.paid)}</b></p>
            <p className="due"><span>Còn phải trả</span><b>{money(Math.max(0, paymentPurchase.total - paymentPurchase.paid))}</b></p>
          </div>
          <Field label="Số tiền trả thêm">
            <MoneyInput autoFocus max={Math.max(0, paymentPurchase.total - paymentPurchase.paid)} value={purchasePaymentAmount} ariaLabel="Số tiền trả thêm nhà cung cấp" onValueChange={setPurchasePaymentAmount} />
          </Field>
          <span className="picker-label">Ghi vào quỹ</span>
          <div className="payment-methods additional-payment-methods">
            <button type="button" className={purchasePaymentMethod === "cash" ? "selected" : ""} onClick={() => setPurchasePaymentMethod("cash")}><i>₫</i><span>Tiền mặt</span></button>
            <button type="button" className={purchasePaymentMethod === "transfer" ? "selected" : ""} onClick={() => setPurchasePaymentMethod("transfer")}><i>⇄</i><span>Chuyển khoản</span></button>
          </div>
          <div className="additional-payment-after">Sau giao dịch còn phải trả <b>{money(Math.max(0, paymentPurchase.total - paymentPurchase.paid - purchasePaymentAmount))}</b></div>
          <SpinnerButton className="primary modal-submit" busy={purchasePaymentBusy} disabled={purchasePaymentAmount <= 0 || purchasePaymentAmount > paymentPurchase.total - paymentPurchase.paid} onClick={addPurchasePayment}>Xác nhận thanh toán và ghi Sổ thu chi</SpinnerButton>
        </Modal>
      )}
      {receiptPurchase && (
        <Modal title={`Thu tiền thêm · ${receiptPurchase.code}`} onClose={() => setReceiptPurchase(null)}>
          <div className="additional-payment-summary">
            <p><span>NCC cần hoàn lại</span><b>{money(receiptPurchase.returnedTotal)}</b></p>
            <p><span>Đã thu</span><b>{money(receiptPurchase.returnedAmount)}</b></p>
            <p className="due"><span>Còn phải thu</span><b>{money(Math.max(0, receiptPurchase.returnedTotal - receiptPurchase.returnedAmount))}</b></p>
          </div>
          <Field label="Số tiền thu thêm"><MoneyInput autoFocus max={Math.max(0, receiptPurchase.returnedTotal - receiptPurchase.returnedAmount)} value={purchaseReceiptAmount} ariaLabel="Số tiền thu thêm từ nhà cung cấp" onValueChange={setPurchaseReceiptAmount} /></Field>
          <span className="picker-label">Nhận vào quỹ</span>
          <div className="payment-methods additional-payment-methods">
            <button type="button" className={purchaseReceiptMethod === "cash" ? "selected" : ""} onClick={() => setPurchaseReceiptMethod("cash")}><i>₫</i><span>Tiền mặt</span></button>
            <button type="button" className={purchaseReceiptMethod === "transfer" ? "selected" : ""} onClick={() => setPurchaseReceiptMethod("transfer")}><i>⇄</i><span>Chuyển khoản</span></button>
          </div>
          <SpinnerButton className="primary modal-submit" busy={purchaseReceiptBusy} disabled={purchaseReceiptAmount <= 0 || purchaseReceiptAmount > receiptPurchase.returnedTotal - receiptPurchase.returnedAmount} onClick={addPurchaseReceipt}>Xác nhận thu tiền và ghi Sổ thu chi</SpinnerButton>
        </Modal>
      )}
      {supplierFormOpen && (
        <PeopleModal
          kind="supplier"
          onClose={() => setSupplierFormOpen(false)}
          onSaved={(id, name) => {
            setSupplierId(id);
            setSupplierQuery(name);
            setSupplierResultsOpen(false);
          }}
          p={p}
        />
      )}
      {quickProductForm && (
        <Modal
          title="Thêm sản phẩm mới"
          onClose={() => {
            if (!quickProductBusy) setQuickProductForm(null);
          }}
          wide
          className="quick-product-modal"
        >
          <div className="form-grid">
            <Field label="Tên sản phẩm *">
              <input
                autoFocus
                value={quickProductForm.name}
                onChange={(e) =>
                  setQuickProductForm({
                    ...quickProductForm,
                    name: e.target.value,
                  })
                }
              />
            </Field>
            <Field label="SKU">
              <input
                value={quickProductForm.sku}
                onChange={(e) =>
                  setQuickProductForm({
                    ...quickProductForm,
                    sku: e.target.value,
                  })
                }
              />
            </Field>
            <Field label="Nhóm hàng">
              <div className="catalog-option-control">
                <select
                  value={quickProductForm.category}
                  onChange={(e) =>
                    setQuickProductForm({
                      ...quickProductForm,
                      category: e.target.value,
                    })
                  }
                  aria-label="Chọn nhóm hàng"
                >
                  <option value="" disabled>
                    Chọn nhóm hàng
                  </option>
                  {quickOptionNames("category").map((name) => (
                    <option key={name} value={name}>
                      {name}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => {
                    setQuickOptionType("category");
                    setQuickOptionName("");
                  }}
                  title="Thêm nhóm hàng mới"
                  aria-label="Thêm nhóm hàng mới"
                >
                  ＋
                </button>
              </div>
            </Field>
            <Field label="Thương hiệu">
              <div className="catalog-option-control">
                <select
                  value={quickProductForm.brand}
                  onChange={(e) =>
                    setQuickProductForm({
                      ...quickProductForm,
                      brand: e.target.value,
                    })
                  }
                  aria-label="Chọn thương hiệu"
                >
                  <option value="">Chưa chọn thương hiệu</option>
                  {quickOptionNames("brand").map((name) => (
                    <option key={name} value={name}>
                      {name}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => {
                    setQuickOptionType("brand");
                    setQuickOptionName("");
                  }}
                  title="Thêm thương hiệu mới"
                  aria-label="Thêm thương hiệu mới"
                >
                  ＋
                </button>
              </div>
            </Field>
            <Field label="Đơn vị">
              <input
                value={quickProductForm.unit}
                onChange={(e) =>
                  setQuickProductForm({
                    ...quickProductForm,
                    unit: e.target.value,
                  })
                }
              />
            </Field>
            <Field label="Quản lý kho">
              <select
                value={quickProductForm.tracking}
                onChange={(e) =>
                  setQuickProductForm({
                    ...quickProductForm,
                    tracking: e.target.value as "serial" | "quantity",
                    stock: "0",
                  })
                }
              >
                <option value="serial">Theo serial</option>
                <option value="quantity">Theo số lượng</option>
              </select>
            </Field>
            <Field label="Giá vốn">
              <MoneyInput
                value={Number(quickProductForm.cost)}
                ariaLabel="Giá vốn sản phẩm"
                onValueChange={(cost) =>
                  setQuickProductForm({
                    ...quickProductForm,
                    cost: String(cost),
                  })
                }
              />
            </Field>
            <Field label="Giá bán">
              <MoneyInput
                value={Number(quickProductForm.price)}
                ariaLabel="Giá bán sản phẩm"
                onValueChange={(price) =>
                  setQuickProductForm({
                    ...quickProductForm,
                    price: String(price),
                  })
                }
              />
            </Field>
            <Field label="Mô tả sản phẩm" wide>
              <textarea
                value={quickProductForm.description}
                onChange={(e) =>
                  setQuickProductForm({
                    ...quickProductForm,
                    description: e.target.value,
                  })
                }
              />
            </Field>
          </div>
          <p className="quick-product-return-note">
            Sau khi lưu, sản phẩm sẽ được chọn vào phiếu nhập đang làm. Số
            lượng và serial của lần nhập này có thể chỉnh tiếp ngay trên phiếu.
          </p>
          {quickProductError && (
            <p className="quick-product-error" role="alert">
              {quickProductError}
            </p>
          )}
          <div className="people-modal-actions">
            <button
              type="button"
              disabled={quickProductBusy}
              onClick={() => setQuickProductForm(null)}
            >
              Hủy
            </button>
            <SpinnerButton
              className="primary"
              busy={quickProductBusy}
              disabled={
                !quickProductForm.name.trim()
              }
              onClick={saveQuickProduct}
            >
              Lưu và thêm vào phiếu
            </SpinnerButton>
          </div>
        </Modal>
      )}
      {quickOptionType && quickProductForm && (
        <Modal
          title={`Thêm ${quickOptionType === "category" ? "nhóm hàng" : "thương hiệu"} mới`}
          onClose={() => {
            if (!quickOptionBusy) setQuickOptionType(null);
          }}
        >
          <Field
            label={
              quickOptionType === "category"
                ? "Tên nhóm hàng"
                : "Tên thương hiệu"
            }
          >
            <input
              autoFocus
              value={quickOptionName}
              maxLength={80}
              onChange={(e) => setQuickOptionName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  void saveQuickOption();
                }
              }}
            />
          </Field>
          <SpinnerButton
            className="primary modal-submit"
            busy={quickOptionBusy}
            disabled={!quickOptionName.trim()}
            onClick={saveQuickOption}
          >
            Lưu và chọn
          </SpinnerButton>
        </Modal>
      )}
    </>
  );
}

export function Returns(p: ViewProps) {
  const [open, setOpen] = useState(false);
  const [orderId, setOrderId] = useState("");
  const [itemId, setItemId] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [reason, setReason] = useState("");
  const [refundPaid, setRefundPaid] = useState(0);
  const [refundMethod, setRefundMethod] = useState<"cash" | "transfer">("transfer");
  const [returnBusy, setReturnBusy] = useState(false);
  const [payingReturn, setPayingReturn] = useState<ReturnRow | null>(null);
  const [additionalRefund, setAdditionalRefund] = useState(0);
  const [additionalRefundMethod, setAdditionalRefundMethod] = useState<"cash" | "transfer">("transfer");
  const order = p.data.orders.find((x) => x.id === orderId);
  const items = p.data.orderItems.filter((x) => x.orderId === orderId);
  const returnedQuantities = useMemo(() => {
    const quantities = new Map<number, number>();
    for (const row of p.data.returns) {
      if (row.orderId !== orderId) continue;
      try {
        const returned = JSON.parse(row.itemsJson || "[]") as Array<{ itemId?: number; quantity?: number }>;
        for (const item of returned) {
          const itemId = Number(item.itemId);
          const itemQuantity = Math.max(0, Number(item.quantity) || 0);
          if (itemId) quantities.set(itemId, (quantities.get(itemId) ?? 0) + itemQuantity);
        }
      } catch {
        // A legacy row without valid item details does not block new returns.
      }
    }
    return quantities;
  }, [orderId, p.data.returns]);
  const returnableItems = items.filter(
    (item) => item.quantity > (returnedQuantities.get(item.id) ?? 0),
  );
  const selectedItem = returnableItems.find((x) => x.id === Number(itemId));
  const maxReturnQuantity = Math.max(
    0,
    (selectedItem?.quantity ?? 0) - (returnedQuantities.get(Number(itemId)) ?? 0),
  );
  const openReturn = () => {
    setOrderId("");
    setItemId("");
    setQuantity(1);
    setReason("");
    setRefundPaid(0);
    setRefundMethod("transfer");
    setOpen(true);
  };
  const save = async () => {
    if (returnBusy) return;
    if (!selectedItem || quantity < 1 || quantity > maxReturnQuantity) {
      p.notify("Vui lòng chọn sản phẩm và số lượng còn có thể đổi trả.");
      return;
    }
    setReturnBusy(true);
    try {
      const result = await p.api({
        action: "return",
        orderId,
        reason,
        refundPaid,
        refundMethod,
        items: [{ itemId: Number(itemId), quantity }],
      });
      setOpen(false);
      p.notify(
        `Đã tạo phiếu ${result.code}; đã hoàn ${money(Number(result.paid))}, còn lại được theo dõi trong công nợ.`,
      );
      await p.reload();
    } catch (error) {
      p.notify(error instanceof Error ? error.message : "Không thể tạo phiếu đổi trả.");
    } finally {
      setReturnBusy(false);
    }
  };
  return (
    <>
      <article className="panel page">
        <PanelTitle
          text="Đổi trả hàng"
          sub="Hoàn kho, serial và tiền theo đơn bán gốc"
          action="＋ Tạo phiếu đổi trả"
          onAction={openReturn}
        />
        <div className="table">
          <table>
            <thead>
              <tr>
                <th>Mã phiếu</th>
                <th>Đơn gốc</th>
                <th>Khách hàng</th>
                <th>Phải hoàn</th>
                <th>Đã hoàn</th>
                <th>Còn phải hoàn</th>
                <th>Lý do</th>
                <th>Thời gian</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {p.data.returns.length ? (
                p.data.returns.map((x) => (
                  <tr key={x.id}>
                    <td className="link">{x.code}</td>
                    <td>{x.orderCode}</td>
                    <td>{x.customerName}</td>
                    <td>{money(x.amount)}</td>
                    <td>{money(x.paid)}</td>
                    <td className="red">{money(Math.max(0, x.amount - x.paid))}</td>
                    <td>{x.reason}</td>
                    <td>{formatDate(x.createdAt)}</td>
                    <td>{x.paid < x.amount ? <button className="link-button" onClick={() => { setPayingReturn(x); setAdditionalRefund(Math.max(0, x.amount - x.paid)); setAdditionalRefundMethod("transfer"); }}>Hoàn tiền thêm</button> : <Status value="paid" />}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={9}>
                    <Empty text="Chưa có phiếu đổi trả" />
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </article>
      {open && (
        <Modal title="Tạo phiếu đổi trả" onClose={() => setOpen(false)}>
          <Field label="Đơn bán gốc">
            <select
              value={orderId}
              onChange={(e) => {
                setOrderId(e.target.value);
                setItemId("");
              }}
            >
              <option value="">Chọn đơn hàng</option>
              {p.data.orders
                .filter((x) => x.status !== "cancelled" && x.paid >= x.total)
                .map((x) => (
                  <option key={x.id} value={x.id}>
                    {x.code} · {x.customerName}
                  </option>
                ))}
            </select>
          </Field>
          {order && (
            <>
              <Field label="Sản phẩm trả">
                <select
                  value={itemId}
                  onChange={(e) => setItemId(e.target.value)}
                >
                  <option value="">Chọn sản phẩm</option>
                  {returnableItems.map((x) => (
                    <option key={x.id} value={x.id}>
                      {x.productName} · còn có thể trả {x.quantity - (returnedQuantities.get(x.id) ?? 0)}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Số lượng trả">
                <input
                  type="number"
                  min="1"
                  max={
                    maxReturnQuantity || 1
                  }
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                />
              </Field>
            </>
          )}
          <Field label="Lý do đổi trả">
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Lỗi sản phẩm, đổi nhu cầu..."
            />
          </Field>
          <div className="additional-payment-summary">
            <p><span>Giá trị cần hoàn</span><b>{money((selectedItem?.unitPrice || 0) * quantity)}</b></p>
          </div>
          <Field label="Số tiền hoàn ngay">
            <MoneyInput max={(selectedItem?.unitPrice || 0) * quantity} value={refundPaid} ariaLabel="Số tiền hoàn ngay" onValueChange={setRefundPaid} />
          </Field>
          <span className="picker-label">Ghi vào quỹ</span>
          <div className="payment-methods additional-payment-methods">
            <button type="button" className={refundMethod === "cash" ? "selected" : ""} onClick={() => setRefundMethod("cash")}><i>₫</i><span>Tiền mặt</span></button>
            <button type="button" className={refundMethod === "transfer" ? "selected" : ""} onClick={() => setRefundMethod("transfer")}><i>⇄</i><span>Chuyển khoản</span></button>
          </div>
          <SpinnerButton
            className="primary modal-submit"
            busy={returnBusy}
            disabled={!itemId || !reason.trim() || !selectedItem || quantity > maxReturnQuantity}
            onClick={save}
          >
            Xác nhận đổi trả
          </SpinnerButton>
        </Modal>
      )}
      {payingReturn && (
        <Modal title={`Hoàn tiền thêm · ${payingReturn.code}`} onClose={() => setPayingReturn(null)}>
          <div className="additional-payment-summary">
            <p><span>Khách cần nhận</span><b>{money(payingReturn.amount)}</b></p>
            <p><span>Đã hoàn</span><b>{money(payingReturn.paid)}</b></p>
            <p className="due"><span>Còn phải hoàn</span><b>{money(Math.max(0, payingReturn.amount - payingReturn.paid))}</b></p>
          </div>
          <Field label="Số tiền hoàn thêm"><MoneyInput autoFocus max={Math.max(0, payingReturn.amount - payingReturn.paid)} value={additionalRefund} ariaLabel="Số tiền hoàn thêm" onValueChange={setAdditionalRefund} /></Field>
          <span className="picker-label">Ghi vào quỹ</span>
          <div className="payment-methods additional-payment-methods">
            <button type="button" className={additionalRefundMethod === "cash" ? "selected" : ""} onClick={() => setAdditionalRefundMethod("cash")}><i>₫</i><span>Tiền mặt</span></button>
            <button type="button" className={additionalRefundMethod === "transfer" ? "selected" : ""} onClick={() => setAdditionalRefundMethod("transfer")}><i>⇄</i><span>Chuyển khoản</span></button>
          </div>
          <SpinnerButton className="primary modal-submit" disabled={additionalRefund <= 0 || additionalRefund > payingReturn.amount - payingReturn.paid} onClick={async () => { await p.api({ action: "return-payment", returnId: payingReturn.id, paymentAmount: additionalRefund, paymentMethod: additionalRefundMethod }); p.notify(`Đã hoàn thêm ${money(additionalRefund)} cho ${payingReturn.code}.`); setPayingReturn(null); await p.reload(); }}>Xác nhận hoàn tiền và ghi Sổ thu chi</SpinnerButton>
        </Modal>
      )}
    </>
  );
}

export function Warranties(p: ViewProps) {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<(typeof p.data.warranties)[number] | null>(null);
  const [busy, setBusy] = useState(false);
  const [lookupBusy, setLookupBusy] = useState(false);
  const [lookupResult, setLookupResult] = useState<Record<string, unknown> | null>(null);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [serviceFilter, setServiceFilter] = useState("all");
  const [customerQuery, setCustomerQuery] = useState("");
  const [customerPickerOpen, setCustomerPickerOpen] = useState(false);
  const blankForm = () => ({
    serviceType: "warranty",
    customerId: "",
    customerName: "",
    phone: "",
    productName: "",
    productSku: "",
    brand: "",
    model: "",
    serial: "",
    soldAt: "",
    warrantyMonths: "0",
    warrantyUntil: "",
    coverageStatus: "unknown",
    orderId: "",
    orderCode: "",
    saleNote: "",
    issue: "",
    priority: "normal",
    accessories: "",
    receivedCondition: "",
    expectedAt: "",
    estimatedCost: "0",
    note: "",
  });
  const [form, setForm] = useState(blankForm);
  const [editForm, setEditForm] = useState({
    status: "received", priority: "normal", expectedAt: "", technician: "",
    diagnosis: "", resolution: "", estimatedCost: "0", finalCost: "0",
    accessories: "", receivedCondition: "", issue: "", note: "",
  });
  const phoneKey = (value: string) => value.replace(/\D/g, "");
  const customerMatches = useMemo(() => {
    const query = customerQuery.trim().toLocaleLowerCase();
    const normalizedPhone = phoneKey(customerQuery);
    return p.data.customers
      .filter((customer) =>
        !query ||
        customer.name.toLocaleLowerCase().includes(query) ||
        (normalizedPhone.length > 0 && phoneKey(customer.phone).includes(normalizedPhone)),
      )
      .slice(0, 6);
  }, [customerQuery, p.data.customers]);
  const chooseCustomer = (customer: Customer) => {
    setCustomerQuery(`${customer.name} · ${customer.phone || "Không có SĐT"}`);
    setForm((current) => ({ ...current, customerId: customer.id, customerName: customer.name, phone: customer.phone }));
    setCustomerPickerOpen(false);
  };

  const lookupSerial = async () => {
    if (!form.serial.trim()) return p.notify("Serial / IMEI không bắt buộc. Chỉ nhập khi cần tra lịch sử bán.");
    setLookupBusy(true);
    try {
      const result = await p.api({ action: "warranty-lookup", serial: form.serial });
      setLookupResult(result);
      if (!result.found) {
        p.notify("Không tìm thấy serial trong hệ thống. Bạn vẫn có thể nhập tay và tiếp nhận máy.");
        return;
      }
      setForm((current) => ({
        ...current,
        customerId: String(result.customerId || current.customerId),
        customerName: String(result.customerName || current.customerName),
        phone: String(result.phone || current.phone),
        productName: String(result.productName || current.productName),
        productSku: String(result.productSku || current.productSku),
        brand: String(result.brand || current.brand),
        soldAt: String(result.soldAt || ""),
        warrantyMonths: String(result.warrantyMonths || 0),
        warrantyUntil: String(result.warrantyUntil || ""),
        coverageStatus: String(result.coverageStatus || "unknown"),
        orderId: String(result.orderId || ""),
        orderCode: String(result.orderCode || ""),
        saleNote: String(result.saleNote || ""),
      }));
      setCustomerQuery(result.customerName ? `${result.customerName} · ${result.phone || "Không có SĐT"}` : "");
      p.notify(result.orderId ? "Đã tìm thấy sản phẩm và lịch sử bán." : "Đã tìm thấy sản phẩm; serial này chưa gắn với đơn bán.");
    } finally {
      setLookupBusy(false);
    }
  };

  const create = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const result = await p.api({ action: "warranty-create", ...form });
      setOpen(false);
      setForm(blankForm());
      setLookupResult(null);
      setCustomerQuery("");
      p.notify(`Đã tạo phiếu ${result.code} và lưu thông tin tiếp nhận.`);
      await p.reload();
    } finally { setBusy(false); }
  };

  const openDetail = (row: (typeof p.data.warranties)[number]) => {
    setEditing(row);
    setEditForm({
      status: row.status, priority: row.priority, expectedAt: row.expectedAt,
      technician: row.technician, diagnosis: row.diagnosis, resolution: row.resolution,
      estimatedCost: String(row.estimatedCost || 0), finalCost: String(row.finalCost || 0),
      accessories: row.accessories, receivedCondition: row.receivedCondition,
      issue: row.issue, note: row.note,
    });
  };
  const update = async () => {
    if (!editing || busy) return;
    setBusy(true);
    try {
      await p.api({ action: "warranty-update", id: editing.id, ...editForm });
      setEditing(null);
      p.notify("Đã lưu tiến độ bảo hành – sửa chữa.");
      await p.reload();
    } finally { setBusy(false); }
  };

  const printReceipt = (warranty: (typeof p.data.warranties)[number]) => {
    const customer = p.data.customers.find((item) => item.id === warranty.customerId)
      || p.data.customers.find((item) => item.phone === warranty.phone);
    if (!printWarrantyReceipt(p.data.settings, warranty, customer))
      p.notify("Trình duyệt đang chặn cửa sổ in. Hãy cho phép pop-up rồi thử lại.");
  };

  const visibleRows = useMemo(() => {
    const keyword = search.trim().toLocaleLowerCase();
    return p.data.warranties.filter((row) =>
      (statusFilter === "all" || row.status === statusFilter) &&
      (serviceFilter === "all" || row.serviceType === serviceFilter) &&
      (!keyword || [row.code, row.customerName, row.phone, row.productName, row.productSku, row.serial]
        .some((value) => String(value || "").toLocaleLowerCase().includes(keyword))),
    );
  }, [p.data.warranties, search, serviceFilter, statusFilter]);
  const waitingStatuses = ["waiting_customer", "waiting_parts"];
  const coverageText = (value: string) => value === "in_warranty" ? "Còn bảo hành" : value === "out_of_warranty" ? "Hết bảo hành" : "Chưa xác định";
  const statusOptions = [
    ["received", "Đã tiếp nhận"], ["diagnosing", "Đang chẩn đoán"],
    ["waiting_customer", "Chờ khách xác nhận"], ["waiting_parts", "Chờ linh kiện"],
    ["repairing", "Đang sửa chữa"], ["completed", "Đã hoàn tất"],
    ["returned", "Đã trả khách"], ["cancelled", "Đã hủy"],
  ];
  return (
    <>
      <div className="kpis warranty-kpis">
        <Kpi
          icon="♧"
          label="Mới tiếp nhận"
          value={String(
            p.data.warranties.filter((x) => x.status === "received").length,
          )}
        />
        <Kpi
          icon="◌"
          label="Đang xử lý"
          value={String(
            p.data.warranties.filter((x) =>
              ["diagnosing", "repairing"].includes(x.status),
            ).length,
          )}
          tone="orange"
        />
        <Kpi icon="⌛" label="Đang chờ" value={String(p.data.warranties.filter((x) => waitingStatuses.includes(x.status)).length)} tone="orange" />
        <Kpi
          icon="✓"
          label="Đã trả khách"
          value={String(
            p.data.warranties.filter((x) => x.status === "returned").length,
          )}
          tone="green"
        />
      </div>
      <article className="panel page">
        <PanelTitle
          text="Bảo hành – Sửa chữa"
          sub="Tiếp nhận máy, tra lịch sử bán và theo dõi đến khi trả khách"
          action="＋ Tiếp nhận máy"
          onAction={() => { setForm(blankForm()); setLookupResult(null); setCustomerQuery(""); setOpen(true); }}
        />
        <div className="warranty-toolbar">
          <label><span>⌕</span><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Tìm mã phiếu, khách hàng, SĐT, sản phẩm, serial..." /></label>
          <select value={serviceFilter} onChange={(e) => setServiceFilter(e.target.value)} aria-label="Lọc loại dịch vụ">
            <option value="all">Tất cả dịch vụ</option><option value="warranty">Bảo hành</option><option value="repair">Sửa chữa</option>
          </select>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} aria-label="Lọc trạng thái">
            <option value="all">Tất cả trạng thái</option>{statusOptions.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
          </select>
        </div>
        <div className="table">
          <table className="warranty-table">
            <thead>
              <tr>
                <th>Mã phiếu</th>
                <th>Dịch vụ</th>
                <th>Khách hàng</th>
                <th>Thiết bị / Serial</th>
                <th>Tiếp nhận</th>
                <th>Hẹn trả</th>
                <th>Trạng thái</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {visibleRows.length ? (
                visibleRows.map((x) => (
                  <tr key={x.id} className="clickable" onClick={() => openDetail(x)}>
                    <td><b className="link">{x.code}</b><small>{formatDate(x.createdAt)}</small></td>
                    <td><span className={`warranty-service ${x.serviceType}`}>{x.serviceType === "repair" ? "Sửa chữa" : "Bảo hành"}</span><small>{x.sourceType === "sale" ? "Máy đã bán" : "Nhập thủ công"}</small></td>
                    <td>
                      <b>{x.customerName}</b>
                      <small>{x.phone}</small>
                    </td>
                    <td className="product-name-cell" title={x.productName}>
                      <b>{x.productName}</b>
                      <small>{x.productSku || "Chưa có mã"} · {x.serial || "Không serial"}</small>
                    </td>
                    <td className="warranty-issue" title={x.issue}>{x.issue}<small>{x.priority === "urgent" ? "Ưu tiên khẩn" : x.priority === "high" ? "Ưu tiên cao" : "Ưu tiên thường"}</small></td>
                    <td>{x.expectedAt ? formatDate(x.expectedAt) : "—"}</td>
                    <td>
                      <Status value={x.status} />
                    </td>
                    <td>
                      <div className="warranty-row-actions">
                        <button className="warranty-detail-button" onClick={(event) => { event.stopPropagation(); openDetail(x); }}>Chi tiết</button>
                        <button className="warranty-print-button" title="In phiếu tiếp nhận" onClick={(event) => { event.stopPropagation(); printReceipt(x); }}>In</button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8}>
                    <Empty text={search || statusFilter !== "all" || serviceFilter !== "all" ? "Không có phiếu phù hợp" : "Chưa có phiếu bảo hành – sửa chữa"} />
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </article>
      {open && (
        <Modal title="Tiếp nhận máy bảo hành – sửa chữa" onClose={() => setOpen(false)} wide className="warranty-modal">
          <div className="warranty-section-title"><b>1. Phân loại & tra cứu</b><span>Serial / IMEI không bắt buộc</span></div>
          <div className="form-grid warranty-reception-grid">
            <Field label="Loại dịch vụ">
              <select value={form.serviceType} onChange={(e) => setForm({ ...form, serviceType: e.target.value })}><option value="warranty">Bảo hành</option><option value="repair">Sửa chữa dịch vụ</option></select>
            </Field>
            <Field label="Mức ưu tiên">
              <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}><option value="normal">Bình thường</option><option value="high">Cao</option><option value="urgent">Khẩn</option></select>
            </Field>
            <Field label="Serial / IMEI (tùy chọn)" wide>
              <div className="warranty-serial-lookup"><input value={form.serial} onChange={(e) => { setForm({ ...form, serial: e.target.value }); setLookupResult(null); }} placeholder="Nhập serial để tự động lấy sản phẩm, đơn bán và khách hàng" autoComplete="off" /><SpinnerButton onClick={lookupSerial} disabled={lookupBusy}>{lookupBusy ? "Đang tra..." : "Tra cứu"}</SpinnerButton></div>
            </Field>
          </div>
          {lookupResult && <div className={`warranty-lookup-card ${lookupResult.found ? "found" : "not-found"}`}>
            <b>{lookupResult.found ? "✓ Đã tìm thấy dữ liệu trong hệ thống" : "Không tìm thấy lịch sử serial"}</b>
            {lookupResult.found ? <div><span><small>Sản phẩm</small><strong>{String(lookupResult.productName || "—")} · {String(lookupResult.productSku || "")}</strong></span><span><small>Đơn bán / ngày bán</small><strong>{String(lookupResult.orderCode || "Chưa có đơn bán")} · {lookupResult.soldAt ? formatDate(String(lookupResult.soldAt)) : "—"}</strong></span><span><small>Khách hàng</small><strong>{String(lookupResult.customerName || "Chưa có")} · {String(lookupResult.phone || "")}</strong></span><span><small>Thời hạn</small><strong>{coverageText(String(lookupResult.coverageStatus || "unknown"))}{lookupResult.warrantyUntil ? ` · đến ${formatDate(String(lookupResult.warrantyUntil))}` : ""}</strong></span>{lookupResult.saleNote ? <span className="wide"><small>Ghi chú đơn bán / thời hạn bảo hành</small><strong>{String(lookupResult.saleNote)}</strong></span> : null}</div> : <small>Tiếp tục điền thông tin thủ công để tạo phiếu sửa chữa hoặc bảo hành ngoài hệ thống.</small>}
          </div>}
          <div className="warranty-section-title"><b>2. Khách hàng</b><span>Có thể chọn khách cũ hoặc nhập tay</span></div>
          <div className="form-grid">
            <Field label="Khách hàng">
              <div className="warranty-customer-picker">
                <input
                  value={customerQuery || form.customerName}
                  onFocus={() => setCustomerPickerOpen(true)}
                  onChange={(e) => {
                    setCustomerQuery(e.target.value);
                    setCustomerPickerOpen(true);
                    setForm({ ...form, customerId: "", customerName: e.target.value });
                  }}
                  placeholder="Gõ tên hoặc số điện thoại khách hàng"
                  autoComplete="off"
                />
                {customerPickerOpen && customerMatches.length > 0 && (
                  <div className="warranty-customer-results">
                    {customerMatches.map((customer) => (
                      <button type="button" key={customer.id} onMouseDown={(e) => e.preventDefault()} onClick={() => chooseCustomer(customer)}>
                        <b>{customer.name}</b>
                        <span>{customer.phone || "Chưa có số điện thoại"}</span>
                      </button>
                    ))}
                  </div>
                )}
                {customerPickerOpen && customerQuery.trim() && !customerMatches.length && <small className="warranty-customer-empty">Không có khách cũ phù hợp — tên này sẽ được lưu trên phiếu.</small>}
              </div>
            </Field>
            <Field label="Số điện thoại">
              <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="Số điện thoại liên hệ" />
            </Field>
          </div>
          <div className="warranty-section-title"><b>3. Thông tin thiết bị</b><span>Các trường tự động vẫn có thể bổ sung khi thiếu</span></div>
          <div className="form-grid">
            <Field label="Tên thiết bị" wide><input value={form.productName} onChange={(e) => setForm({ ...form, productName: e.target.value })} placeholder="Ví dụ: Laptop Dell Latitude 5420" /></Field>
            <Field label="Mã sản phẩm"><input value={form.productSku} onChange={(e) => setForm({ ...form, productSku: e.target.value })} placeholder="SKU / mã máy" /></Field>
            <Field label="Hãng / Model"><div className="warranty-inline-inputs"><input value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} placeholder="Hãng" /><input value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} placeholder="Model" /></div></Field>
            <Field label="Ngày bán"><input type="date" value={form.soldAt ? form.soldAt.slice(0, 10) : ""} onChange={(e) => setForm({ ...form, soldAt: e.target.value })} /></Field>
            <Field label="Bảo hành (tháng)"><input type="number" min="0" value={form.warrantyMonths} onChange={(e) => setForm({ ...form, warrantyMonths: e.target.value })} /></Field>
            {form.saleNote && <Field label="Ghi chú đơn bán" wide><div className="warranty-readonly-note">{form.saleNote}</div></Field>}
          </div>
          <div className="warranty-section-title"><b>4. Biên bản tiếp nhận</b><span>Ghi rõ để đối chiếu khi trả máy</span></div>
          <div className="form-grid">
            <Field label="Tình trạng / lỗi khách báo" wide>
              <textarea value={form.issue} onChange={(e) => setForm({ ...form, issue: e.target.value })} placeholder="Mô tả lỗi, tần suất, hoàn cảnh phát sinh..." />
            </Field>
            <Field label="Ngoại quan khi nhận"><textarea value={form.receivedCondition} onChange={(e) => setForm({ ...form, receivedCondition: e.target.value })} placeholder="Xước, móp, nứt, tem niêm phong..." /></Field>
            <Field label="Phụ kiện nhận kèm"><textarea value={form.accessories} onChange={(e) => setForm({ ...form, accessories: e.target.value })} placeholder="Sạc, túi, pin, chuột..." /></Field>
            <Field label="Ngày hẹn trả">
              <input type="date" value={form.expectedAt} onChange={(e) => setForm({ ...form, expectedAt: e.target.value })} />
            </Field>
            <Field label="Chi phí dự kiến">
              <input type="number" min="0" step="1000" value={form.estimatedCost} onChange={(e) => setForm({ ...form, estimatedCost: e.target.value })} />
            </Field>
            <Field label="Ghi chú nội bộ" wide><textarea value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} /></Field>
          </div>
          <SpinnerButton className="primary modal-submit" disabled={busy} onClick={create}>{busy ? "Đang lưu..." : "Tạo phiếu tiếp nhận"}</SpinnerButton>
        </Modal>
      )}
      {editing && (
        <Modal title={`${editing.code} · ${editing.serviceType === "repair" ? "Sửa chữa" : "Bảo hành"}`} onClose={() => setEditing(null)} wide className="warranty-modal">
          <div className="warranty-detail-summary">
            <div><small>Khách hàng</small><b>{editing.customerName}</b><span>{editing.phone}</span></div>
            <div><small>Thiết bị</small><b>{editing.productName}</b><span>{editing.productSku || "Chưa có mã"} · {editing.serial || "Không serial"}</span></div>
            <div><small>Nguồn máy</small><b>{editing.sourceType === "sale" ? `Đơn ${editing.orderCode}` : "Nhập thủ công"}</b><span>{editing.soldAt ? `Bán ${formatDate(editing.soldAt)}` : "Không có ngày bán"}</span></div>
            <div><small>Bảo hành</small><b>{coverageText(editing.coverageStatus)}</b><span>{editing.warrantyUntil ? `Đến ${formatDate(editing.warrantyUntil)}` : `${editing.warrantyMonths || 0} tháng`}</span></div>
          </div>
          {editing.saleNote && <div className="warranty-sale-note"><b>Ghi chú đơn bán:</b> {editing.saleNote}</div>}
          <div className="warranty-section-title"><b>Cập nhật xử lý</b><span>Lưu lại chẩn đoán, phương án và chi phí thực tế</span></div>
          <div className="form-grid">
            <Field label="Trạng thái"><select value={editForm.status} onChange={(e) => setEditForm({ ...editForm, status: e.target.value })}>{statusOptions.map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></Field>
            <Field label="Mức ưu tiên"><select value={editForm.priority} onChange={(e) => setEditForm({ ...editForm, priority: e.target.value })}><option value="normal">Bình thường</option><option value="high">Cao</option><option value="urgent">Khẩn</option></select></Field>
            <Field label="Kỹ thuật viên"><input value={editForm.technician} onChange={(e) => setEditForm({ ...editForm, technician: e.target.value })} placeholder="Người phụ trách" /></Field>
            <Field label="Hẹn trả"><input type="date" value={editForm.expectedAt} onChange={(e) => setEditForm({ ...editForm, expectedAt: e.target.value })} /></Field>
            <Field label="Lỗi / tình trạng khách báo" wide><textarea value={editForm.issue} onChange={(e) => setEditForm({ ...editForm, issue: e.target.value })} /></Field>
            <Field label="Chẩn đoán kỹ thuật"><textarea value={editForm.diagnosis} onChange={(e) => setEditForm({ ...editForm, diagnosis: e.target.value })} placeholder="Nguyên nhân, kết quả kiểm tra..." /></Field>
            <Field label="Phương án / kết quả xử lý"><textarea value={editForm.resolution} onChange={(e) => setEditForm({ ...editForm, resolution: e.target.value })} placeholder="Hạng mục sửa, linh kiện thay..." /></Field>
            <Field label="Ngoại quan khi nhận"><textarea value={editForm.receivedCondition} onChange={(e) => setEditForm({ ...editForm, receivedCondition: e.target.value })} /></Field>
            <Field label="Phụ kiện nhận kèm"><textarea value={editForm.accessories} onChange={(e) => setEditForm({ ...editForm, accessories: e.target.value })} /></Field>
            <Field label="Chi phí dự kiến"><input type="number" min="0" step="1000" value={editForm.estimatedCost} onChange={(e) => setEditForm({ ...editForm, estimatedCost: e.target.value })} /></Field>
            <Field label="Chi phí thực tế"><input type="number" min="0" step="1000" value={editForm.finalCost} onChange={(e) => setEditForm({ ...editForm, finalCost: e.target.value })} /></Field>
            <Field label="Ghi chú nội bộ" wide><textarea value={editForm.note} onChange={(e) => setEditForm({ ...editForm, note: e.target.value })} /></Field>
          </div>
          <div className="warranty-detail-actions">
            <button className="warranty-print-full" type="button" onClick={() => printReceipt(editing)}>⌑ In phiếu tiếp nhận</button>
            <SpinnerButton className="primary" disabled={busy} onClick={update}>{busy ? "Đang lưu..." : "Lưu cập nhật"}</SpinnerButton>
          </div>
        </Modal>
      )}
    </>
  );
}

function PeopleModal({
  kind,
  item,
  onClose,
  onSaved,
  p,
}: {
  kind: "customer" | "supplier";
  item?: Customer | Supplier;
  onClose: () => void;
  onSaved?: (id: string, name: string) => void;
  p: ViewProps;
}) {
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [form, setForm] = useState({
    name: item?.name || "",
    phone: item?.phone || "",
    email: item?.email || "",
    address: item?.address || "",
    code: (item as Supplier)?.code || "",
  });
  const save = async () => {
    if (saving || deleting) return;
    setSaving(true);
    try {
      const result = await p.api({ action: kind, id: item?.id, ...form });
      const savedId = String(result.id || item?.id || "");
      await p.reload();
      onSaved?.(savedId, form.name.trim());
      onClose();
      p.notify(
        kind === "customer" ? "Đã lưu khách hàng." : "Đã lưu nhà cung cấp.",
      );
    } catch (error) {
      p.notify(error instanceof Error ? error.message : "Không thể lưu thông tin.");
    } finally {
      setSaving(false);
    }
  };
  const removePerson = async () => {
    if (!item || saving || deleting) return;
    setDeleting(true);
    try {
      await p.api({
        action: kind === "customer" ? "customer-delete" : "supplier-delete",
        id: item.id,
      });
      await p.reload();
      onClose();
      p.notify(
        `Đã xóa ${kind === "customer" ? "khách hàng" : "nhà cung cấp"} ${item.name}.`,
      );
    } catch (error) {
      setConfirmDelete(false);
      p.notify(
        error instanceof Error
          ? error.message
          : `Không thể xóa ${kind === "customer" ? "khách hàng" : "nhà cung cấp"}.`,
      );
    } finally {
      setDeleting(false);
    }
  };
  return (
    <Modal
      title={`${item ? "Sửa" : "Thêm"} ${kind === "customer" ? "khách hàng" : "nhà cung cấp"}`}
      onClose={onClose}
    >
      <div className="form-grid">
        {kind === "supplier" && (
          <Field label="Mã NCC">
            <input
              value={form.code}
              onChange={(e) => setForm({ ...form, code: e.target.value })}
            />
          </Field>
        )}
        <Field label="Tên">
          <input
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
        </Field>
        <Field label="Số điện thoại">
          <input
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
          />
        </Field>
        <Field label="Email">
          <input
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
          />
        </Field>
        <Field label="Địa chỉ" wide>
          <input
            value={form.address}
            onChange={(e) => setForm({ ...form, address: e.target.value })}
          />
        </Field>
      </div>
      {item && confirmDelete && (
        <div className="supplier-delete-confirm" role="alert">
          <div>
            <b>
              Xóa {kind === "customer" ? "khách hàng" : "nhà cung cấp"} này?
            </b>
            <span>
              <strong>{item.name}</strong> sẽ bị xóa khỏi danh sách nếu chưa
              phát sinh giao dịch. Thao tác này không thể hoàn tác.
            </span>
          </div>
          <div>
            <button
              type="button"
              className="secondary"
              disabled={deleting}
              onClick={() => setConfirmDelete(false)}
            >
              Không xóa
            </button>
            <button
              type="button"
              className="danger-button supplier-delete-final"
              disabled={deleting}
              onClick={removePerson}
            >
              {deleting ? "Đang xóa..." : "Xác nhận xóa"}
            </button>
          </div>
        </div>
      )}
      <div className={`people-modal-actions ${item ? "has-delete" : ""}`}>
        {item && (
          <button
            type="button"
            className="danger-button"
            disabled={saving || deleting}
            onClick={() => setConfirmDelete(true)}
          >
            Xóa {kind === "customer" ? "khách hàng" : "nhà cung cấp"}
          </button>
        )}
        <button
          className="primary"
          disabled={saving || deleting}
          onClick={save}
        >
          {saving ? "Đang lưu..." : "Lưu thông tin"}
        </button>
      </div>
    </Modal>
  );
}

type PartnerDetailsTarget = {
  type: "customer" | "supplier";
  id?: string;
  name: string;
};

type PartnerDetailsData = {
  partner: {
    id: string;
    code?: string;
    name: string;
    phone: string;
    email: string;
    address: string;
    createdAt: string;
  };
  documents: Array<{
    id: string;
    code: string;
    total: number;
    paid: number;
    status: string;
    happenedAt: string;
  }>;
};

function PartnerDetailsModal({
  target,
  onClose,
  onOpenDocument,
}: {
  target: PartnerDetailsTarget;
  onClose: () => void;
  onOpenDocument: (type: "order" | "purchase", id: string) => void;
}) {
  const [data, setData] = useState<PartnerDetailsData | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const controller = new AbortController();
    const params = new URLSearchParams({
      type: target.type,
      name: target.name,
    });
    if (target.id) params.set("id", target.id);

    void fetch(`/api/partner-details?${params.toString()}`, {
      cache: "no-store",
      signal: controller.signal,
    })
      .then(async (response) => {
        const result = (await response.json()) as PartnerDetailsData & {
          error?: string;
        };
        if (!response.ok) throw new Error(result.error || "Không thể tải dữ liệu.");
        setData(result);
      })
      .catch((reason: unknown) => {
        if (reason instanceof DOMException && reason.name === "AbortError") return;
        setError(
          reason instanceof Error
            ? reason.message
            : "Không thể tải thông tin đối tượng.",
        );
      });

    return () => controller.abort();
  }, [target.id, target.name, target.type]);

  const partnerLabel =
    target.type === "customer" ? "Khách hàng" : "Nhà cung cấp";
  const documentLabel =
    target.type === "customer" ? "đơn hàng" : "phiếu nhập";

  return (
    <Modal
      title={`Chi tiết ${partnerLabel.toLocaleLowerCase("vi")}`}
      onClose={onClose}
      wide
      className="partner-details-modal"
    >
      {!data && !error && (
        <div className="partner-details-loading">Đang tải thông tin và lịch sử…</div>
      )}
      {error && (
        <div className="partner-details-error" role="alert">
          {error}
        </div>
      )}
      {data && (
        <>
          <section className="partner-profile">
            <i>{data.partner.name.slice(0, 1).toUpperCase()}</i>
            <div className="partner-profile-main">
              <span className={`partner-type-badge ${target.type}`}>
                {partnerLabel}
              </span>
              <h3>{data.partner.name}</h3>
              {target.type === "supplier" && data.partner.code && (
                <small>Mã NCC: {data.partner.code}</small>
              )}
            </div>
            <div className="partner-profile-meta">
              <p>
                <small>Số điện thoại</small>
                <b>{data.partner.phone || "Chưa cập nhật"}</b>
              </p>
              <p>
                <small>Email</small>
                <b>{data.partner.email || "Chưa cập nhật"}</b>
              </p>
              <p>
                <small>Địa chỉ</small>
                <b>{data.partner.address || "Chưa cập nhật"}</b>
              </p>
              <p>
                <small>Ngày tạo hồ sơ</small>
                <b>{data.partner.createdAt ? formatDate(data.partner.createdAt) : "Chưa có hồ sơ"}</b>
              </p>
            </div>
          </section>

          <div className="partner-history-heading">
            <div>
              <h3>Lịch sử {documentLabel}</h3>
              <p>Mới nhất trước · {data.documents.length} chứng từ</p>
            </div>
            <span>Tối đa 10 dòng trong khung, cuộn để xem thêm</span>
          </div>
          <div className="partner-history-scroll">
            <table>
              <thead>
                <tr>
                  <th>{target.type === "customer" ? "Mã đơn" : "Mã phiếu"}</th>
                  <th>Ngày giờ</th>
                  <th>Tổng tiền</th>
                  <th>Đã thanh toán</th>
                  <th>Còn lại</th>
                  <th>Trạng thái</th>
                </tr>
              </thead>
              <tbody>
                {data.documents.map((document) => (
                  <tr key={document.id}>
                    <td>
                      <button
                        type="button"
                        className="partner-document-link"
                        onClick={() =>
                          onOpenDocument(
                            target.type === "customer" ? "order" : "purchase",
                            document.id,
                          )
                        }
                        title={`Mở chi tiết ${document.code}`}
                      >
                        {document.code}
                      </button>
                    </td>
                    <td>{formatDate(document.happenedAt)}</td>
                    <td>{money(document.total)}</td>
                    <td>{money(document.paid)}</td>
                    <td className={document.total > document.paid ? "red" : ""}>
                      {money(Math.max(0, document.total - document.paid))}
                    </td>
                    <td>
                      <Status value={document.status} />
                    </td>
                  </tr>
                ))}
                {!data.documents.length && (
                  <tr>
                    <td className="partner-history-empty" colSpan={6}>
                      Chưa có {documentLabel} liên quan đến đối tượng này.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </>
      )}
    </Modal>
  );
}

export function Customers(p: ViewProps) {
  const [open, setOpen] = useState<Customer | true | false>(false);
  const [details, setDetails] = useState<PartnerDetailsTarget | null>(null);
  const [importOpen, setImportOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [importBusy, setImportBusy] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const downloadWorkbook = async (
    filename: string,
    rows: Array<Record<string, string | number>>,
  ) => {
    const XLSX = await import("xlsx");
    const sheet = XLSX.utils.json_to_sheet(rows);
    sheet["!cols"] = [
      { wch: 16 },
      { wch: 28 },
      { wch: 18 },
      { wch: 32 },
      { wch: 42 },
      { wch: 12 },
      { wch: 18 },
    ];
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheet, "Khách hàng");
    const output = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const url = URL.createObjectURL(
      new Blob([output], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      }),
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };
  const downloadTemplate = async () => {
    await downloadWorkbook("Mau_nhap_khach_hang.xlsx", [
      {
        "Mã khách hàng": "",
        "Tên khách hàng": "Nguyễn Văn A",
        "Số điện thoại": "0901234567",
        Email: "",
        "Địa chỉ": "",
      },
    ]);
  };
  const exportCustomers = async () => {
    const rows = p.data.customers.map((customer) => {
      const orders = p.data.orders.filter(
        (order) => order.customerId === customer.id && order.status !== "cancelled",
      );
      return {
        "Mã khách hàng": customer.code,
        "Tên khách hàng": customer.name,
        "Số điện thoại": customer.phone,
        Email: customer.email,
        "Địa chỉ": customer.address,
        "Số đơn": orders.length,
        "Tổng mua": orders.reduce((sum, order) => sum + order.total, 0),
      };
    });
    await downloadWorkbook(
      `Danh_sach_khach_hang_${new Date().toISOString().slice(0, 10).replaceAll("-", "")}.xlsx`,
      rows,
    );
  };
  const importCustomers = async () => {
    if (!selectedFile) return;
    setImportBusy(true);
    try {
      const extension = selectedFile.name.split(".").pop()?.toLowerCase();
      if (!extension || !["xlsx", "xls", "csv"].includes(extension))
        throw new Error("Chỉ hỗ trợ file Excel (.xlsx, .xls) hoặc CSV.");
      if (selectedFile.size > 2 * 1024 * 1024)
        throw new Error("Dung lượng file tối đa là 2 MB.");
      const XLSX = await import("xlsx");
      const workbook = XLSX.read(await selectedFile.arrayBuffer(), { type: "array" });
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      if (!firstSheet) throw new Error("Không tìm thấy trang dữ liệu trong file.");
      const sourceRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(firstSheet, {
        defval: "",
        raw: false,
      });
      const hasRequiredColumns = sourceRows.length
        ? Object.prototype.hasOwnProperty.call(sourceRows[0], "Tên khách hàng") &&
          Object.prototype.hasOwnProperty.call(sourceRows[0], "Số điện thoại")
        : false;
      if (!hasRequiredColumns)
        throw new Error("File cần có đúng các cột Tên khách hàng và Số điện thoại.");
      const customers = sourceRows
        .map((row) => ({
          code: String(row["Mã khách hàng"] || "").trim(),
          name: String(row["Tên khách hàng"] || "").trim(),
          phone: String(row["Số điện thoại"] || "").trim(),
          email: String(row.Email || "").trim(),
          address: String(row["Địa chỉ"] || "").trim(),
        }))
        .filter((row) => row.code || row.name || row.phone || row.email || row.address);
      if (!customers.length) throw new Error("File chưa có dòng khách hàng hợp lệ.");
      if (customers.length > 1000)
        throw new Error("Mỗi lần chỉ được nhập tối đa 1.000 khách hàng.");
      const result = await p.api({ action: "customer-import", customers });
      const added = Number(result.added) || 0;
      const skipped = Number(result.skipped) || 0;
      p.notify(
        added
          ? `Đã thêm ${added} khách hàng${skipped ? `, bỏ qua ${skipped} dòng trùng hoặc sai dữ liệu` : ""}.`
          : `Không thêm khách hàng nào. Đã bỏ qua ${skipped} dòng trùng hoặc sai dữ liệu.`,
      );
      setImportOpen(false);
      setSelectedFile(null);
      await p.reload();
    } catch (error) {
      p.notify(error instanceof Error ? error.message : "Không thể nhập file khách hàng.");
    } finally {
      setImportBusy(false);
    }
  };
  const remove = async (customer: Customer) => {
    if (!confirm(`Xóa khách hàng ${customer.name}?\n\nChỉ khách hàng chưa phát sinh giao dịch mới được phép xóa.`)) return;
    try {
      await p.api({ action: "customer-delete", id: customer.id });
      p.notify(`Đã xóa khách hàng ${customer.name}.`);
      await p.reload();
    } catch (error) {
      p.notify(error instanceof Error ? error.message : "Không thể xóa khách hàng.");
    }
  };
  return (
    <>
      <article className="panel page">
        <div className="section-title customer-title">
          <div>
            <h2>Khách hàng</h2>
            <p>Thông tin và lịch sử mua hàng</p>
          </div>
          <div className="customer-file-actions">
            <button type="button" onClick={() => void exportCustomers()}>⇩ Xuất file</button>
            <button type="button" onClick={() => { setSelectedFile(null); setImportOpen(true); }}>⇧ Nhập file</button>
            <button type="button" className="primary" onClick={() => setOpen(true)}>＋ Thêm khách hàng</button>
          </div>
        </div>
        <div className="table">
          <table>
            <thead>
              <tr>
                <th>Mã khách hàng</th>
                <th>Tên khách hàng</th>
                <th>Liên hệ</th>
                <th>Số đơn</th>
                <th>Tổng mua</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {p.data.customers.map((x) => {
                const orders = p.data.orders.filter(
                  (o) => o.customerId === x.id && o.status !== "cancelled",
                );
                return (
                  <tr key={x.id}>
                    <td>{x.code}</td>
                    <td>
                      <button
                        type="button"
                        className="partner-name-button"
                        onClick={() =>
                          setDetails({ type: "customer", id: x.id, name: x.name })
                        }
                      >
                        {x.name}
                      </button>
                      <small>{x.address || "Chưa có địa chỉ"}</small>
                    </td>
                    <td>
                      {x.phone || "Chưa có số điện thoại"}
                      <small>{x.email || "Chưa có email"}</small>
                    </td>
                    <td>{orders.length}</td>
                    <td>{money(orders.reduce((s, o) => s + o.total, 0))}</td>
                    <td>
                      <div className="row-actions">
                        <button className="link-button" onClick={() => setOpen(x)}>
                          Sửa
                        </button>
                        <button className="danger-link" onClick={() => void remove(x)}>
                          Xóa
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {!p.data.customers.length && (
                <tr>
                  <td colSpan={6}>
                    <Empty text="Chưa có khách hàng" />
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </article>
      {open && (
        <PeopleModal
          kind="customer"
          item={open === true ? undefined : open}
          onClose={() => setOpen(false)}
          p={p}
        />
      )}
      {details && (
        <PartnerDetailsModal
          target={details}
          onClose={() => setDetails(null)}
          onOpenDocument={(type, id) => {
            setDetails(null);
            p.openDocument(type, id);
          }}
        />
      )}
      {importOpen && (
        <Modal title="Nhập khách hàng từ file" onClose={() => !importBusy && setImportOpen(false)}>
          <div className="customer-import-options">
            <button type="button" onClick={() => void downloadTemplate()}>
              <i>⇩</i>
              <span><b>Tải file mẫu</b><small>Tệp Excel có sẵn đúng tên cột để nhập.</small></span>
            </button>
            <button type="button" onClick={() => fileInput.current?.click()}>
              <i>⇧</i>
              <span><b>Tải file lên</b><small>Chọn file khách hàng đã điền dữ liệu.</small></span>
            </button>
          </div>
          <input
            ref={fileInput}
            className="customer-file-input"
            type="file"
            accept=".xlsx,.xls,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,text/csv"
            onChange={(event) => setSelectedFile(event.target.files?.[0] || null)}
          />
          <div className="customer-import-rules">
            <b>Quy định file nhập</b>
            <p>Hỗ trợ <strong>.xlsx, .xls, .csv</strong>; dung lượng tối đa <strong>2 MB</strong>, tối đa <strong>1.000 dòng</strong>.</p>
            <p>Hai cột bắt buộc: <strong>Tên khách hàng</strong>, <strong>Số điện thoại</strong>. Các cột tùy chọn: Mã khách hàng, Email, Địa chỉ.</p>
            <p>Dòng trùng số điện thoại, trùng mã hoặc sai định dạng sẽ được bỏ qua; dữ liệu khách hàng có sẵn không bị ghi đè.</p>
          </div>
          {selectedFile && (
            <div className="customer-file-selected">
              <span>✓</span>
              <div><b>{selectedFile.name}</b><small>{(selectedFile.size / 1024).toFixed(1)} KB</small></div>
              <button type="button" aria-label="Bỏ file đã chọn" disabled={importBusy} onClick={() => setSelectedFile(null)}>×</button>
            </div>
          )}
          <SpinnerButton className="primary modal-submit" busy={importBusy} disabled={!selectedFile} onClick={importCustomers}>
            Nhập khách hàng
          </SpinnerButton>
        </Modal>
      )}
    </>
  );
}
export function Suppliers(p: ViewProps) {
  const [open, setOpen] = useState<Supplier | true | false>(false);
  const [details, setDetails] = useState<PartnerDetailsTarget | null>(null);
  const remove = async (supplier: Supplier) => {
    if (!confirm(`Xóa nhà cung cấp ${supplier.name}?\n\nChỉ nhà cung cấp chưa phát sinh giao dịch mới được phép xóa.`)) return;
    try {
      await p.api({ action: "supplier-delete", id: supplier.id });
      p.notify(`Đã xóa nhà cung cấp ${supplier.name}.`);
      await p.reload();
    } catch (error) {
      p.notify(error instanceof Error ? error.message : "Không thể xóa nhà cung cấp.");
    }
  };
  return (
    <>
      <article className="panel page">
        <PanelTitle
          text="Nhà cung cấp"
          sub="Danh bạ và lịch sử nhập hàng"
          action="＋ Thêm nhà cung cấp"
          onAction={() => setOpen(true)}
        />
        <div className="table">
          <table>
            <thead>
              <tr>
                <th>Mã NCC</th>
                <th>Tên nhà cung cấp</th>
                <th>Liên hệ</th>
                <th>Số phiếu nhập</th>
                <th>Tổng nhập</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {p.data.suppliers.map((x) => {
                const rows = p.data.purchases.filter(
                  (y) =>
                    y.supplierId === x.id &&
                    y.status !== "purchase_returned",
                );
                return (
                  <tr key={x.id}>
                    <td>{x.code}</td>
                    <td>
                      <button
                        type="button"
                        className="partner-name-button"
                        onClick={() =>
                          setDetails({ type: "supplier", id: x.id, name: x.name })
                        }
                      >
                        {x.name}
                      </button>
                      <small>{x.address}</small>
                    </td>
                    <td>
                      {x.phone}
                      <small>{x.email}</small>
                    </td>
                    <td>{rows.length}</td>
                    <td>{money(rows.reduce((s, y) => s + y.total, 0))}</td>
                    <td>
                      <div className="row-actions">
                        <button
                          className="link-button"
                          onClick={() => setOpen(x)}
                        >
                          Sửa
                        </button>
                        <button
                          className="danger-link"
                          onClick={() => void remove(x)}
                        >
                          Xóa
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </article>
      {open && (
        <PeopleModal
          kind="supplier"
          item={open === true ? undefined : open}
          onClose={() => setOpen(false)}
          p={p}
        />
      )}
      {details && (
        <PartnerDetailsModal
          target={details}
          onClose={() => setDetails(null)}
          onOpenDocument={(type, id) => {
            setDetails(null);
            p.openDocument(type, id);
          }}
        />
      )}
    </>
  );
}

export function Debts(p: ViewProps) {
  const [open, setOpen] = useState(false);
  const [details, setDetails] = useState<PartnerDetailsTarget | null>(null);
  const [payId, setPayId] = useState("");
  const [pay, setPay] = useState(0);
  const [payMethod, setPayMethod] = useState("transfer");
  const [form, setForm] = useState({
    partnerType: "customer",
    partnerName: "",
    reference: "",
    total: 0,
    paid: 0,
    dueDate: "",
  });
  const activeDebt = p.data.debts.find((item) => item.id === payId);
  const create = async () => {
    await p.api({ action: "debt-create", ...form });
    setOpen(false);
    p.notify("Đã tạo khoản công nợ.");
    await p.reload();
  };
  const settle = async () => {
    await p.api({
      action: "debt-pay",
      id: payId,
      amount: pay,
      paymentMethod: payMethod,
    });
    setPayId("");
    p.notify("Đã ghi nhận thanh toán công nợ và cập nhật sổ quỹ.");
    await p.reload();
  };
  return (
    <>
      <div className="three">
        <Kpi
          icon="↓"
          label="Khách còn nợ"
          value={money(
            p.data.debts
              .filter((x) => x.settlementType === "income")
              .reduce((s, x) => s + x.total - x.paid, 0),
          )}
          tone="orange"
        />
        <Kpi
          icon="↑"
          label="Còn nợ NCC"
          value={money(
            p.data.debts
              .filter((x) => x.settlementType === "expense")
              .reduce((s, x) => s + x.total - x.paid, 0),
          )}
          tone="purple"
        />
        <Kpi
          icon="✓"
          label="Đã tất toán"
          value={String(p.data.debts.filter((x) => x.status === "paid").length)}
          tone="green"
        />
      </div>
      <article className="panel page">
        <PanelTitle
          text="Công nợ"
          sub="Theo dõi phải thu và phải trả"
          action="＋ Thêm công nợ"
          onAction={() => setOpen(true)}
        />
        <div className="table">
          <table>
            <thead>
              <tr>
                <th>Đối tác</th>
                <th>Đối tượng</th>
                <th>Loại công nợ</th>
                <th>Tham chiếu</th>
                <th>Tổng</th>
                <th>Đã trả</th>
                <th>Còn lại</th>
                <th>Hạn trả</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {p.data.debts.map((x) => (
                <tr key={x.id}>
                  <td>
                    <button
                      type="button"
                      className="partner-name-button"
                      onClick={() =>
                        setDetails({
                          type:
                            x.partnerType === "supplier"
                              ? "supplier"
                              : "customer",
                          name: x.partnerName,
                        })
                      }
                    >
                      {x.partnerName}
                    </button>
                  </td>
                  <td>
                    <span
                      className={`partner-type-badge ${
                        x.partnerType === "supplier" ? "supplier" : "customer"
                      }`}
                    >
                      {x.partnerType === "supplier"
                        ? "Nhà cung cấp"
                        : "Khách hàng"}
                    </span>
                  </td>
                  <td>
                    {x.settlementType === "income" ? "Phải thu" : "Phải trả"}
                  </td>
                  <td>{x.reference || "—"}</td>
                  <td>{money(x.total)}</td>
                  <td>{money(x.paid)}</td>
                  <td className="red">{money(x.total - x.paid)}</td>
                  <td>{x.dueDate || "—"}</td>
                  <td>
                    {x.status !== "paid" ? (
                      <button
                        className="link-button"
                        onClick={() => {
                          setPayId(x.id);
                          setPay(x.total - x.paid);
                          setPayMethod("transfer");
                        }}
                      >
                        {x.settlementType === "income" ? "Thu tiền" : "Trả tiền"}
                      </button>
                    ) : (
                      <Status value="paid" />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </article>
      {open && (
        <Modal title="Thêm khoản công nợ" onClose={() => setOpen(false)}>
          <div className="form-grid">
            <Field label="Loại công nợ">
              <select
                value={form.partnerType}
                onChange={(e) =>
                  setForm({ ...form, partnerType: e.target.value })
                }
              >
                <option value="customer">Khách hàng nợ</option>
                <option value="supplier">Nợ nhà cung cấp</option>
              </select>
            </Field>
            <Field label="Tên đối tác">
              <input
                value={form.partnerName}
                onChange={(e) =>
                  setForm({ ...form, partnerName: e.target.value })
                }
              />
            </Field>
            <Field label="Tham chiếu">
              <input
                value={form.reference}
                onChange={(e) =>
                  setForm({ ...form, reference: e.target.value })
                }
              />
            </Field>
            <Field label="Hạn thanh toán">
              <input
                type="date"
                value={form.dueDate}
                onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
              />
            </Field>
            <Field label="Tổng tiền">
              <MoneyInput value={form.total} ariaLabel="Tổng tiền công nợ" onValueChange={(total) => setForm({ ...form, total })} />
            </Field>
            <Field label="Đã trả">
              <MoneyInput value={form.paid} max={form.total} ariaLabel="Đã trả công nợ" onValueChange={(paid) => setForm({ ...form, paid })} />
            </Field>
          </div>
          <button className="primary modal-submit" onClick={create}>
            Lưu công nợ
          </button>
        </Modal>
      )}
      {payId && (
        <Modal
          title={activeDebt?.settlementType === "income" ? "Thu công nợ" : "Trả công nợ"}
          onClose={() => setPayId("")}
        >
          {activeDebt && (
            <div className="debt-settlement-summary">
              <span>{activeDebt.partnerName}</span>
              <b>{money(activeDebt.total - activeDebt.paid)}</b>
              <small>{activeDebt.reference || "Công nợ không có tham chiếu"}</small>
            </div>
          )}
          <Field label={activeDebt?.settlementType === "income" ? "Số tiền thực thu" : "Số tiền thực trả"}>
            <MoneyInput value={pay} max={Math.max(0, (activeDebt?.total || 0) - (activeDebt?.paid || 0))} ariaLabel="Số tiền thanh toán công nợ" onValueChange={setPay} />
          </Field>
          <Field label="Phương thức thanh toán">
            <select
              value={payMethod}
              onChange={(e) => setPayMethod(e.target.value)}
            >
              <option value="cash">Tiền mặt</option>
              <option value="transfer">Chuyển khoản</option>
            </select>
          </Field>
          <button className="primary modal-submit" onClick={settle}>
            {activeDebt?.settlementType === "income" ? "Xác nhận đã thu" : "Xác nhận đã trả"}
          </button>
        </Modal>
      )}
      {details && (
        <PartnerDetailsModal
          target={details}
          onClose={() => setDetails(null)}
          onOpenDocument={(type, id) => {
            setDetails(null);
            p.openDocument(type, id);
          }}
        />
      )}
    </>
  );
}

export function Cash(p: ViewProps) {
  const [open, setOpen] = useState(false);
  const [filter, setFilter] = useState<"all" | "cash" | "transfer">("all");
  const [confirmId, setConfirmId] = useState("");
  const [settlementMode, setSettlementMode] = useState<
    "full" | "partial" | "none"
  >("full");
  const [settlementAmount, setSettlementAmount] = useState(0);
  const [settlementMethod, setSettlementMethod] = useState<"cash" | "transfer">(
    "transfer",
  );
  const [form, setForm] = useState({
    type: "expense",
    category: "Chi phí vận hành",
    note: "",
    amount: 0,
    paymentMethod: "transfer",
  });
  const balance = (method?: "cash" | "transfer") =>
    p.data.cashTransactions
      .filter(
        (x) =>
          ["completed", "partial"].includes(x.status) &&
          (!method || x.paymentMethod === method),
      )
      .reduce(
        (sum, transaction) =>
          sum +
          (transaction.type === "income"
            ? transaction.amount
            : -transaction.amount),
        0,
      );
  const filteredTransactions = p.data.cashTransactions.filter(
    (transaction) =>
      filter === "all" || transaction.paymentMethod === filter,
  );
  const save = async () => {
    await p.api({ action: "cash", ...form });
    setOpen(false);
    p.notify("Đã ghi sổ thu chi.");
    await p.reload();
  };
  const confirming = p.data.cashTransactions.find((x) => x.id === confirmId);
  const expectedAmount = confirming
    ? confirming.expectedAmount || confirming.amount
    : 0;
  const actualAmount =
    settlementMode === "full"
      ? expectedAmount
      : settlementMode === "none"
        ? 0
        : Math.min(expectedAmount, Math.max(0, settlementAmount));
  const debtAmount = Math.max(0, expectedAmount - actualAmount);
  const openConfirmation = (id: string) => {
    const transaction = p.data.cashTransactions.find((x) => x.id === id);
    if (!transaction) return;
    const expected = transaction.expectedAmount || transaction.amount;
    setConfirmId(id);
    setSettlementMode("full");
    setSettlementAmount(expected);
    setSettlementMethod("transfer");
  };
  const confirmSettlement = async () => {
    if (!confirming) return;
    await p.api({
      action: "cash-confirm",
      id: confirming.id,
      amount: actualAmount,
      paymentMethod: settlementMethod,
    });
    setConfirmId("");
    p.notify(
      debtAmount > 0
        ? `Đã ghi nhận ${money(actualAmount)} và chuyển ${money(debtAmount)} còn lại vào công nợ.`
        : `Đã xác nhận ${confirming.type === "income" ? "thu" : "trả"} đủ ${money(actualAmount)}.`,
    );
    await p.reload();
  };
  return (
    <>
      <div className="three">
        <Kpi
          icon="₫"
          label="Quỹ tiền mặt"
          value={money(balance("cash"))}
          tone="green"
        />
        <Kpi
          icon="⇄"
          label="Quỹ chuyển khoản"
          value={money(balance("transfer"))}
          tone="purple"
        />
        <Kpi
          icon="Σ"
          label="Tổng cả hai quỹ"
          value={money(balance())}
          tone="blue"
        />
      </div>
      <article className="panel cash-page">
        <PanelTitle
          text="Sổ quỹ"
          sub="Theo dõi riêng tiền mặt, chuyển khoản hoặc tổng hợp cả hai"
          action="＋ Lập phiếu thu/chi"
          onAction={() => {
            setForm((current) => ({ ...current, paymentMethod: "transfer" }));
            setOpen(true);
          }}
        />
        <div className="cash-filters" role="group" aria-label="Lọc sổ quỹ">
          {[
            ["all", "Tổng cả hai"],
            ["cash", "Tiền mặt"],
            ["transfer", "Chuyển khoản"],
          ].map(([value, label]) => (
            <button
              key={value}
              type="button"
              className={filter === value ? "selected" : ""}
              onClick={() =>
                setFilter(value as "all" | "cash" | "transfer")
              }
            >
              {label}
            </button>
          ))}
        </div>
        <div className="table cash-table">
          <table>
            <thead>
              <tr>
                <th>Thời gian</th>
                <th>Loại</th>
                <th>Trạng thái</th>
                <th>Nhóm</th>
                <th>Quỹ</th>
                <th>Nội dung</th>
                <th>Số tiền</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.map((x) => (
                <tr key={x.id}>
                  <td>{formatDate(x.createdAt)}</td>
                  <td>
                    <span className={`cash-kind ${x.type}`}>
                      {x.type === "income" ? "Phiếu thu" : "Phiếu chi"}
                    </span>
                  </td>
                  <td><Status value={x.status} /></td>
                  <td>{x.category}</td>
                  <td>
                    <span className={`fund-badge ${x.paymentMethod}`}>
                      {x.paymentMethod === "transfer"
                        ? "Chuyển khoản"
                        : "Tiền mặt"}
                    </span>
                  </td>
                  <td>
                    <b>{x.note}</b>
                    {(x.partnerName || x.reference) && (
                      <small>
                        {[x.partnerName, x.reference].filter(Boolean).join(" · ")}
                      </small>
                    )}
                  </td>
                  <td className={x.type === "income" ? "green" : "red"}>
                    {x.type === "income" ? "+" : "−"}
                    {money(x.status === "pending" ? x.expectedAmount || x.amount : x.amount)}
                    {x.status === "partial" && (
                      <small>Công nợ {money(Math.max(0, (x.expectedAmount || x.amount) - x.amount))}</small>
                    )}
                  </td>
                  <td>
                    {x.status === "pending" && (
                      <button
                        type="button"
                        className={`cash-confirm-button ${x.type}`}
                        onClick={() => openConfirmation(x.id)}
                      >
                        {x.type === "income" ? "Xác nhận thu" : "Xác nhận trả"}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </article>
      {open && (
        <Modal title="Lập phiếu thu / chi" onClose={() => setOpen(false)}>
          <Field label="Loại phiếu">
            <select
              value={form.type}
              onChange={(e) => setForm({ ...form, type: e.target.value })}
            >
              <option value="income">Phiếu thu</option>
              <option value="expense">Phiếu chi</option>
            </select>
          </Field>
          <Field label="Nhóm khoản">
            <input
              value={form.category}
              onChange={(e) => setForm({ ...form, category: e.target.value })}
            />
          </Field>
          <Field label="Ghi nhận vào quỹ">
            <select
              value={form.paymentMethod}
              onChange={(e) =>
                setForm({ ...form, paymentMethod: e.target.value })
              }
            >
              <option value="cash">Tiền mặt</option>
              <option value="transfer">Chuyển khoản</option>
            </select>
          </Field>
          <Field label="Nội dung">
            <textarea
              value={form.note}
              onChange={(e) => setForm({ ...form, note: e.target.value })}
            />
          </Field>
          <Field label="Số tiền">
            <MoneyInput value={form.amount} ariaLabel="Số tiền thu chi" onValueChange={(amount) => setForm({ ...form, amount })} />
          </Field>
          <button className="primary modal-submit" onClick={save}>
            Ghi sổ
          </button>
        </Modal>
      )}
      {confirming && (
        <Modal
          title={confirming.type === "income" ? "Xác nhận thu tiền" : "Xác nhận trả tiền"}
          onClose={() => setConfirmId("")}
          className="cash-confirm-modal"
        >
          <div className={`cash-confirm-summary ${confirming.type}`}>
            <span>
              {confirming.type === "income" ? "Cần thu" : "Cần trả"}
            </span>
            <b>{money(expectedAmount)}</b>
            <small>
              {confirming.partnerName || "Chưa có tên đối tác"}
              {confirming.reference ? ` · ${confirming.reference}` : ""}
            </small>
          </div>

          <div className="settlement-options" role="radiogroup" aria-label="Mức tiền xác nhận">
            {[
              ["full", confirming.type === "income" ? "Thu đủ" : "Trả đủ"],
              ["partial", confirming.type === "income" ? "Thu một phần" : "Trả một phần"],
              ["none", confirming.type === "income" ? "Chưa thu" : "Chưa trả"],
            ].map(([value, label]) => (
              <button
                type="button"
                role="radio"
                aria-checked={settlementMode === value}
                className={settlementMode === value ? "selected" : ""}
                key={value}
                onClick={() => setSettlementMode(value as "full" | "partial" | "none")}
              >
                {label}
              </button>
            ))}
          </div>

          {settlementMode === "partial" && (
            <Field label={confirming.type === "income" ? "Số tiền thực thu" : "Số tiền thực trả"}>
              <MoneyInput
                autoFocus
                max={expectedAmount}
                value={settlementAmount}
                ariaLabel={confirming.type === "income" ? "Số tiền thực thu" : "Số tiền thực trả"}
                onValueChange={setSettlementAmount}
              />
            </Field>
          )}
          {actualAmount > 0 && (
            <Field label="Ghi nhận vào quỹ">
              <select
                value={settlementMethod}
                onChange={(event) =>
                  setSettlementMethod(event.target.value === "transfer" ? "transfer" : "cash")
                }
              >
                <option value="cash">Tiền mặt</option>
                <option value="transfer">Chuyển khoản</option>
              </select>
            </Field>
          )}

          <div className="settlement-result">
            <p>
              <span>{confirming.type === "income" ? "Ghi thu vào quỹ" : "Ghi chi khỏi quỹ"}</span>
              <b>{money(actualAmount)}</b>
            </p>
            <p className={debtAmount > 0 ? "has-debt" : ""}>
              <span>Chuyển vào công nợ</span>
              <b>{money(debtAmount)}</b>
            </p>
          </div>
          {debtAmount > 0 && (
            <div className="settlement-note">
              {confirming.type === "income"
                ? `${confirming.partnerName || "Đối tác"} còn phải trả ${money(debtAmount)}.`
                : `Cửa hàng còn phải trả ${confirming.partnerName || "đối tác"} ${money(debtAmount)}.`}
            </div>
          )}
          <div className="cash-confirm-actions">
            <button type="button" onClick={() => setConfirmId("")}>Để sau</button>
            <button type="button" className="primary" onClick={() => void confirmSettlement()}>
              Xác nhận và cập nhật công nợ
            </button>
          </div>
        </Modal>
      )}
    </>
  );
}

export function Reports(p: ViewProps) {
  const valid = p.data.orders.filter((x) => x.status !== "cancelled");
  const returnItemsByOrder = useMemo(() => {
    const result = new Map<string, Map<number, number>>();
    for (const row of p.data.returns) {
      try {
        const items = JSON.parse(row.itemsJson || "[]") as Array<{
          itemId?: number;
          quantity?: number;
        }>;
        const quantities = result.get(row.orderId) ?? new Map<number, number>();
        for (const item of items) {
          const itemId = Number(item.itemId);
          const quantity = Math.max(0, Number(item.quantity) || 0);
          if (Number.isInteger(itemId) && quantity)
            quantities.set(itemId, (quantities.get(itemId) ?? 0) + quantity);
        }
        result.set(row.orderId, quantities);
      } catch {
        // A legacy return without item details still reduces revenue by its saved amount.
      }
    }
    return result;
  }, [p.data.returns]);

  const orderProfitRows = useMemo(() =>
    valid.map((order) => {
      const items = p.data.orderItems.filter((item) => item.orderId === order.id);
      const returnedQuantities = returnItemsByOrder.get(order.id) ?? new Map<number, number>();
      const refund = p.data.returns
        .filter((row) => row.orderId === order.id && row.status === "completed")
        .reduce((sum, row) => sum + Math.max(0, row.amount), 0);
      const originalCost = items.reduce((sum, item) => sum + item.unitCost * item.quantity, 0);
      const returnedCost = items.reduce(
        (sum, item) => sum + item.unitCost * Math.min(item.quantity, returnedQuantities.get(item.id) ?? 0),
        0,
      );
      const revenue = Math.max(0, order.total - refund);
      const cost = Math.max(0, originalCost - returnedCost);
      const grossProfit = revenue - cost;
      const orderExpenses = p.data.cashTransactions
        .filter(
          (transaction) =>
            transaction.orderId === order.id &&
            transaction.type === "expense" &&
            !["Hoàn tiền", "Hoàn tiền hủy đơn"].includes(transaction.category),
        )
        .reduce((sum, transaction) => sum + Math.max(0, transaction.amount), 0);
      return {
        order,
        refund,
        revenue,
        cost,
        grossProfit,
        orderExpenses,
        netProfit: grossProfit - orderExpenses,
      };
    }),
    [p.data.cashTransactions, p.data.orderItems, p.data.returns, returnItemsByOrder, valid],
  );
  const revenue = orderProfitRows.reduce((sum, row) => sum + row.revenue, 0);
  const cost = orderProfitRows.reduce((sum, row) => sum + row.cost, 0);
  const grossProfit = orderProfitRows.reduce((sum, row) => sum + row.grossProfit, 0);
  const netProfit = orderProfitRows.reduce((sum, row) => sum + row.netProfit, 0);
  const exportCsv = () => {
    const rows = [
      ["Mã đơn", "Khách hàng", "Kênh", "Doanh thu", "Giá vốn", "Lợi nhuận gộp", "Chi phí đơn", "Lợi nhuận ròng", "Trạng thái", "Ngày"],
      ...orderProfitRows.map((row) => [
        row.order.code,
        row.order.customerName,
        row.order.channel === "pos" ? "Tại quầy" : "Online",
        String(row.revenue),
        String(row.cost),
        String(row.grossProfit),
        String(row.orderExpenses),
        String(row.netProfit),
        row.order.status,
        row.order.createdAt,
      ]),
    ];
    const csv =
      "\uFEFF" +
      rows
        .map((r) =>
          r.map((v) => `"${String(v).replaceAll('"', '""')}"`).join(","),
        )
        .join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(
      new Blob([csv], { type: "text/csv;charset=utf-8" }),
    );
    a.download = `bao-cao-tien-computer-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  };
  const byProduct = (() => {
    const map = new Map<
      string,
      { name: string; qty: number; revenue: number }
    >();
    p.data.orderItems.forEach((i) => {
      if (!valid.some((o) => o.id === i.orderId)) return;
      const old = map.get(i.sku) || { name: i.productName, qty: 0, revenue: 0 };
      old.qty += i.quantity;
      old.revenue += i.quantity * i.unitPrice;
      map.set(i.sku, old);
    });
    return [...map.entries()].sort((a, b) => b[1].revenue - a[1].revenue);
  })();
  return (
    <>
      <div className="report-actions">
        <button onClick={exportCsv}>⇩ Xuất Excel/CSV</button>
        <button onClick={() => window.print()}>▤ In báo cáo</button>
      </div>
      <div className="kpis">
        <Kpi icon="₫" label="Doanh thu" value={money(revenue)} />
        <Kpi
          icon="↗"
          label="Lợi nhuận gộp"
          value={money(grossProfit)}
          tone="green"
        />
        <Kpi
          icon="↗"
          label="Lợi nhuận ròng"
          value={money(netProfit)}
          tone="purple"
        />
        <Kpi
          icon="▣"
          label="Giá trị tồn (giá vốn)"
          value={money(
            p.data.products.reduce((sum, product) => sum + inventoryValue(product), 0),
          )}
          tone="orange"
        />
      </div>
      <article className="panel report-order-profit">
        <PanelTitle
          text="Lời lỗ theo đơn hàng"
          sub="Doanh thu đã trừ đổi trả; lợi nhuận ròng trừ thêm chi phí gắn với từng đơn."
        />
        <div className="table report-order-profit-table">
          <table>
            <thead>
              <tr>
                <th>Mã đơn</th>
                <th>Khách hàng</th>
                <th>Ngày bán</th>
                <th>Doanh thu</th>
                <th>Giá vốn</th>
                <th>Lợi nhuận gộp</th>
                <th>Chi phí đơn</th>
                <th>Lợi nhuận ròng</th>
              </tr>
            </thead>
            <tbody>
              {orderProfitRows.length ? orderProfitRows.map((row) => (
                <tr key={row.order.id}>
                  <td><b className="link">{row.order.code}</b><small>{row.order.channel === "pos" ? "Tại quầy" : "Online"}</small></td>
                  <td>{row.order.customerName}</td>
                  <td>{formatDate(row.order.createdAt)}</td>
                  <td><b>{money(row.revenue)}</b>{row.refund > 0 && <small>Đã trừ đổi trả {money(row.refund)}</small>}</td>
                  <td>{money(row.cost)}</td>
                  <td className={row.grossProfit < 0 ? "loss" : "profit"}>{money(row.grossProfit)}</td>
                  <td>{row.orderExpenses ? money(row.orderExpenses) : "—"}</td>
                  <td className={row.netProfit < 0 ? "loss" : "profit"}><b>{money(row.netProfit)}</b></td>
                </tr>
              )) : (
                <tr><td colSpan={8}><div className="mini-empty">Chưa có đơn bán hợp lệ để thống kê</div></td></tr>
              )}
            </tbody>
            {orderProfitRows.length > 0 && (
              <tfoot>
                <tr>
                  <td colSpan={3}><b>Tổng cộng</b></td>
                  <td><b>{money(revenue)}</b></td>
                  <td><b>{money(cost)}</b></td>
                  <td className={grossProfit < 0 ? "loss" : "profit"}><b>{money(grossProfit)}</b></td>
                  <td><b>{money(orderProfitRows.reduce((sum, row) => sum + row.orderExpenses, 0))}</b></td>
                  <td className={netProfit < 0 ? "loss" : "profit"}><b>{money(netProfit)}</b></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </article>
      <div className="cols">
        <article className="panel">
          <PanelTitle text="Sản phẩm bán chạy" sub="Theo doanh thu" />
          <div className="rank-list">
            {byProduct.slice(0, 8).map(([sku, x], i) => (
              <div key={sku}>
                <i>{i + 1}</i>
                <span>
                  <b>{x.name}</b>
                  <small>{x.qty} sản phẩm</small>
                </span>
                <strong>{money(x.revenue)}</strong>
              </div>
            ))}
          </div>
        </article>
        <article className="panel">
          <PanelTitle text="Hiệu quả vận hành" />
          <div className="metrics">
            <p>
              <span>Giá trị đơn trung bình</span>
              <b>
                {money(valid.length ? Math.round(revenue / valid.length) : 0)}
              </b>
            </p>
            <p>
              <span>Biên lợi nhuận gộp</span>
              <b>{revenue ? Math.round((grossProfit / revenue) * 100) : 0}%</b>
            </p>
            <p>
              <span>Tỷ lệ đơn online</span>
              <b>
                {valid.length
                  ? Math.round(
                      (valid.filter((x) => x.channel === "online").length /
                        valid.length) *
                        100,
                    )
                  : 0}
                %
              </b>
            </p>
            <p>
              <span>Tổng khách hàng</span>
              <b>{p.data.customers.length}</b>
            </p>
            <p>
              <span>Đơn bảo hành đang mở</span>
              <b>
                {
                  p.data.warranties.filter(
                    (x) => !["completed", "returned"].includes(x.status),
                  ).length
                }
              </b>
            </p>
          </div>
        </article>
      </div>
    </>
  );
}

export function OnlineStore(p: ViewProps) {
  const [checkout, setCheckout] = useState(false);
  const [busy, setBusy] = useState(false);
  const [customer, setCustomer] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
  });
  const [note, setNote] = useState("");
  const total = p.cart.reduce((s, x) => s + x.price * x.qty, 0);
  const order = async () => {
    setBusy(true);
    try {
      const result = await p.api(
        {
          channel: "online",
          customer,
          shippingAddress: customer.address,
          note,
          paid: 0,
          paymentMethod: "transfer",
          items: p.cart.map((x) => ({ productId: x.id, quantity: x.qty })),
        },
        "/api/orders",
      );
      p.setCart([]);
      setCheckout(false);
      p.notify(
        `Đã gửi đơn ${(result.order as { code: string }).code}. Đơn đang chờ cửa hàng xác nhận.`,
      );
      await p.reload();
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <div className="store">
        <div className="store-head">
          <b>TC</b>
          <strong>{p.data.settings.storeName.toUpperCase()}</strong>
          <nav>Laptop　 Linh kiện　 Phụ kiện　 Khuyến mãi</nav>
          <button onClick={() => setCheckout(true)}>
            Giỏ hàng ({p.cart.reduce((s, x) => s + x.qty, 0)})
          </button>
        </div>
        <div className="hero">
          <div>
            <small>LAPTOP CHÍNH HÃNG · KIỂM TRA SERIAL</small>
            <h2>
              Máy tính phù hợp,
              <br />
              giá thật dễ chọn.
            </h2>
            <p>
              Tư vấn đúng nhu cầu, bảo hành rõ ràng và hỗ trợ cài đặt tận tình.
            </p>
            <button
              className="primary"
              onClick={() =>
                document
                  .getElementById("shop-products")
                  ?.scrollIntoView({ behavior: "smooth" })
              }
            >
              Xem sản phẩm
            </button>
          </div>
          <i>▱</i>
        </div>
        <div className="shop" id="shop-products">
          <h2>Sản phẩm nổi bật</h2>
          <div>
            {p.products.map((x) => (
              <article key={x.id}>
                <ProductImage
                  imageKey={x.imageKey}
                  alt={x.name}
                  className="online-product-image"
                  fallback={x.category === "Laptop" ? "▱" : "◇"}
                />
                <small>{x.brand || x.category}</small>
                <h3>{x.name}</h3>
                <p>{x.description || x.category}</p>
                <b>{money(x.price)}</b>
                <button onClick={() => p.add(x)} disabled={!x.stock}>
                  {x.stock ? "Thêm vào giỏ" : "Hết hàng"}
                </button>
              </article>
            ))}
          </div>
        </div>
      </div>
      {checkout && (
        <Modal
          title="Giỏ hàng và đặt mua"
          onClose={() => setCheckout(false)}
          wide
        >
          <div className="cart-list checkout-cart">
            {p.cart.map((x) => (
              <div className="cart-row" key={x.id}>
                <span>
                  <b>{x.name}</b>
                  <small>{money(x.price)}</small>
                </span>
                <div>
                  <button
                    onClick={() =>
                      p.setCart((c) =>
                        c.flatMap((i) =>
                          i.id === x.id
                            ? i.qty === 1
                              ? []
                              : [{ ...i, qty: i.qty - 1 }]
                            : [i],
                        ),
                      )
                    }
                  >
                    −
                  </button>
                  {x.qty}
                  <button onClick={() => p.add(x)}>＋</button>
                </div>
              </div>
            ))}
          </div>
          <div className="form-grid">
            <Field label="Họ tên">
              <input
                value={customer.name}
                onChange={(e) =>
                  setCustomer({ ...customer, name: e.target.value })
                }
              />
            </Field>
            <Field label="Số điện thoại">
              <input
                value={customer.phone}
                onChange={(e) =>
                  setCustomer({ ...customer, phone: e.target.value })
                }
              />
            </Field>
            <Field label="Email">
              <input
                value={customer.email}
                onChange={(e) =>
                  setCustomer({ ...customer, email: e.target.value })
                }
              />
            </Field>
            <Field label="Địa chỉ giao hàng">
              <input
                value={customer.address}
                onChange={(e) =>
                  setCustomer({ ...customer, address: e.target.value })
                }
              />
            </Field>
            <Field label="Ghi chú" wide>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />
            </Field>
          </div>
          <div className="checkout-total">
            <span>Tổng đơn hàng</span>
            <b>{money(total)}</b>
          </div>
          <SpinnerButton
            className="primary modal-submit"
            busy={busy}
            disabled={
              !p.cart.length ||
              !customer.name ||
              !customer.phone ||
              !customer.address
            }
            onClick={order}
          >
            Đặt hàng – thanh toán khi nhận
          </SpinnerButton>
        </Modal>
      )}
    </>
  );
}

export function SettingsView(p: ViewProps) {
  const [form, setForm] = useState(p.data.settings);
  const [busy, setBusy] = useState(false);
  const [salesSettingBusy, setSalesSettingBusy] = useState<keyof Pick<typeof form, "allowNegativeStock" | "autoPrint" | "lowStockAlert"> | null>(null);
  const save = async () => {
    setBusy(true);
    try {
      await p.api({ action: "settings", ...form });
      p.notify("Đã lưu cấu hình cửa hàng.");
      await p.reload();
    } finally {
      setBusy(false);
    }
  };
  const saveSalesSetting = async (
    key: keyof Pick<typeof form, "allowNegativeStock" | "autoPrint" | "lowStockAlert">,
    value: boolean,
  ) => {
    setForm((current) => ({ ...current, [key]: value }));
    setSalesSettingBusy(key);
    try {
      await p.api({ action: "settings-sales", key, value });
      p.notify("Đã lưu thiết lập bán hàng.");
      await p.reload();
    } catch (error) {
      setForm((current) => ({ ...current, [key]: !value }));
      p.notify(error instanceof Error ? error.message : "Không thể lưu thiết lập bán hàng.");
    } finally {
      setSalesSettingBusy(null);
    }
  };
  return (
    <div className="cols">
      <article className="panel settings">
        <h2>Quản trị cửa hàng</h2>
        <p className="settings-help">Chỉ thay đổi nội dung và cấu hình. Dữ liệu đơn hàng, kho và công nợ vẫn được giữ nguyên.</p>
        <div className="kpis">
          <Kpi icon="▧" label="Đơn bán" value={String(p.data.orders.length)} tone="blue" />
          <Kpi icon="⇩" label="Phiếu nhập" value={String(p.data.purchases.length)} tone="purple" />
          <Kpi icon="₫" label="Công nợ đang theo dõi" value={String(p.data.debts.filter((x) => x.status !== "completed").length)} tone="orange" />
        </div>
        <h2>Thông tin cửa hàng</h2>
        <Field label="Tên cửa hàng">
          <input
            value={form.storeName}
            onChange={(e) => setForm({ ...form, storeName: e.target.value })}
          />
        </Field>
        <Field label="Số điện thoại">
          <input
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
          />
        </Field>
        <Field label="Địa chỉ">
          <input
            value={form.address}
            onChange={(e) => setForm({ ...form, address: e.target.value })}
          />
        </Field>
        <Field label="Mã số thuế">
          <input
            value={form.taxCode}
            onChange={(e) => setForm({ ...form, taxCode: e.target.value })}
          />
        </Field>
        <Field label="Dòng cuối hóa đơn">
          <input
            value={form.receiptFooter}
            onChange={(e) =>
              setForm({ ...form, receiptFooter: e.target.value })
            }
          />
        </Field>
        <h2 className="print-settings-heading">Mẫu in đơn A4</h2>
        <p className="settings-help">Thông tin khách hàng, mã đơn, ngày tạo và hàng hóa lấy tự động từ đơn. Cột bảo hành lấy từ ghi chú của từng sản phẩm.</p>
        <Field label="Tiêu đề phiếu in">
          <input value={form.printTitle} onChange={(e) => setForm({ ...form, printTitle: e.target.value })} />
        </Field>
        <Field label="Quy định bảo hành">
          <textarea rows={6} value={form.printRegulations} onChange={(e) => setForm({ ...form, printRegulations: e.target.value })} />
        </Field>
        <div className="form-grid">
          <Field label="Chức danh ký khách hàng"><input value={form.printCustomerSigner} onChange={(e) => setForm({ ...form, printCustomerSigner: e.target.value })} /></Field>
          <Field label="Chức danh ký nhân viên"><input value={form.printSalesSigner} onChange={(e) => setForm({ ...form, printSalesSigner: e.target.value })} /></Field>
          <Field label="Chức danh ký kế toán"><input value={form.printAccountantSigner} onChange={(e) => setForm({ ...form, printAccountantSigner: e.target.value })} /></Field>
        </div>
        <Field label="Dòng cuối phiếu A4 (tùy chọn)">
          <input value={form.printFooter} onChange={(e) => setForm({ ...form, printFooter: e.target.value })} />
        </Field>
        <SpinnerButton className="primary" busy={busy} onClick={save}>
          Lưu thay đổi
        </SpinnerButton>
      </article>
      <article className="panel settings">
        <h2>Quỹ & loại thu chi</h2>
        <p className="settings-help">Quản lý giao dịch tại mục Thu chi. Các khoản Chờ xác nhận chưa được tính vào quỹ.</p>
        <div className="quick">
          <button onClick={() => p.setActive("Thu chi")}>↕ Mở sổ thu chi</button>
          <button onClick={() => p.setActive("Công nợ")}>₫ Xác nhận công nợ</button>
        </div>
        <h2>Nhật ký hoạt động</h2>
        <p className="settings-help">Các chứng từ mới nhất: đơn bán, phiếu nhập và thu chi.</p>
        <div className="compact-list">
          {[...p.data.orders.map(x => ({ text: `Tạo đơn bán ${x.code}`, at: x.createdAt })), ...p.data.purchases.map(x => ({ text: `Tạo phiếu nhập ${x.code}`, at: x.createdAt })), ...p.data.cashTransactions.map(x => ({ text: `${x.type === "income" ? "Thu" : "Chi"}: ${x.category}`, at: x.createdAt }))].sort((a,b)=>new Date(b.at).getTime()-new Date(a.at).getTime()).slice(0,10).map((x,i)=><div key={i}><span>{x.text}</span><small>{formatDate(x.at)}</small></div>)}
        </div>
        <h2>Sao lưu dữ liệu</h2>
        <p className="settings-help">Tải bản sao dữ liệu hiện có về máy. Phục hồi sẽ được thực hiện riêng để tránh ghi đè nhầm dữ liệu.</p>
        <button className="secondary full" onClick={() => { const blob = new Blob([JSON.stringify(p.data, null, 2)], { type: "application/json" }); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `tien-computer-backup-${new Date().toISOString().slice(0,10)}.json`; a.click(); URL.revokeObjectURL(a.href); }}>⇩ Tải bản sao dữ liệu</button>
        <h2>Thiết lập bán hàng</h2>
        <label className="toggle">
          <span>
            Cho phép bán âm kho
            <small>Khuyến nghị tắt để kiểm soát serial</small>
          </span>
          <input
            type="checkbox"
            checked={form.allowNegativeStock}
            disabled={salesSettingBusy !== null}
            onChange={(e) => void saveSalesSetting("allowNegativeStock", e.target.checked)}
          />
        </label>
        <label className="toggle">
          <span>
            Tự động in hóa đơn<small>Mở hộp thoại in sau khi thanh toán</small>
          </span>
          <input
            type="checkbox"
            checked={form.autoPrint}
            disabled={salesSettingBusy !== null}
            onChange={(e) => void saveSalesSetting("autoPrint", e.target.checked)}
          />
        </label>
        <label className="toggle">
          <span>
            Nhắc hàng sắp hết
            <small>Hiển thị trên tổng quan và chuông thông báo</small>
          </span>
          <input
            type="checkbox"
            checked={form.lowStockAlert}
            disabled={salesSettingBusy !== null}
            onChange={(e) => void saveSalesSetting("lowStockAlert", e.target.checked)}
          />
        </label>
        <button
          className="secondary full"
          onClick={() => {
            if (confirm("Tải lại dữ liệu mới nhất từ hệ thống?")) p.reload();
          }}
        >
          ↻ Đồng bộ dữ liệu ngay
        </button>
      </article>
    </div>
  );
}
