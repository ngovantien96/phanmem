import { getD1 } from "../../../db/runtime";
import { nextShortCode } from "../../../db/short-codes";

type OrderPayload = {
  action?: "payment" | "edit";
  id?: string;
  customerId?: string;
  customer?: {
    name?: string;
    phone?: string;
    email?: string;
    address?: string;
  };
  paymentMethod?: "cash" | "transfer" | "card";
  discount?: number;
  paid?: number;
  channel?: "pos" | "online";
  shippingAddress?: string;
  note?: string;
  createdAt?: string;
  paymentAmount?: number;
  cancellationReason?: string;
  items?: Array<{
    productId: number;
    quantity: number;
    serials?: string[];
    unitPrice?: number;
    discount?: number;
    note?: string;
  }>;
};

type ProductRow = {
  id: number;
  sku: string;
  name: string;
  tracking: "serial" | "quantity";
  cost: number;
  price: number;
  stock: number;
};

export async function POST(request: Request) {
  try {
    const db = getD1();
    const body = (await request.json()) as OrderPayload;
    const items = (body.items ?? []).filter(
      (item) => Number.isInteger(item.quantity) && item.quantity > 0,
    );
    if (!items.length)
      return Response.json(
        { error: "Đơn hàng chưa có sản phẩm." },
        { status: 400 },
      );

    const channel = body.channel === "online" ? "online" : "pos";
    const paymentMethod = body.paymentMethod === "cash" ? "cash" : "transfer";
    const salesSettings = await db
      .prepare("SELECT allow_negative_stock AS allowNegativeStock FROM store_settings WHERE id = 1")
      .first<{ allowNegativeStock: number }>();
    const allowNegativeStock = Boolean(salesSettings?.allowNegativeStock);

    const products: ProductRow[] = [];
    const chosenSerials = new Map<
      number,
      Array<{ id: number; serial: string }>
    >();
    for (const item of items) {
      const product = await db
        .prepare(
          "SELECT id, sku, name, tracking, cost, price, stock FROM products WHERE id = ? AND active = 1",
        )
        .bind(item.productId)
        .first<ProductRow>();
      if (!product)
        return Response.json(
          { error: "Có sản phẩm không còn tồn tại." },
          { status: 400 },
        );
      const canSellNegative =
        allowNegativeStock && product.tracking === "quantity";
      if (!canSellNegative && product.stock < item.quantity)
        return Response.json(
          { error: `${product.name} chỉ còn ${product.stock} sản phẩm.` },
          { status: 409 },
        );
      products.push(product);
      if (product.tracking === "serial") {
        const requested = [
          ...new Set(
            (item.serials ?? []).map((serial) => serial.trim()).filter(Boolean),
          ),
        ];
        if (channel === "pos" && requested.length !== item.quantity)
          return Response.json(
            { error: `${product.name}: vui lòng chọn đủ ${item.quantity} serial để xuất.` },
            { status: 400 },
          );
        const rows = channel === "pos"
          ? await db
              .prepare(
                `SELECT id, serial FROM serials WHERE product_id = ? AND status = 'available' AND serial IN (${requested.map(() => "?").join(",")})`,
              )
              .bind(product.id, ...requested)
              .all<{ id: number; serial: string }>()
          : await db
              .prepare(
                "SELECT id, serial FROM serials WHERE product_id = ? AND status = 'available' ORDER BY id LIMIT ?",
              )
              .bind(product.id, item.quantity)
              .all<{ id: number; serial: string }>();
        if (rows.results.length < item.quantity)
          return Response.json(
            {
              error:
                channel === "pos"
                  ? `${product.name}: có serial đã được bán hoặc không còn sẵn sàng.`
                  : `${product.name} không đủ serial sẵn sàng bán.`,
            },
            { status: 409 },
          );
        const bySerial = new Map(rows.results.map((row) => [row.serial, row]));
        chosenSerials.set(
          product.id,
          channel === "pos"
            ? requested.map((serial) => bySerial.get(serial)!).filter(Boolean)
            : rows.results,
        );
      }
    }

    const id = crypto.randomUUID();
    const code = await nextShortCode(db, "order");
    const createdAt = new Date().toISOString();
    let customerId = body.customerId?.trim() || "";
    let customer = customerId
      ? await db
          .prepare("SELECT id,name,phone,email,address FROM customers WHERE id=?")
          .bind(customerId)
          .first<{
            id: string;
            name: string;
            phone: string;
            email: string;
            address: string;
          }>()
      : null;
    let createCustomer = false;
    let customerCode = "";
    if (!customer) {
      const name = body.customer?.name?.trim() || "";
      const phone = body.customer?.phone?.trim() || "";
      if (!name || !phone)
        return Response.json(
          { error: "Đơn bán phải có thông tin khách hàng: tên và số điện thoại." },
          { status: 400 },
        );
      const existingCustomer = await db
        .prepare("SELECT id, code FROM customers WHERE phone = ? ORDER BY created_at, rowid LIMIT 1")
        .bind(phone)
        .first<{ id: string; code: string }>();
      customerId = existingCustomer?.id || crypto.randomUUID();
      customerCode = existingCustomer?.code || await nextShortCode(db, "customer");
      customer = {
        id: customerId,
        name,
        phone,
        email: body.customer?.email?.trim() || "",
        address: body.customer?.address?.trim() || "",
      };
      createCustomer = true;
    }
    const customerName = customer.name;
    const address = customer.address;
    const normalizedLines = items.map((item, index) => {
      const product = products[index];
      const requestedPrice = Number(item.unitPrice);
      const unitPrice = Number.isFinite(requestedPrice)
        ? Math.max(0, Math.round(requestedPrice))
        : product.price;
      const lineSubtotal = unitPrice * item.quantity;
      const requestedDiscount = Number(item.discount);
      const lineDiscount = Number.isFinite(requestedDiscount)
        ? Math.min(lineSubtotal, Math.max(0, Math.round(requestedDiscount)))
        : 0;
      return {
        unitPrice,
        lineDiscount,
        note: item.note?.trim().slice(0, 500) || "",
      };
    });
    const subtotal = items.reduce(
      (sum, item, index) =>
        sum + normalizedLines[index].unitPrice * item.quantity,
      0,
    );
    const lineDiscountTotal = normalizedLines.reduce(
      (sum, line) => sum + line.lineDiscount,
      0,
    );
    const discount = Math.min(
      subtotal,
      lineDiscountTotal + Math.max(0, Number(body.discount) || 0),
    );
    const total = Math.max(0, subtotal - discount);
    const paid = Math.min(
      total,
      Math.max(
        0,
        body.paid === undefined
          ? channel === "pos"
            ? total
            : 0
          : Number(body.paid) || 0,
      ),
    );
    const status =
      channel === "online"
        ? "pending"
        : paid >= total
          ? "completed"
          : "processing";
    const statements = [];

    if (createCustomer)
      statements.push(
        db
          .prepare(
            "INSERT INTO customers (id,code,name,phone,email,address) VALUES (?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,email=excluded.email,address=excluded.address",
          )
          .bind(
            customer.id,
            customerCode,
            customer.name,
            customer.phone,
            customer.email,
            customer.address,
          ),
      );
    statements.push(
      db
        .prepare(
          "INSERT INTO orders (id, code, customer_id, customer_name, subtotal, discount, total, paid, payment_method, status, channel, shipping_address, note, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        )
        .bind(
          id,
          code,
          customerId,
          customerName,
          subtotal,
          discount,
          total,
          paid,
          paymentMethod,
          status,
          channel,
          body.shippingAddress?.trim() || address,
          body.note?.trim() || "",
          createdAt,
        ),
    );

    items.forEach((item, index) => {
      const product = products[index];
      const line = normalizedLines[index];
      const serialRows = chosenSerials.get(product.id) ?? [];
      statements.push(
        db
          .prepare(
            "INSERT INTO order_items (order_id, product_id, product_name, sku, quantity, unit_price, unit_cost, discount, note, serials_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
          )
          .bind(
            id,
            product.id,
            product.name,
            product.sku,
            item.quantity,
            line.unitPrice,
            product.cost,
            line.lineDiscount,
            line.note,
            JSON.stringify(serialRows.map((x) => x.serial)),
          ),
      );
      statements.push(
        allowNegativeStock && product.tracking === "quantity"
          ? db.prepare("UPDATE products SET stock = stock - ? WHERE id = ?").bind(item.quantity, product.id)
          : db.prepare("UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?").bind(item.quantity, product.id, item.quantity),
      );
      statements.push(
        db
          .prepare(
            "INSERT INTO inventory_movements (id, product_id, product_name, type, quantity, reference, note) VALUES (?, ?, ?, 'sale', ?, ?, ?)",
          )
          .bind(
            crypto.randomUUID(),
            product.id,
            product.name,
            -item.quantity,
            code,
            channel === "online" ? "Đơn online" : "Bán tại quầy",
          ),
      );
      serialRows.forEach((serial) => {
        statements.push(
          db
            .prepare(
              "UPDATE serials SET status = 'sold', order_id = ? WHERE id = ? AND status = 'available'",
            )
            .bind(id, serial.id),
        );
      });
    });
    if (paid > 0)
      statements.push(
        db
          .prepare(
            "INSERT INTO cash_transactions (id, type, category, note, amount, payment_method, order_id) VALUES (?, 'income', 'Bán hàng', ?, ?, ?, ?)",
          )
          .bind(
            crypto.randomUUID(),
            `Thanh toán đơn ${code}`,
            paid,
            paymentMethod,
            id,
          ),
      );
    if (paid < total)
      statements.push(
        db
          .prepare(
            "INSERT INTO debts (id, partner_type, partner_name, reference, total, paid, due_date, status, settlement_type) VALUES (?, 'customer', ?, ?, ?, ?, ?, ?, 'income')",
          )
          .bind(
            crypto.randomUUID(),
            customerName,
            code,
            total,
            paid,
            "",
            paid > 0 ? "partial" : "open",
          ),
      );

    await db.batch(statements);
    return Response.json(
      {
        order: {
          id,
          code,
          customerId,
          customerName,
          subtotal,
          discount,
          total,
          paid,
          refunded: 0,
          paymentMethod,
          status,
          channel,
          shippingAddress: body.shippingAddress?.trim() || address,
          note: body.note?.trim() || "",
          cancellationReason: "",
          cancelledAt: null,
          createdAt,
        },
      },
      { status: 201 },
    );
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Không thể tạo đơn hàng";
    return Response.json({ error: message }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const db = getD1();
    const body = (await request.json()) as OrderPayload & { status?: string };

    if (body.action === "payment") {
      if (!body.id)
        return Response.json(
          { error: "Thiếu mã đơn hàng." },
          { status: 400 },
        );
      const order = await db
        .prepare(
          "SELECT id, code, customer_name AS customerName, total, paid, status FROM orders WHERE id = ?",
        )
        .bind(body.id)
        .first<{
          id: string;
          code: string;
          customerName: string;
          total: number;
          paid: number;
          status: string;
        }>();
      if (!order)
        return Response.json(
          { error: "Không tìm thấy đơn hàng." },
          { status: 404 },
        );
      if (order.status === "cancelled")
        return Response.json(
          { error: "Đơn đã hủy không thể nhận thêm thanh toán." },
          { status: 409 },
        );
      const paymentAmount = Math.round(Number(body.paymentAmount) || 0);
      const remaining = Math.max(0, order.total - order.paid);
      if (paymentAmount <= 0)
        return Response.json(
          { error: "Số tiền thanh toán phải lớn hơn 0." },
          { status: 400 },
        );
      if (paymentAmount > remaining)
        return Response.json(
          { error: `Số tiền thanh toán không được vượt quá ${remaining}.` },
          { status: 400 },
        );
      const paymentMethod =
        body.paymentMethod === "cash" ? "cash" : "transfer";
      const nextPaid = order.paid + paymentAmount;
      const nextStatus = nextPaid >= order.total ? "completed" : "processing";
      const debt = await db
        .prepare(
          "SELECT id FROM debts WHERE partner_type = 'customer' AND reference = ? ORDER BY created_at DESC LIMIT 1",
        )
        .bind(order.code)
        .first<{ id: string }>();
      const statements = [
        db
          .prepare(
            "UPDATE orders SET paid = ?, payment_method = ?, status = ? WHERE id = ?",
          )
          .bind(nextPaid, paymentMethod, nextStatus, order.id),
        db
          .prepare(
            "INSERT INTO cash_transactions (id, type, category, note, amount, payment_method, order_id) VALUES (?, 'income', 'Bán hàng', ?, ?, ?, ?)",
          )
          .bind(
            crypto.randomUUID(),
            `Thanh toán thêm đơn ${order.code}`,
            paymentAmount,
            paymentMethod,
            order.id,
          ),
      ];
      if (debt) {
        statements.push(
          db
            .prepare(
              "UPDATE debts SET partner_name = ?, total = ?, paid = ?, status = ? WHERE id = ?",
            )
            .bind(
              order.customerName,
              order.total,
              nextPaid,
              nextPaid >= order.total ? "paid" : "partial",
              debt.id,
            ),
        );
      } else if (nextPaid < order.total) {
        statements.push(
          db
            .prepare(
              "INSERT INTO debts (id, partner_type, partner_name, reference, total, paid, due_date, status, settlement_type) VALUES (?, 'customer', ?, ?, ?, ?, '', ?, 'income')",
            )
            .bind(
              crypto.randomUUID(),
              order.customerName,
              order.code,
              order.total,
              nextPaid,
              "partial",
            ),
        );
      }
      await db.batch(statements);
      return Response.json({
        ok: true,
        paid: nextPaid,
        remaining: Math.max(0, order.total - nextPaid),
        status: nextStatus,
      });
    }

    if (body.action === "edit") {
      if (!body.id)
        return Response.json(
          { error: "Thiếu mã đơn hàng." },
          { status: 400 },
        );
      const order = await db
        .prepare(
          "SELECT id, code, paid, status, channel, created_at AS createdAt FROM orders WHERE id = ?",
        )
        .bind(body.id)
        .first<{
          id: string;
          code: string;
          paid: number;
          status: string;
          channel: string;
          createdAt: string;
        }>();
      if (!order)
        return Response.json(
          { error: "Không tìm thấy đơn hàng." },
          { status: 404 },
        );
      if (order.status === "cancelled")
        return Response.json(
          { error: "Đơn đã hủy không thể chỉnh sửa." },
          { status: 409 },
        );
      const salesSettings = await db
        .prepare(
          "SELECT allow_negative_stock AS allowNegativeStock FROM store_settings WHERE id = 1",
        )
        .first<{ allowNegativeStock: number }>();
      const allowNegativeStock = Boolean(salesSettings?.allowNegativeStock);
      const returned = await db
        .prepare("SELECT COUNT(*) AS total FROM returns WHERE order_id = ?")
        .bind(order.id)
        .first<{ total: number }>();
      if ((returned?.total ?? 0) > 0)
        return Response.json(
          { error: "Đơn đã phát sinh đổi trả nên không thể sửa hàng hóa." },
          { status: 409 },
        );

      const items = (body.items ?? []).filter(
        (item) => Number.isInteger(item.quantity) && item.quantity > 0,
      );
      if (!items.length)
        return Response.json(
          { error: "Đơn hàng phải có ít nhất một sản phẩm." },
          { status: 400 },
        );
      if (new Set(items.map((item) => item.productId)).size !== items.length)
        return Response.json(
          { error: "Mỗi sản phẩm chỉ được xuất hiện một lần trong đơn." },
          { status: 400 },
        );

      const oldItems = await db
        .prepare(
          "SELECT product_id AS productId, product_name AS productName, quantity, serials_json AS serialsJson FROM order_items WHERE order_id = ?",
        )
        .bind(order.id)
        .all<{
          productId: number;
          productName: string;
          quantity: number;
          serialsJson: string;
        }>();
      const oldQuantity = new Map<number, number>();
      for (const item of oldItems.results)
        oldQuantity.set(
          item.productId,
          (oldQuantity.get(item.productId) ?? 0) + item.quantity,
        );

      const products: ProductRow[] = [];
      const chosenSerials = new Map<
        number,
        Array<{ id: number; serial: string }>
      >();
      for (const item of items) {
        const product = await db
          .prepare(
            "SELECT id, sku, name, tracking, cost, price, stock FROM products WHERE id = ? AND active = 1",
          )
          .bind(item.productId)
          .first<ProductRow>();
        if (!product)
          return Response.json(
            { error: "Có sản phẩm không còn tồn tại." },
            { status: 400 },
          );
        const available = product.stock + (oldQuantity.get(product.id) ?? 0);
        const canSellNegative =
          allowNegativeStock && product.tracking === "quantity";
        if (!canSellNegative && available < item.quantity)
          return Response.json(
            { error: `${product.name} chỉ có thể xuất tối đa ${available} sản phẩm.` },
            { status: 409 },
          );
        products.push(product);
        if (product.tracking === "serial") {
          const requested = [
            ...new Set(
              (item.serials ?? []).map((serial) => serial.trim()).filter(Boolean),
            ),
          ];
          if (requested.length !== item.quantity)
            return Response.json(
              { error: `${product.name}: vui lòng chọn đủ ${item.quantity} serial để xuất.` },
              { status: 400 },
            );
          const rows = await db
            .prepare(
              `SELECT id, serial FROM serials WHERE product_id = ? AND (status = 'available' OR order_id = ?) AND serial IN (${requested.map(() => "?").join(",")})`,
            )
            .bind(product.id, order.id, ...requested)
            .all<{ id: number; serial: string }>();
          if (rows.results.length !== item.quantity)
            return Response.json(
              { error: `${product.name}: có serial đã được bán ở đơn khác hoặc không còn sẵn sàng.` },
              { status: 409 },
            );
          const bySerial = new Map(rows.results.map((row) => [row.serial, row]));
          chosenSerials.set(
            product.id,
            requested.map((serial) => bySerial.get(serial)!).filter(Boolean),
          );
        }
      }

      const normalizedLines = items.map((item, index) => {
        const product = products[index];
        const requestedPrice = Number(item.unitPrice);
        const unitPrice = Number.isFinite(requestedPrice)
          ? Math.max(0, Math.round(requestedPrice))
          : product.price;
        const lineSubtotal = unitPrice * item.quantity;
        const requestedDiscount = Number(item.discount);
        const lineDiscount = Number.isFinite(requestedDiscount)
          ? Math.min(lineSubtotal, Math.max(0, Math.round(requestedDiscount)))
          : 0;
        return {
          unitPrice,
          lineDiscount,
          note: item.note?.trim().slice(0, 500) || "",
        };
      });
      const subtotal = items.reduce(
        (sum, item, index) =>
          sum + normalizedLines[index].unitPrice * item.quantity,
        0,
      );
      const discount = normalizedLines.reduce(
        (sum, line) => sum + line.lineDiscount,
        0,
      );
      const total = Math.max(0, subtotal - discount);
      if (total < order.paid)
        return Response.json(
          {
            error:
              "Tổng tiền sau khi sửa không được thấp hơn số tiền khách đã thanh toán.",
          },
          { status: 409 },
        );

      const customerId = body.customerId?.trim() || "";
      if (!customerId)
        return Response.json(
          { error: "Vui lòng chọn khách hàng trước khi lưu đơn bán." },
          { status: 400 },
        );
      const customer = await db
        .prepare("SELECT id,name,phone,email,address FROM customers WHERE id=?")
        .bind(customerId)
        .first<{
          id: string;
          name: string;
          phone: string;
          email: string;
          address: string;
        }>();
      if (!customer)
        return Response.json(
          { error: "Khách hàng đã chọn không hợp lệ hoặc không còn tồn tại." },
          { status: 400 },
        );
      const customerName = customer.name;
      const address = customer.address;
      const channel = body.channel === "online" ? "online" : "pos";
      const createdAt = body.createdAt?.trim() || order.createdAt;
      const nextStatus = order.paid >= total ? "completed" : "processing";
      const statements = [];

      for (const oldItem of oldItems.results) {
        statements.push(
          db
            .prepare("UPDATE products SET stock = stock + ? WHERE id = ?")
            .bind(oldItem.quantity, oldItem.productId),
        );
        let oldSerials: string[] = [];
        try {
          oldSerials = JSON.parse(oldItem.serialsJson || "[]") as string[];
        } catch {
          oldSerials = [];
        }
        for (const serial of oldSerials)
          statements.push(
            db
              .prepare(
                "UPDATE serials SET status = 'available', order_id = NULL WHERE serial = ? AND order_id = ?",
              )
              .bind(serial, order.id),
          );
      }
      statements.push(
        db.prepare("DELETE FROM order_items WHERE order_id = ?").bind(order.id),
      );

      items.forEach((item, index) => {
        const product = products[index];
        const line = normalizedLines[index];
        const serialRows = chosenSerials.get(product.id) ?? [];
        statements.push(
          db
            .prepare(
              "INSERT INTO order_items (order_id, product_id, product_name, sku, quantity, unit_price, unit_cost, discount, note, serials_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            )
            .bind(
              order.id,
              product.id,
              product.name,
              product.sku,
              item.quantity,
              line.unitPrice,
              product.cost,
              line.lineDiscount,
              line.note,
              JSON.stringify(serialRows.map((serial) => serial.serial)),
            ),
        );
        statements.push(
          db
            .prepare("UPDATE products SET stock = stock - ? WHERE id = ?")
            .bind(item.quantity, product.id),
        );
        for (const serial of serialRows)
          statements.push(
            db
              .prepare(
                "UPDATE serials SET status = 'sold', order_id = ? WHERE id = ?",
              )
              .bind(order.id, serial.id),
          );
      });

      const allProductIds = new Set([
        ...oldItems.results.map((item) => item.productId),
        ...items.map((item) => item.productId),
      ]);
      for (const productId of allProductIds) {
        const before = oldQuantity.get(productId) ?? 0;
        const after = items.find((item) => item.productId === productId)?.quantity ?? 0;
        const delta = after - before;
        if (!delta) continue;
        const productName =
          products.find((product) => product.id === productId)?.name ||
          oldItems.results.find((item) => item.productId === productId)
            ?.productName ||
          "Sản phẩm";
        statements.push(
          db
            .prepare(
              "INSERT INTO inventory_movements (id, product_id, product_name, type, quantity, reference, note) VALUES (?, ?, ?, 'adjustment', ?, ?, 'Điều chỉnh khi sửa đơn hàng')",
            )
            .bind(
              crypto.randomUUID(),
              productId,
              productName,
              -delta,
              order.code,
            ),
        );
      }

      statements.push(
        db
          .prepare(
            "UPDATE orders SET customer_id = ?, customer_name = ?, subtotal = ?, discount = ?, total = ?, status = ?, channel = ?, shipping_address = ?, note = ?, created_at = ? WHERE id = ?",
          )
          .bind(
            customerId,
            customerName,
            subtotal,
            discount,
            total,
            nextStatus,
            channel,
            body.shippingAddress?.trim() || address,
            body.note?.trim() || "",
            createdAt,
            order.id,
          ),
      );
      const debt = await db
        .prepare(
          "SELECT id FROM debts WHERE partner_type = 'customer' AND reference = ? ORDER BY created_at DESC LIMIT 1",
        )
        .bind(order.code)
        .first<{ id: string }>();
      if (debt) {
        statements.push(
          db
            .prepare(
              "UPDATE debts SET partner_name = ?, total = ?, paid = ?, status = ? WHERE id = ?",
            )
            .bind(
              customerName,
              total,
              order.paid,
              order.paid >= total ? "paid" : order.paid > 0 ? "partial" : "open",
              debt.id,
            ),
        );
      } else if (order.paid < total) {
        statements.push(
          db
            .prepare(
              "INSERT INTO debts (id, partner_type, partner_name, reference, total, paid, due_date, status, settlement_type) VALUES (?, 'customer', ?, ?, ?, ?, '', ?, 'income')",
            )
            .bind(
              crypto.randomUUID(),
              customerName,
              order.code,
              total,
              order.paid,
              order.paid > 0 ? "partial" : "open",
            ),
        );
      }
      await db.batch(statements);
      return Response.json({ ok: true, total, status: nextStatus });
    }

    const allowed = ["pending", "processing", "completed", "cancelled"];
    if (!body.id || !body.status || !allowed.includes(body.status))
      return Response.json(
        { error: "Trạng thái đơn không hợp lệ." },
        { status: 400 },
      );
    const order = await db
      .prepare("SELECT id, code, customer_id AS customerId, customer_name AS customerName, status, total, paid, payment_method AS paymentMethod FROM orders WHERE id = ?")
      .bind(body.id)
      .first<{
        id: string;
        code: string;
        customerId: string | null;
        customerName: string;
        status: string;
        total: number;
        paid: number;
        paymentMethod: string;
      }>();
    if (!order)
      return Response.json(
        { error: "Không tìm thấy đơn hàng." },
        { status: 404 },
      );
    if (order.status === "cancelled")
      return Response.json(
        { error: "Đơn đã hủy không thể cập nhật." },
        { status: 409 },
      );
    if (body.status === "completed" && order.paid < order.total)
      return Response.json(
        { error: "Đơn chưa thanh toán đủ nên chưa thể hoàn thành." },
        { status: 409 },
      );
    if (body.status === "cancelled" && order.status !== "cancelled") {
      const cancellationReason = body.cancellationReason?.trim().slice(0, 500);
      if (!cancellationReason)
        return Response.json(
          { error: "Vui lòng nhập lý do hủy đơn." },
          { status: 400 },
        );
      const returned = await db
        .prepare("SELECT COUNT(*) AS total FROM returns WHERE order_id = ?")
        .bind(body.id)
        .first<{ total: number }>();
      if ((returned?.total ?? 0) > 0)
        return Response.json(
          { error: "Đơn đã phát sinh đổi trả nên không thể hủy toàn bộ." },
          { status: 409 },
        );
      const warrantySerial = await db
        .prepare(
          "SELECT serial FROM serials WHERE order_id = ? AND status = 'warranty' LIMIT 1",
        )
        .bind(body.id)
        .first<{ serial: string }>();
      if (warrantySerial)
        return Response.json(
          {
            error: `Serial ${warrantySerial.serial} đang trong quy trình bảo hành nên chưa thể hủy đơn.`,
          },
          { status: 409 },
        );
      const items = await db
        .prepare(
          "SELECT product_id AS productId, product_name AS productName, quantity, serials_json AS serialsJson FROM order_items WHERE order_id = ?",
        )
        .bind(body.id)
        .all<{
          productId: number;
          productName: string;
          quantity: number;
          serialsJson: string;
        }>();
      const statements = [
        db
          .prepare(
            "UPDATE orders SET status = 'cancelled', refunded = 0, cancellation_reason = ?, cancelled_at = CURRENT_TIMESTAMP WHERE id = ? AND status <> 'cancelled'",
          )
          .bind(cancellationReason, body.id),
      ];
      for (const item of items.results) {
        statements.push(
          db
            .prepare("UPDATE products SET stock = stock + ? WHERE id = ?")
            .bind(item.quantity, item.productId),
        );
        statements.push(
          db
            .prepare(
              "INSERT INTO inventory_movements (id, product_id, product_name, type, quantity, reference, note) VALUES (?, ?, ?, 'return', ?, ?, ?)",
            )
            .bind(
              crypto.randomUUID(),
              item.productId,
              item.productName,
              item.quantity,
              order.code,
              `Hoàn kho do hủy đơn: ${cancellationReason}`,
            ),
        );
        let itemSerials: string[] = [];
        try {
          itemSerials = JSON.parse(item.serialsJson || "[]") as string[];
        } catch {
          itemSerials = [];
        }
        for (const serial of itemSerials)
          statements.push(
            db
              .prepare(
                "UPDATE serials SET status = 'available', order_id = NULL WHERE serial = ? AND order_id = ?",
              )
              .bind(serial, body.id),
          );
      }
      if (order.paid > 0)
        statements.push(
          db
            .prepare(
              "INSERT INTO cash_transactions (id,type,category,note,amount,expected_amount,payment_method,status,partner_type,partner_name,reference,source_type,source_id,order_id) VALUES (?,'expense','Hoàn tiền hủy đơn',?,?,?,?, 'pending','customer',?,?,'order_cancel',?,?)",
            )
            .bind(
              crypto.randomUUID(),
              `Hoàn tiền đơn ${order.code}: ${cancellationReason}`,
              order.paid,
              order.paid,
              order.paymentMethod === "cash" ? "cash" : "transfer",
              order.customerName,
              order.code,
              order.id,
              order.id,
            ),
        );
      statements.push(
        db
          .prepare(
            "UPDATE debts SET total = 0, paid = 0, status = 'paid' WHERE partner_type = 'customer' AND reference = ?",
          )
          .bind(order.code),
      );
      await db.batch(statements);
    } else {
      await db
        .prepare("UPDATE orders SET status = ? WHERE id = ?")
        .bind(body.status, body.id)
        .run();
    }
    return Response.json({
      ok: true,
      refunded: 0,
      refundPending: body.status === "cancelled" ? order.paid : 0,
    });
  } catch (error) {
    return Response.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "Không thể cập nhật đơn hàng",
      },
      { status: 500 },
    );
  }
}
