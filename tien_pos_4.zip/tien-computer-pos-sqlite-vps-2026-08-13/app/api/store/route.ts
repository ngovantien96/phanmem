import { getD1 } from "../../../db/runtime";

async function ensureStoreSettings() {
  const db = getD1();
  await db
    .prepare(
      "INSERT OR IGNORE INTO store_settings (id, store_name, receipt_footer) VALUES (1, 'Tiến Computer', 'Cảm ơn quý khách đã mua hàng!')",
    )
    .run();
}

const scopes = [
  "products",
  "productOptions",
  "orders",
  "orderItems",
  "customers",
  "serials",
  "cashTransactions",
  "suppliers",
  "purchases",
  "inventoryMovements",
  "returns",
  "warranties",
  "debts",
  "settings",
] as const;

type Scope = (typeof scopes)[number];

export async function GET(request: Request) {
  try {
    const requestedParam = new URL(request.url).searchParams.get("scope");
    const requested = new Set<Scope>(
      requestedParam
        ? requestedParam
            .split(",")
            .filter((value): value is Scope => scopes.includes(value as Scope))
        : scopes,
    );

    if (requested.has("products") || requested.has("settings")) {
      await ensureStoreSettings();
    }
    const db = getD1();
    const result: Record<string, unknown> = {};
    const queries: Promise<void>[] = [];
    const list = (scope: Scope, sql: string) => {
      if (!requested.has(scope)) return;
      queries.push(
        db
          .prepare(sql)
          .all()
          .then((rows) => {
            result[scope] = rows.results;
          }),
      );
    };

    list(
      "products",
      "SELECT id, sku, name, category, brand, image_key AS imageKey, description, unit, warranty_months AS warrantyMonths, tracking, cost, price, stock, min_stock AS min, active, created_at AS createdAt FROM products WHERE active = 1 ORDER BY created_at DESC, id DESC",
    );
    list(
      "productOptions",
      "SELECT id, type, name FROM product_options ORDER BY type, name COLLATE NOCASE",
    );
    list(
      "orders",
      "SELECT id, code, customer_id AS customerId, customer_name AS customerName, subtotal, discount, total, paid, refunded, payment_method AS paymentMethod, status, channel, shipping_address AS shippingAddress, note, cancellation_reason AS cancellationReason, cancelled_at AS cancelledAt, created_at AS createdAt FROM orders ORDER BY created_at DESC LIMIT 200",
    );
    list(
      "orderItems",
      "SELECT id, order_id AS orderId, product_id AS productId, product_name AS productName, sku, quantity, unit_price AS unitPrice, unit_cost AS unitCost, discount, note, serials_json AS serialsJson FROM order_items ORDER BY id DESC LIMIT 500",
    );
    list(
      "customers",
      "SELECT id, code, name, phone, email, address, created_at AS createdAt FROM customers ORDER BY created_at DESC, rowid DESC LIMIT 100",
    );
    list(
      "serials",
      "SELECT s.id, s.product_id AS productId, s.serial, s.status, s.order_id AS orderId, p.name AS productName, p.sku FROM serials s JOIN products p ON p.id = s.product_id ORDER BY s.id DESC LIMIT 200",
    );
    list(
      "cashTransactions",
      "SELECT id, type, category, note, amount, expected_amount AS expectedAmount, payment_method AS paymentMethod, status, partner_type AS partnerType, partner_name AS partnerName, reference, source_type AS sourceType, source_id AS sourceId, settled_at AS settledAt, order_id AS orderId, created_at AS createdAt FROM cash_transactions ORDER BY created_at DESC LIMIT 100",
    );
    list(
      "suppliers",
      "SELECT id, code, name, phone, email, address, created_at AS createdAt FROM suppliers ORDER BY created_at DESC LIMIT 100",
    );
    list(
      "purchases",
      `SELECT p.id, p.code, p.supplier_id AS supplierId,
        p.supplier_name AS supplierName, p.total,
        CASE
          WHEN p.status = 'purchase_returned' THEN p.returned_amount
          ELSE MAX(p.paid, COALESCE((
            SELECT SUM(ct.amount)
            FROM cash_transactions ct
            WHERE ct.type = 'expense' AND (
              (ct.category = 'Nhập hàng' AND ct.note = 'Thanh toán phiếu ' || p.code)
              OR (ct.category = 'Nhập hàng' AND ct.note = 'Thanh toán thêm phiếu ' || p.code)
            )
          ), 0))
        END AS paid,
        p.status, p.note,
        COALESCE(p.received_at, p.created_at) AS receivedAt,
        p.returned_amount AS returnedAmount,
        COALESCE((SELECT amount FROM purchase_returns pr WHERE pr.purchase_id = p.id), 0) AS returnedTotal,
        p.return_reason AS returnReason,
        p.returned_at AS returnedAt,
        p.created_at AS createdAt
      FROM purchases p
      ORDER BY COALESCE(p.received_at, p.created_at) DESC, p.created_at DESC
      LIMIT 100`,
    );
    list(
      "inventoryMovements",
      "SELECT id, product_id AS productId, product_name AS productName, type, quantity, reference, note, created_at AS createdAt FROM inventory_movements ORDER BY created_at DESC LIMIT 300",
    );
    list(
      "returns",
      "SELECT id, code, order_id AS orderId, order_code AS orderCode, customer_name AS customerName, amount, paid, reason, items_json AS itemsJson, status, created_at AS createdAt FROM returns ORDER BY created_at DESC LIMIT 100",
    );
    list(
      "warranties",
      `SELECT id, code, service_type AS serviceType, source_type AS sourceType,
        customer_id AS customerId, customer_name AS customerName, phone,
        order_id AS orderId, order_code AS orderCode, product_id AS productId,
        product_name AS productName, product_sku AS productSku, brand, model, serial,
        sold_at AS soldAt, warranty_months AS warrantyMonths,
        warranty_until AS warrantyUntil, coverage_status AS coverageStatus,
        sale_note AS saleNote, issue, status, priority, accessories,
        received_condition AS receivedCondition, diagnosis, resolution, technician,
        estimated_cost AS estimatedCost, final_cost AS finalCost,
        expected_at AS expectedAt, note, completed_at AS completedAt,
        returned_at AS returnedAt, created_at AS createdAt, updated_at AS updatedAt
      FROM warranties ORDER BY updated_at DESC LIMIT 200`,
    );
    list(
      "debts",
      "SELECT id, partner_type AS partnerType, partner_name AS partnerName, reference, total, paid, due_date AS dueDate, status, settlement_type AS settlementType, source_transaction_id AS sourceTransactionId, created_at AS createdAt FROM debts ORDER BY created_at DESC LIMIT 100",
    );

    if (requested.has("settings")) {
      queries.push(
        db
        .prepare(
          "SELECT id, store_name AS storeName, phone, address, tax_code AS taxCode, receipt_footer AS receiptFooter, print_title AS printTitle, print_regulations AS printRegulations, print_customer_signer AS printCustomerSigner, print_sales_signer AS printSalesSigner, print_accountant_signer AS printAccountantSigner, print_footer AS printFooter, allow_negative_stock AS allowNegativeStock, auto_print AS autoPrint, low_stock_alert AS lowStockAlert, updated_at AS updatedAt FROM store_settings WHERE id = 1",
        )
          .first()
          .then((row) => {
            result.settings = row;
          }),
      );
    }

    await Promise.all(queries);
    return Response.json(result);
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Không thể tải dữ liệu cửa hàng";
    return Response.json({ error: message }, { status: 500 });
  }
}
