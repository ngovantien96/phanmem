import { getD1 } from "../../../db/runtime";

type PartnerType = "customer" | "supplier";

type PartnerRow = {
  id: string;
  code?: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  createdAt: string;
};

export async function GET(request: Request) {
  try {
    const params = new URL(request.url).searchParams;
    const type = params.get("type")?.trim() as PartnerType | undefined;
    const id = params.get("id")?.trim() || "";
    const requestedName = params.get("name")?.trim() || "";

    if (type !== "customer" && type !== "supplier") {
      return Response.json(
        { error: "Loại đối tượng không hợp lệ." },
        { status: 400 },
      );
    }
    if (!id && !requestedName) {
      return Response.json(
        { error: "Thiếu thông tin khách hàng hoặc nhà cung cấp." },
        { status: 400 },
      );
    }

    const db = getD1();
    let partner: PartnerRow | null = null;

    if (type === "customer") {
      partner = id
        ? await db
            .prepare(
              "SELECT id,code,name,phone,email,address,created_at AS createdAt FROM customers WHERE id=?",
            )
            .bind(id)
            .first<PartnerRow>()
        : await db
            .prepare(
              "SELECT id,code,name,phone,email,address,created_at AS createdAt FROM customers WHERE name=? COLLATE NOCASE ORDER BY created_at DESC, rowid DESC LIMIT 1",
            )
            .bind(requestedName)
            .first<PartnerRow>();
    } else {
      partner = id
        ? await db
            .prepare(
              "SELECT id,code,name,phone,email,address,created_at AS createdAt FROM suppliers WHERE id=?",
            )
            .bind(id)
            .first<PartnerRow>()
        : await db
            .prepare(
              "SELECT id,code,name,phone,email,address,created_at AS createdAt FROM suppliers WHERE name=? COLLATE NOCASE ORDER BY created_at DESC LIMIT 1",
            )
            .bind(requestedName)
            .first<PartnerRow>();
    }

    const partnerName = partner?.name || requestedName;
    const documents =
      type === "customer"
        ? await db
            .prepare(
              `SELECT id,code,total,paid,status,created_at AS happenedAt
               FROM orders
               WHERE (customer_id=? AND ?<>'') OR customer_name=? COLLATE NOCASE
               ORDER BY created_at DESC
               LIMIT 100`,
            )
            .bind(partner?.id || id, partner?.id || id, partnerName)
            .all()
        : await db
            .prepare(
              `SELECT id,code,total,paid,status,
                      COALESCE(received_at,created_at) AS happenedAt
               FROM purchases
               WHERE (supplier_id=? AND ?<>'') OR supplier_name=? COLLATE NOCASE
               ORDER BY COALESCE(received_at,created_at) DESC, created_at DESC
               LIMIT 100`,
            )
            .bind(partner?.id || id, partner?.id || id, partnerName)
            .all();

    return Response.json({
      partner: partner || {
        id: "",
        name: partnerName,
        phone: "",
        email: "",
        address: "",
        createdAt: "",
      },
      documents: documents.results,
    });
  } catch (error) {
    return Response.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "Không thể tải thông tin đối tượng.",
      },
      { status: 500 },
    );
  }
}
