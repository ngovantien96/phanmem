import { mkdir, readFile, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import { getDataDirectory } from "../../../db/runtime";

export const runtime = "nodejs";

const MAX_IMAGE_SIZE = 5 * 1024 * 1024;
const allowedTypes = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);

const validKey = (value: string) =>
  value.startsWith("product-images/") &&
  !value.includes("..") &&
  /^[a-zA-Z0-9/_-]+\.(?:jpe?g|png|webp|gif)$/.test(value);

const extensionFor = (contentType: string) =>
  ({ "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/gif": "gif" })[contentType] || "jpg";

const contentTypeFor = (key: string) => {
  const extension = path.extname(key).toLowerCase();
  return ({ ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif" })[extension] || "application/octet-stream";
};

const filePathFor = (key: string) => path.join(getDataDirectory(), key);

export async function GET(request: Request) {
  const key = new URL(request.url).searchParams.get("key") || "";
  if (!validKey(key)) return new Response("Không tìm thấy ảnh.", { status: 404 });
  try {
    const filePath = filePathFor(key);
    const [buffer, info] = await Promise.all([readFile(filePath), stat(filePath)]);
    return new Response(buffer, {
      headers: {
        "Content-Type": contentTypeFor(key),
        "Cache-Control": "public, max-age=31536000, immutable",
        ETag: `W/\"${info.size}-${Math.trunc(info.mtimeMs)}\"`,
      },
    });
  } catch {
    return new Response("Không tìm thấy ảnh.", { status: 404 });
  }
}

export async function POST(request: Request) {
  try {
    const form = await request.formData();
    const image = form.get("image");
    if (!(image instanceof File))
      return Response.json({ error: "Chưa chọn ảnh sản phẩm." }, { status: 400 });
    if (!allowedTypes.has(image.type))
      return Response.json({ error: "Chỉ hỗ trợ ảnh JPG, PNG, WEBP hoặc GIF." }, { status: 400 });
    if (!image.size || image.size > MAX_IMAGE_SIZE)
      return Response.json({ error: "Ảnh tối đa 5 MB." }, { status: 400 });

    const key = `product-images/${crypto.randomUUID()}.${extensionFor(image.type)}`;
    const filePath = filePathFor(key);
    await mkdir(path.dirname(filePath), { recursive: true });
    await writeFile(filePath, Buffer.from(await image.arrayBuffer()), { flag: "wx" });
    return Response.json({ key }, { status: 201 });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Không thể tải ảnh lên." },
      { status: 500 },
    );
  }
}
