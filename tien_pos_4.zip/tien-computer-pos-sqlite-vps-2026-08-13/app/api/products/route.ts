import { deleteProductImage, getD1 } from "../../../db/runtime";
import { nextShortCode, reserveShortCode } from "../../../db/short-codes";

type ProductPayload = {
  sku?: string;
  name?: string;
  category?: string;
  brand?: string;
  imageKey?: string;
  description?: string;
  unit?: string;
  warrantyMonths?: number;
  tracking?: "serial" | "quantity";
  cost?: number;
  price?: number;
  stock?: number;
  min?: number;
  serials?: string[];
};

export async function POST(request: Request) {
  try {
    const db = getD1();
    const body = (await request.json()) as ProductPayload;
    const name = body.name?.trim() ?? "";
    const enteredSku = body.sku?.trim().toUpperCase() || "";
    if (enteredSku) await reserveShortCode(db, "product", enteredSku);
    const sku = enteredSku || await nextShortCode(db, "product");
    const category = body.category?.trim() || "Chưa phân loại";
    const tracking = body.tracking === "serial" ? "serial" : "quantity";
    const serials = [
      ...new Set((body.serials ?? []).map((x) => x.trim()).filter(Boolean)),
    ];
    const stock =
      tracking === "serial"
        ? serials.length
        : Math.max(0, Number(body.stock) || 0);

    if (!name) {
      return Response.json(
        { error: "Tên sản phẩm là thông tin bắt buộc." },
        { status: 400 },
      );
    }

    const id = crypto.randomUUID();
    const statements = [
      db
        .prepare(
          "INSERT INTO products (sku, name, category, brand, image_key, description, unit, warranty_months, tracking, cost, price, stock, min_stock) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        )
        .bind(
          sku,
          name,
          category,
          body.brand?.trim() || "",
          body.imageKey?.trim() || "",
          body.description?.trim() || "",
          body.unit?.trim() || "Chiếc",
          Math.max(0, Number(body.warrantyMonths) || 0),
          tracking,
          Math.max(0, Number(body.cost) || 0),
          Math.max(0, Number(body.price) || 0),
          stock,
          Math.max(0, Number(body.min) || 0),
        ),
    ];

    // D1 cannot reference an auto-increment id inside the same batch, so serials are added after resolving the new product.
    await db.batch(statements);
    const product = await db
      .prepare(
        "SELECT id, sku, name, category, brand, image_key AS imageKey, description, unit, warranty_months AS warrantyMonths, tracking, cost, price, stock, min_stock AS min, active, created_at AS createdAt FROM products WHERE sku = ?",
      )
      .bind(sku)
      .first<{ id: number }>();
    if (!product) throw new Error(`Không thể tạo sản phẩm ${id}`);
    if (tracking === "serial" && serials.length) {
      await db.batch(
        serials.map((serial) =>
          db
            .prepare("INSERT INTO serials (product_id, serial) VALUES (?, ?)")
            .bind(product.id, serial),
        ),
      );
    }

    return Response.json({ product }, { status: 201 });
  } catch (error) {
    const message =
      error instanceof Error && error.message.includes("UNIQUE")
        ? "SKU hoặc serial đã tồn tại."
        : error instanceof Error
          ? error.message
          : "Không thể thêm sản phẩm";
    return Response.json({ error: message }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const db = getD1();
    const body = (await request.json()) as ProductPayload & {
      id?: number;
      action?: "edit" | "archive" | "adjust";
      adjustment?: number;
      reason?: string;
    };
    if (!body.id)
      return Response.json(
        { error: "Thiếu sản phẩm cần cập nhật." },
        { status: 400 },
      );
    const product = await db
      .prepare("SELECT id, name, tracking, stock, image_key AS imageKey FROM products WHERE id = ?")
      .bind(body.id)
      .first<{ id: number; name: string; tracking: string; stock: number; imageKey: string }>();
    if (!product)
      return Response.json(
        { error: "Không tìm thấy sản phẩm." },
        { status: 404 },
      );
    if (body.action === "archive") {
      await db
        .prepare("UPDATE products SET active = 0 WHERE id = ?")
        .bind(body.id)
        .run();
      return Response.json({ ok: true });
    }
    if (body.action === "adjust") {
      const adjustment = Math.trunc(Number(body.adjustment) || 0);
      if (!adjustment)
        return Response.json(
          { error: "Số lượng điều chỉnh phải khác 0." },
          { status: 400 },
        );
      if (product.stock + adjustment < 0)
        return Response.json(
          { error: "Không thể điều chỉnh tồn kho xuống dưới 0." },
          { status: 409 },
        );
      if (product.tracking === "serial" && adjustment > 0) {
        const serials = [
          ...new Set((body.serials ?? []).map((x) => x.trim()).filter(Boolean)),
        ];
        if (serials.length !== adjustment)
          return Response.json(
            { error: "Số serial phải đúng bằng số lượng tăng." },
            { status: 400 },
          );
        await db.batch([
          ...serials.map((serial) =>
            db
              .prepare("INSERT INTO serials (product_id, serial) VALUES (?, ?)")
              .bind(body.id, serial),
          ),
          db
            .prepare("UPDATE products SET stock = stock + ? WHERE id = ?")
            .bind(adjustment, body.id),
          db
            .prepare(
              "INSERT INTO inventory_movements (id, product_id, product_name, type, quantity, reference, note) VALUES (?, ?, ?, 'adjustment', ?, 'KIỂM KHO', ?)",
            )
            .bind(
              crypto.randomUUID(),
              body.id,
              product.name,
              adjustment,
              body.reason?.trim() || "Điều chỉnh tồn kho",
            ),
        ]);
      } else if (product.tracking === "serial" && adjustment < 0) {
        return Response.json(
          {
            error:
              "Với hàng serial, hãy dùng đổi trả/bảo hành để giảm tồn chính xác.",
          },
          { status: 400 },
        );
      } else {
        await db.batch([
          db
            .prepare("UPDATE products SET stock = stock + ? WHERE id = ?")
            .bind(adjustment, body.id),
          db
            .prepare(
              "INSERT INTO inventory_movements (id, product_id, product_name, type, quantity, reference, note) VALUES (?, ?, ?, 'adjustment', ?, 'KIỂM KHO', ?)",
            )
            .bind(
              crypto.randomUUID(),
              body.id,
              product.name,
              adjustment,
              body.reason?.trim() || "Điều chỉnh tồn kho",
            ),
        ]);
      }
      return Response.json({ ok: true });
    }
    const sku = body.sku?.trim().toUpperCase();
    const name = body.name?.trim();
    if (!sku || !name || !body.category || !Number(body.price))
      return Response.json(
        { error: "Vui lòng nhập đủ thông tin sản phẩm." },
        { status: 400 },
      );
    await reserveShortCode(db, "product", sku);
    await db
      .prepare(
        "UPDATE products SET sku=?, name=?, category=?, brand=?, image_key=?, description=?, unit=?, warranty_months=?, cost=?, price=?, min_stock=? WHERE id=?",
      )
      .bind(
        sku,
        name,
        body.category,
        body.brand?.trim() || "",
        body.imageKey === undefined ? product.imageKey : body.imageKey.trim(),
        body.description?.trim() || "",
        body.unit?.trim() || "Chiếc",
        Math.max(0, Number(body.warrantyMonths) || 0),
        Math.max(0, Number(body.cost) || 0),
        Number(body.price),
        Math.max(0, Number(body.min) || 0),
        body.id,
      )
      .run();
    if (
      body.imageKey !== undefined &&
      product.imageKey &&
      body.imageKey !== product.imageKey
    ) {
      await deleteProductImage(product.imageKey);
    }
    return Response.json({ ok: true });
  } catch (error) {
    const message =
      error instanceof Error && error.message.includes("UNIQUE")
        ? "SKU hoặc serial đã tồn tại."
        : error instanceof Error
          ? error.message
          : "Không thể cập nhật sản phẩm";
    return Response.json({ error: message }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const db = getD1();
    const body = (await request.json()) as { id?: number };
    const id = Math.trunc(Number(body.id) || 0);
    if (!id)
      return Response.json(
        { error: "Không xác định được sản phẩm cần xóa." },
        { status: 400 },
      );

    const product = await db
      .prepare("SELECT id, name, image_key AS imageKey FROM products WHERE id = ?")
      .bind(id)
      .first<{ id: number; name: string; imageKey: string }>();
    if (!product)
      return Response.json(
        { error: "Sản phẩm không tồn tại hoặc đã được xóa." },
        { status: 404 },
      );

    const transaction = await db
      .prepare(
        `SELECT
          (SELECT p.code FROM purchase_items pi JOIN purchases p ON p.id = pi.purchase_id WHERE pi.product_id = ? LIMIT 1) AS purchaseCode,
          (SELECT o.code FROM order_items oi JOIN orders o ON o.id = oi.order_id WHERE oi.product_id = ? LIMIT 1) AS orderCode,
          (SELECT reference FROM inventory_movements WHERE product_id = ? LIMIT 1) AS movementReference`,
      )
      .bind(id, id, id)
      .first<{
        purchaseCode: string | null;
        orderCode: string | null;
        movementReference: string | null;
      }>();

    if (transaction?.orderCode || transaction?.purchaseCode || transaction?.movementReference) {
      const reference =
        transaction.orderCode ||
        transaction.purchaseCode ||
        transaction.movementReference ||
        "lịch sử kho";
      return Response.json(
        {
          error: `Không thể xóa sản phẩm đã phát sinh giao dịch (${reference}). Bạn có thể dùng “Ngừng bán” để giữ nguyên lịch sử.`,
        },
        { status: 409 },
      );
    }

    await db.batch([
      db.prepare("DELETE FROM serials WHERE product_id = ?").bind(id),
      db.prepare("DELETE FROM products WHERE id = ?").bind(id),
    ]);
    if (product.imageKey) await deleteProductImage(product.imageKey);
    return Response.json({ ok: true });
  } catch (error) {
    return Response.json(
      {
        error:
          error instanceof Error ? error.message : "Không thể xóa sản phẩm.",
      },
      { status: 500 },
    );
  }
}
