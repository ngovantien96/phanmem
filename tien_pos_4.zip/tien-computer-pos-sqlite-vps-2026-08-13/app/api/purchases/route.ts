import { getD1 } from "../../../db/runtime";

export async function GET(request: Request) {
  try {
    const id = new URL(request.url).searchParams.get("id")?.trim();
    if (!id) return Response.json({ error: "Thiếu mã phiếu nhập." }, { status: 400 });
    const db = getD1();
    const [purchase, items, payments] = await Promise.all([
      db.prepare(
        "SELECT id,code,supplier_id AS supplierId,supplier_name AS supplierName,subtotal,discount,other_costs AS otherCosts,tax,tax_rate AS taxRate,total,paid,status,note,tags,costs_json AS costsJson,COALESCE(received_at,created_at) AS receivedAt,returned_amount AS returnedAmount,return_reason AS returnReason,returned_at AS returnedAt,created_at AS createdAt FROM purchases WHERE id=?",
      ).bind(id).first(),
      db.prepare(
        "SELECT pi.id,pi.product_id AS productId,pi.product_name AS productName,p.sku,p.unit,p.tracking,pi.quantity,pi.unit_cost AS unitCost,pi.discount,pi.note,pi.serials_json AS serialsJson FROM purchase_items pi JOIN products p ON p.id=pi.product_id WHERE pi.purchase_id=? ORDER BY pi.id",
      ).bind(id).all(),
      db.prepare(
        "SELECT id,amount,payment_method AS method FROM cash_transactions WHERE category='Nhập hàng' AND note IN ((SELECT 'Thanh toán phiếu ' || code FROM purchases WHERE id=?), (SELECT 'Thanh toán thêm phiếu ' || code FROM purchases WHERE id=?)) ORDER BY created_at,id",
      ).bind(id, id).all(),
    ]);
    if (!purchase) return Response.json({ error: "Phiếu nhập không tồn tại." }, { status: 404 });
    return Response.json({ purchase, items: items.results, payments: payments.results });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Không thể tải chi tiết phiếu nhập." }, { status: 500 });
  }
}
