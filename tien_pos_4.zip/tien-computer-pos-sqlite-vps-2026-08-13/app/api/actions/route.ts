import { getD1 } from "../../../db/runtime";
import { nextShortCode, reserveShortCode } from "../../../db/short-codes";

type Json = Record<string, unknown>;
const text = (value: unknown) =>
  typeof value === "string" ? value.trim() : "";
const phoneKey = (value: unknown) => text(value).replace(/\D/g, "");
const amount = (value: unknown) => Math.max(0, Math.round(Number(value) || 0));
const dateTime = (value: unknown) => {
  const raw = text(value);
  if (!raw) return new Date().toISOString();
  const parsed = new Date(raw);
  return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
};
export async function POST(request: Request) {
  try {
    const db = getD1();
    const body = (await request.json()) as Json;
    const action = text(body.action);

    if (action === "cash") {
      const type = body.type === "expense" ? "expense" : "income";
      const paymentMethod =
        body.paymentMethod === "cash" ? "cash" : "transfer";
      const value = amount(body.amount);
      if (!value || !text(body.category))
        return Response.json(
          { error: "Vui lòng nhập loại khoản và số tiền." },
          { status: 400 },
        );
      await db
        .prepare(
          "INSERT INTO cash_transactions (id, type, category, note, amount, expected_amount, payment_method, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'completed')",
        )
        .bind(
          crypto.randomUUID(),
          type,
          text(body.category),
          text(body.note),
          value,
          value,
          paymentMethod,
        )
        .run();
      return Response.json({ ok: true });
    }

    if (action === "customer") {
      const phone = text(body.phone);
      const name = text(body.name);
      const requestedId = text(body.id);
      if (!phone || !name)
        return Response.json(
          { error: "Tên và số điện thoại khách hàng là bắt buộc." },
          { status: 400 },
        );
      const existing = requestedId
        ? await db
            .prepare("SELECT id, code FROM customers WHERE id = ?")
            .bind(requestedId)
            .first<{ id: string; code: string }>()
        : await db
            .prepare("SELECT id, code FROM customers WHERE phone = ? ORDER BY created_at, rowid LIMIT 1")
            .bind(phone)
            .first<{ id: string; code: string }>();
      if (requestedId && !existing)
        return Response.json(
          { error: "Khách hàng cần sửa không còn tồn tại." },
          { status: 404 },
        );
      if (requestedId) {
        const samePhone = await db
          .prepare("SELECT id FROM customers WHERE phone = ? AND id <> ? LIMIT 1")
          .bind(phone, requestedId)
          .first<{ id: string }>();
        if (samePhone)
          return Response.json(
            { error: "Số điện thoại này đã thuộc về một khách hàng khác." },
            { status: 409 },
          );
      }
      const id = existing?.id || crypto.randomUUID();
      const code = existing?.code || await nextShortCode(db, "customer");
      await db
        .prepare(
          "INSERT INTO customers (id,code,name,phone,email,address) VALUES (?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,phone=excluded.phone,email=excluded.email,address=excluded.address",
        )
        .bind(id, code, name, phone, text(body.email), text(body.address))
        .run();
      return Response.json({ ok: true, id, code });
    }

    if (action === "customer-import") {
      const sourceRows = Array.isArray(body.customers) ? body.customers : [];
      if (!sourceRows.length)
        return Response.json(
          { error: "File chưa có khách hàng để nhập." },
          { status: 400 },
        );
      if (sourceRows.length > 1000)
        return Response.json(
          { error: "Mỗi lần chỉ được nhập tối đa 1.000 khách hàng." },
          { status: 400 },
        );

      const existingRows = await db
        .prepare("SELECT code, phone FROM customers")
        .all<{ code: string; phone: string }>();
      const usedPhones = new Set(existingRows.results.map((row) => phoneKey(row.phone)));
      const usedCodes = new Set(existingRows.results.map((row) => row.code.toUpperCase()));
      const accepted: Array<{ code: string; name: string; phone: string; email: string; address: string }> = [];
      let skipped = 0;

      for (const raw of sourceRows) {
        const row = raw && typeof raw === "object" ? raw as Json : {};
        const name = text(row.name);
        const phone = text(row.phone);
        const normalizedPhone = phoneKey(phone);
        const email = text(row.email);
        const address = text(row.address);
        const requestedCode = text(row.code).toUpperCase();
        const validCode = !requestedCode || /^KH\d{4,}$/.test(requestedCode);
        const validEmail = !email || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
        if (
          !name || name.length > 120 || normalizedPhone.length < 8 ||
          normalizedPhone.length > 15 || email.length > 120 || address.length > 250 ||
          !validCode || !validEmail || usedPhones.has(normalizedPhone) ||
          (requestedCode && usedCodes.has(requestedCode))
        ) {
          skipped += 1;
          continue;
        }

        const code = requestedCode || await nextShortCode(db, "customer");
        if (requestedCode) await reserveShortCode(db, "customer", code);
        usedPhones.add(normalizedPhone);
        usedCodes.add(code);
        accepted.push({ code, name, phone, email, address });
      }

      if (accepted.length) {
        await db.batch(
          accepted.map((row) =>
            db
              .prepare("INSERT INTO customers (id,code,name,phone,email,address) VALUES (?,?,?,?,?,?)")
              .bind(crypto.randomUUID(), row.code, row.name, row.phone, row.email, row.address),
          ),
        );
      }
      return Response.json({ ok: true, added: accepted.length, skipped });
    }

    if (action === "customer-delete") {
      const id = text(body.id);
      if (!id)
        return Response.json(
          { error: "Không xác định được khách hàng cần xóa." },
          { status: 400 },
        );

      const linkedOrder = await db
        .prepare("SELECT code FROM orders WHERE customer_id = ? LIMIT 1")
        .bind(id)
        .first<{ code: string }>();
      if (linkedOrder)
        return Response.json(
          {
            error: `Không thể xóa khách hàng đã phát sinh giao dịch (${linkedOrder.code}). Bạn vẫn có thể sửa thông tin khách hàng.`,
          },
          { status: 409 },
        );

      const result = await db
        .prepare("DELETE FROM customers WHERE id = ?")
        .bind(id)
        .run();
      if (!result.meta.changes)
        return Response.json(
          { error: "Khách hàng không tồn tại hoặc đã được xóa." },
          { status: 404 },
        );
      return Response.json({ ok: true });
    }

    if (action === "supplier") {
      const name = text(body.name);
      if (!name)
        return Response.json(
          { error: "Vui lòng nhập tên nhà cung cấp." },
          { status: 400 },
        );
      const id = text(body.id) || crypto.randomUUID();
      const supplierCode = text(body.code) || await nextShortCode(db, "supplier");
      await reserveShortCode(db, "supplier", supplierCode);
      await db
        .prepare(
          "INSERT INTO suppliers (id,code,name,phone,email,address) VALUES (?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET code=excluded.code,name=excluded.name,phone=excluded.phone,email=excluded.email,address=excluded.address",
        )
        .bind(
          id,
          supplierCode,
          name,
          text(body.phone),
          text(body.email),
          text(body.address),
        )
        .run();
      return Response.json({ ok: true, id });
    }

    if (action === "supplier-delete") {
      const id = text(body.id);
      if (!id)
        return Response.json(
          { error: "Không xác định được nhà cung cấp cần xóa." },
          { status: 400 },
        );

      const linkedPurchase = await db
        .prepare("SELECT code FROM purchases WHERE supplier_id = ? LIMIT 1")
        .bind(id)
        .first<{ code: string }>();
      if (linkedPurchase)
        return Response.json(
          {
            error: `Không thể xóa nhà cung cấp đã phát sinh giao dịch (${linkedPurchase.code}). Bạn vẫn có thể sửa thông tin nhà cung cấp.`,
          },
          { status: 409 },
        );

      const result = await db
        .prepare("DELETE FROM suppliers WHERE id = ?")
        .bind(id)
        .run();
      if (!result.meta.changes)
        return Response.json(
          { error: "Nhà cung cấp không tồn tại hoặc đã được xóa." },
          { status: 404 },
        );
      return Response.json({ ok: true });
    }

    if (action === "purchase-return") {
      const purchaseId = text(body.purchaseId);
      const reason = text(body.reason).slice(0, 500);
      if (!purchaseId || !reason)
        return Response.json(
          { error: "Vui lòng nhập lý do hoàn trả phiếu nhập." },
          { status: 400 },
        );

      const purchase = await db
        .prepare(
          "SELECT id,code,supplier_id AS supplierId,supplier_name AS supplierName,paid,status FROM purchases WHERE id=?",
        )
        .bind(purchaseId)
        .first<{
          id: string;
          code: string;
          supplierId: string | null;
          supplierName: string;
          paid: number;
          status: string;
        }>();
      if (!purchase)
        return Response.json(
          { error: "Phiếu nhập không tồn tại." },
          { status: 404 },
        );
      if (purchase.status === "purchase_returned")
        return Response.json(
          { error: "Phiếu nhập này đã được hoàn trả trước đó." },
          { status: 409 },
        );

      const previousReturn = await db
        .prepare("SELECT id FROM purchase_returns WHERE purchase_id=? LIMIT 1")
        .bind(purchaseId)
        .first<{ id: string }>();
      if (previousReturn)
        return Response.json(
          { error: "Phiếu nhập này đã được hoàn trả trước đó." },
          { status: 409 },
        );

      const itemRows = await db
        .prepare(
          "SELECT pi.product_id AS productId,pi.product_name AS productName,pi.quantity,pi.serials_json AS serialsJson,p.stock,p.tracking FROM purchase_items pi JOIN products p ON p.id=pi.product_id WHERE pi.purchase_id=? ORDER BY pi.id",
        )
        .bind(purchaseId)
        .all<{
          productId: number;
          productName: string;
          quantity: number;
          serialsJson: string;
          stock: number;
          tracking: string;
        }>();
      if (!itemRows.results.length)
        return Response.json(
          { error: "Phiếu nhập không có sản phẩm để hoàn trả." },
          { status: 400 },
        );

      const resolvedItems: Array<{
        productId: number;
        productName: string;
        quantity: number;
        serials: string[];
      }> = [];
      for (const item of itemRows.results) {
        if (item.stock < item.quantity)
          return Response.json(
            {
              error: `Không thể hoàn trả ${item.productName}: tồn kho hiện chỉ còn ${item.stock}, thấp hơn ${item.quantity} đã nhập.`,
            },
            { status: 409 },
          );
        let serials: string[] = [];
        try {
          serials = JSON.parse(item.serialsJson || "[]") as string[];
        } catch {
          serials = [];
        }
        if (item.tracking === "serial") {
          if (serials.length !== item.quantity)
            return Response.json(
              {
                error: `${item.productName}: phiếu nhập thiếu thông tin serial nên chưa thể hoàn trả tự động.`,
              },
              { status: 409 },
            );
          const placeholders = serials.map(() => "?").join(",");
          const available = await db
            .prepare(
              `SELECT serial FROM serials WHERE product_id=? AND serial IN (${placeholders}) AND status='available'`,
            )
            .bind(item.productId, ...serials)
            .all<{ serial: string }>();
          if (available.results.length !== serials.length)
            return Response.json(
              {
                error: `${item.productName}: có serial đã bán hoặc đang xử lý nên không thể hoàn trả toàn bộ phiếu.`,
              },
              { status: 409 },
            );
        }
        resolvedItems.push({
          productId: item.productId,
          productName: item.productName,
          quantity: item.quantity,
          serials,
        });
      }

      const refundableAmount = Math.max(0, purchase.paid);
      const receivedAmount = amount(body.receivedAmount);
      if (receivedAmount > refundableAmount)
        return Response.json({ error: "Số tiền thu lại không được vượt quá số đã trả cho nhà cung cấp." }, { status: 400 });
      const receivedMethod = body.receivedMethod === "cash" ? "cash" : "transfer";
      const returnId = crypto.randomUUID();
      const returnedAt = new Date().toISOString();
      const statements = [
        db
          .prepare(
            "INSERT INTO purchase_returns (id,purchase_id,purchase_code,supplier_name,amount,paid,reason) VALUES (?,?,?,?,?,?,?)",
          )
          .bind(
            returnId,
            purchase.id,
            purchase.code,
            purchase.supplierName,
            refundableAmount,
            receivedAmount,
            reason,
          ),
        db
          .prepare(
            "UPDATE purchases SET status='purchase_returned',returned_amount=?,return_reason=?,returned_at=? WHERE id=? AND status<>'purchase_returned'",
          )
          .bind(receivedAmount, reason, returnedAt, purchase.id),
      ];
      for (const item of resolvedItems) {
        statements.push(
          db
            .prepare(
              "UPDATE products SET stock=stock-? WHERE id=? AND stock>=?",
            )
            .bind(item.quantity, item.productId, item.quantity),
          db
            .prepare(
              "INSERT INTO inventory_movements (id,product_id,product_name,type,quantity,reference,note) VALUES (?,?,?,'purchase_return',?,?,?)",
            )
            .bind(
              crypto.randomUUID(),
              item.productId,
              item.productName,
              -item.quantity,
              purchase.code,
              `Hoàn trả nhà cung cấp: ${reason}`,
            ),
        );
        for (const serial of item.serials)
          statements.push(
            db
              .prepare(
                "DELETE FROM serials WHERE product_id=? AND serial=? AND status='available'",
              )
              .bind(item.productId, serial),
          );
      }
      if (receivedAmount > 0)
        statements.push(
          db
            .prepare(
              "INSERT INTO cash_transactions (id,type,category,note,amount,expected_amount,payment_method,status,partner_type,partner_name,reference,source_type,source_id) VALUES (?,'income','Hoàn trả nhập hàng',?,?,?,?,'completed','supplier',?,?,'purchase_return',?)",
            )
            .bind(
              crypto.randomUUID(),
              `Nhận hoàn tiền phiếu ${purchase.code}: ${reason}`,
              receivedAmount,
              receivedAmount,
              receivedMethod,
              purchase.supplierName,
              purchase.code,
              purchase.id,
            ),
        );
      statements.push(
        db
          .prepare(
            "UPDATE debts SET total=0,paid=0,status='paid' WHERE partner_type='supplier' AND reference=?",
          )
          .bind(purchase.code),
      );
      if (receivedAmount < refundableAmount)
        statements.push(
          db.prepare("INSERT INTO debts (id,partner_type,partner_name,reference,total,paid,due_date,status,settlement_type) VALUES (?,'supplier',?,?,?,?,?,'income')").bind(crypto.randomUUID(), purchase.supplierName, purchase.code, refundableAmount, receivedAmount, text(body.dueDate), receivedAmount > 0 ? "partial" : "open"),
        );
      await db.batch(statements);
      return Response.json({
        ok: true,
        code: purchase.code,
        refundedAmount: receivedAmount,
        refundableAmount,
      });
    }

    if (action === "purchase-update") {
      const purchaseId = text(body.purchaseId);
      const receivedAt = dateTime(body.receivedAt);
      if (!receivedAt)
        return Response.json(
          { error: "Ngày giờ nhập hàng không hợp lệ." },
          { status: 400 },
        );
      const oldPurchase = await db.prepare("SELECT id,code,status FROM purchases WHERE id=?").bind(purchaseId).first<{ id: string; code: string; status: string }>();
      if (!oldPurchase) return Response.json({ error: "Phiếu nhập không tồn tại." }, { status: 404 });
      if (oldPurchase.status === "purchase_returned")
        return Response.json({ error: "Phiếu đã hoàn trả nên không thể sửa." }, { status: 409 });
      const oldRows = await db.prepare("SELECT product_id AS productId,quantity,serials_json AS serialsJson FROM purchase_items WHERE purchase_id=?").bind(purchaseId).all<{ productId: number; quantity: number; serialsJson: string }>();
      for (const row of oldRows.results) {
        const product = await db.prepare("SELECT stock FROM products WHERE id=?").bind(row.productId).first<{ stock: number }>();
        if (!product || product.stock < row.quantity) return Response.json({ error: "Không thể sửa phiếu vì một phần hàng của phiếu đã được xuất kho." }, { status: 400 });
        const oldSerials = JSON.parse(row.serialsJson || "[]") as string[];
        if (oldSerials.length) {
          const placeholders = oldSerials.map(() => "?").join(",");
          const used = await db.prepare(`SELECT serial FROM serials WHERE product_id=? AND serial IN (${placeholders}) AND status<>'available' LIMIT 1`).bind(row.productId, ...oldSerials).first();
          if (used) return Response.json({ error: "Không thể sửa phiếu vì có serial đã được bán hoặc đang xử lý." }, { status: 400 });
        }
      }
      const rawItems = Array.isArray(body.items) ? (body.items as Json[]) : [];
      if (!rawItems.length) return Response.json({ error: "Phiếu nhập chưa có sản phẩm." }, { status: 400 });
      const rawCosts = Array.isArray(body.costs) ? (body.costs as Json[]) : [];
      const costs = rawCosts.map((item) => ({ name: text(item.name) || "Chi phí khác", amount: amount(item.amount) })).filter((item) => item.amount > 0);
      const rawPayments = Array.isArray(body.payments) ? (body.payments as Json[]) : [];
      const payments = rawPayments.map((item) => ({ amount: amount(item.amount), method: item.method === "cash" ? "cash" : "transfer" })).filter((item) => item.amount > 0);
      const supplierId = text(body.supplierId);
      const supplier = await db.prepare("SELECT name FROM suppliers WHERE id=?").bind(supplierId).first<{ name: string }>();
      if (!supplier) return Response.json({ error: "Vui lòng chọn nhà cung cấp hợp lệ." }, { status: 400 });
      const resolved: Array<{ id: number; name: string; qty: number; cost: number; discount: number; note: string; serials: string[] }> = [];
      for (const item of rawItems) {
        const id = Number(item.productId);
        const qty = Math.max(1, Math.trunc(Number(item.quantity) || 0));
        const product = await db.prepare("SELECT id,name,tracking,cost FROM products WHERE id=? AND active=1").bind(id).first<{ id: number; name: string; tracking: string; cost: number }>();
        if (!product) return Response.json({ error: "Có sản phẩm nhập không tồn tại." }, { status: 400 });
        const serials = Array.isArray(item.serials) ? [...new Set((item.serials as unknown[]).map(text).filter(Boolean))] : [];
        if (product.tracking === "serial" && serials.length !== qty) return Response.json({ error: `${product.name}: số serial phải bằng số lượng nhập.` }, { status: 400 });
        resolved.push({ id, name: product.name, qty, cost: amount(item.cost) || product.cost, discount: Math.min(qty * (amount(item.cost) || product.cost), amount(item.discount)), note: text(item.note), serials });
      }
      const subtotal = resolved.reduce((sum, item) => sum + item.cost * item.qty, 0);
      const discount = resolved.reduce((sum, item) => sum + item.discount, 0);
      const otherCosts = costs.reduce((sum, item) => sum + item.amount, 0);
      const taxRate = Math.min(100, amount(body.taxRate));
      const tax = Math.round((Math.max(0, subtotal - discount + otherCosts) * taxRate) / 100);
      const total = Math.max(0, subtotal - discount + otherCosts) + tax;
      const paid = payments.reduce((sum, item) => sum + item.amount, 0);
      if (paid > total) return Response.json({ error: "Tổng thanh toán không được vượt quá tiền cần trả." }, { status: 400 });
      const status = paid >= total ? "completed" : paid > 0 ? "partial" : "unpaid";
      const statements = [];
      for (const row of oldRows.results) {
        statements.push(db.prepare("UPDATE products SET stock=stock-? WHERE id=?").bind(row.quantity, row.productId));
        const serials = JSON.parse(row.serialsJson || "[]") as string[];
        for (const serial of serials) statements.push(db.prepare("DELETE FROM serials WHERE product_id=? AND serial=? AND status='available'").bind(row.productId, serial));
      }
      statements.push(
        db.prepare("DELETE FROM purchase_items WHERE purchase_id=?").bind(purchaseId),
        db.prepare("DELETE FROM inventory_movements WHERE reference=? AND type='purchase'").bind(oldPurchase.code),
        db.prepare("DELETE FROM cash_transactions WHERE category='Nhập hàng' AND note=?").bind(`Thanh toán phiếu ${oldPurchase.code}`),
        db.prepare("DELETE FROM cash_transactions WHERE category='Nhập hàng' AND note=?").bind(`Thanh toán thêm phiếu ${oldPurchase.code}`),
        db.prepare("DELETE FROM debts WHERE partner_type='supplier' AND reference=?").bind(oldPurchase.code),
        db.prepare("UPDATE purchases SET supplier_id=?,supplier_name=?,subtotal=?,discount=?,other_costs=?,tax=?,tax_rate=?,total=?,paid=?,status=?,note=?,tags=?,costs_json=?,received_at=? WHERE id=?").bind(supplierId, supplier.name, subtotal, discount, otherCosts, tax, taxRate, total, paid, status, text(body.note), text(body.tags), JSON.stringify(costs), receivedAt, purchaseId),
      );
      for (const item of resolved) {
        statements.push(
          db.prepare("INSERT INTO purchase_items (purchase_id,product_id,product_name,quantity,unit_cost,discount,note,serials_json) VALUES (?,?,?,?,?,?,?,?)").bind(purchaseId,item.id,item.name,item.qty,item.cost,item.discount,item.note,JSON.stringify(item.serials)),
          db.prepare("UPDATE products SET stock=stock+?,cost=? WHERE id=?").bind(item.qty, Math.max(0, Math.round((item.cost * item.qty - item.discount) / item.qty)), item.id),
          db.prepare("INSERT INTO inventory_movements (id,product_id,product_name,type,quantity,reference,note) VALUES (?,?,?,'purchase',?,?,?)").bind(crypto.randomUUID(),item.id,item.name,item.qty,oldPurchase.code,supplier.name),
        );
        for (const serial of item.serials) statements.push(db.prepare("INSERT INTO serials (product_id,serial) VALUES (?,?)").bind(item.id,serial));
      }
      for (const payment of payments) statements.push(db.prepare("INSERT INTO cash_transactions (id,type,category,note,amount,payment_method) VALUES (?,'expense','Nhập hàng',?,?,?)").bind(crypto.randomUUID(),`Thanh toán phiếu ${oldPurchase.code}`,payment.amount,payment.method));
      if (paid < total) statements.push(db.prepare("INSERT INTO debts (id,partner_type,partner_name,reference,total,paid,due_date,status,settlement_type) VALUES (?,'supplier',?,?,?,?,?,?,'expense')").bind(crypto.randomUUID(),supplier.name,oldPurchase.code,total,paid,text(body.dueDate),paid > 0 ? "partial" : "open"));
      await db.batch(statements);
      return Response.json({ ok: true, code: oldPurchase.code });
    }

    if (action === "purchase") {
      const receivedAt = dateTime(body.receivedAt);
      if (!receivedAt)
        return Response.json(
          { error: "Ngày giờ nhập hàng không hợp lệ." },
          { status: 400 },
        );
      const rawItems = Array.isArray(body.items) ? (body.items as Json[]) : [];
      if (!rawItems.length)
        return Response.json(
          { error: "Phiếu nhập chưa có sản phẩm." },
          { status: 400 },
        );
      // A purchase must always be tied to an existing supplier.  Do not create
      // an anonymous supplier from a free-text field: that makes later debt
      // reconciliation unreliable.
      const supplierId = text(body.supplierId);
      if (!supplierId)
        return Response.json(
          { error: "Vui lòng chọn nhà cung cấp trước khi tạo phiếu nhập." },
          { status: 400 },
        );
      const supplier = await db
        .prepare("SELECT id,name FROM suppliers WHERE id=?")
        .bind(supplierId)
        .first<{ id: string; name: string }>();
      if (!supplier)
        return Response.json(
          { error: "Nhà cung cấp đã chọn không hợp lệ hoặc không còn tồn tại." },
          { status: 400 },
        );
      const supplierName = supplier.name;
      const rawCosts = Array.isArray(body.costs) ? (body.costs as Json[]) : [];
      const costs = rawCosts
        .map((item) => ({ name: text(item.name) || "Chi phí khác", amount: amount(item.amount) }))
        .filter((item) => item.amount > 0);
      const rawPayments = Array.isArray(body.payments)
        ? (body.payments as Json[])
        : amount(body.paid) > 0
          ? [{ amount: body.paid, method: body.paymentMethod }]
          : [];
      const payments = rawPayments
        .map((item) => ({
          amount: amount(item.amount),
          method: item.method === "cash" ? "cash" : "transfer",
        }))
        .filter((item) => item.amount > 0);
      const purchaseId = crypto.randomUUID();
      const purchaseCode = await nextShortCode(db, "purchase");
      const resolved: Array<{
        id: number;
        name: string;
        tracking: string;
        qty: number;
        cost: number;
        discount: number;
        note: string;
        serials: string[];
      }> = [];
      for (const item of rawItems) {
        const id = Number(item.productId);
        const qty = Math.max(1, Math.trunc(Number(item.quantity) || 0));
        const product = await db
          .prepare(
            "SELECT id,name,tracking,cost FROM products WHERE id=? AND active=1",
          )
          .bind(id)
          .first<{
            id: number;
            name: string;
            tracking: string;
            cost: number;
          }>();
        if (!product)
          return Response.json(
            { error: "Có sản phẩm nhập không tồn tại." },
            { status: 400 },
          );
        const serials = Array.isArray(item.serials)
          ? [...new Set((item.serials as unknown[]).map(text).filter(Boolean))]
          : [];
        if (product.tracking === "serial" && serials.length !== qty)
          return Response.json(
            { error: `${product.name}: số serial phải bằng số lượng nhập.` },
            { status: 400 },
          );
        resolved.push({
          ...product,
          qty,
          cost: amount(item.cost) || product.cost,
          discount: Math.min(
            qty * (amount(item.cost) || product.cost),
            amount(item.discount),
          ),
          note: text(item.note),
          serials,
        });
      }
      const subtotal = resolved.reduce(
        (sum, item) => sum + item.cost * item.qty,
        0,
      );
      const discount = resolved.reduce((sum, item) => sum + item.discount, 0);
      const otherCosts = costs.reduce((sum, item) => sum + item.amount, 0);
      const taxRate = Math.min(100, amount(body.taxRate));
      const beforeTax = Math.max(0, subtotal - discount + otherCosts);
      const tax = Math.round((beforeTax * taxRate) / 100);
      const total = beforeTax + tax;
      const paid = payments.reduce((sum, payment) => sum + payment.amount, 0);
      if (paid > total)
        return Response.json(
          { error: "Tổng thanh toán không được vượt quá tiền cần trả." },
          { status: 400 },
        );
      const status =
        paid >= total ? "completed" : paid > 0 ? "partial" : "unpaid";
      const statements = [
        db
          .prepare(
            "INSERT INTO purchases (id,code,supplier_id,supplier_name,subtotal,discount,other_costs,tax,tax_rate,total,paid,status,note,tags,costs_json,received_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
          )
          .bind(
            purchaseId,
            purchaseCode,
            supplierId,
            supplierName,
            subtotal,
            discount,
            otherCosts,
            tax,
            taxRate,
            total,
            paid,
            status,
            text(body.note),
            text(body.tags),
            JSON.stringify(costs),
            receivedAt,
          ),
      ];
      for (const item of resolved) {
        statements.push(
          db
            .prepare(
              "INSERT INTO purchase_items (purchase_id,product_id,product_name,quantity,unit_cost,discount,note,serials_json) VALUES (?,?,?,?,?,?,?,?)",
            )
            .bind(
              purchaseId,
              item.id,
              item.name,
              item.qty,
              item.cost,
              item.discount,
              item.note,
              JSON.stringify(item.serials),
            ),
        );
        const effectiveCost = Math.max(
          0,
          Math.round((item.cost * item.qty - item.discount) / item.qty),
        );
        statements.push(
          db
            .prepare("UPDATE products SET stock=stock+?, cost=? WHERE id=?")
            .bind(item.qty, effectiveCost, item.id),
        );
        statements.push(
          db
            .prepare(
              "INSERT INTO inventory_movements (id,product_id,product_name,type,quantity,reference,note) VALUES (?,?,?,'purchase',?,?,?)",
            )
            .bind(
              crypto.randomUUID(),
              item.id,
              item.name,
              item.qty,
              purchaseCode,
              supplierName,
            ),
        );
        for (const serial of item.serials)
          statements.push(
            db
              .prepare("INSERT INTO serials (product_id,serial) VALUES (?,?)")
              .bind(item.id, serial),
          );
      }
      for (const payment of payments)
        statements.push(
          db
            .prepare(
              "INSERT INTO cash_transactions (id,type,category,note,amount,payment_method) VALUES (?,'expense','Nhập hàng',?,?,?)",
            )
            .bind(
              crypto.randomUUID(),
              `Thanh toán phiếu ${purchaseCode}`,
              payment.amount,
              payment.method,
            ),
        );
      if (paid < total)
        statements.push(
          db
            .prepare(
            "INSERT INTO debts (id,partner_type,partner_name,reference,total,paid,due_date,status,settlement_type) VALUES (?,'supplier',?,?,?,?,?,?,'expense')",
            )
            .bind(
              crypto.randomUUID(),
              supplierName,
              purchaseCode,
              total,
              paid,
              text(body.dueDate),
              paid > 0 ? "partial" : "open",
            ),
        );
      await db.batch(statements);
      return Response.json({ ok: true, code: purchaseCode });
    }

    if (action === "purchase-payment") {
      const purchaseId = text(body.purchaseId);
      const paymentAmount = amount(body.paymentAmount);
      const paymentMethod = body.paymentMethod === "cash" ? "cash" : "transfer";
      // Read the document itself first.  The former query used MAX() together
      // with a correlated cashbook query; on D1 it could produce a row with
      // null document values, leaving the modal open with no completed write.
      const purchase = await db
        .prepare(
          "SELECT id,code,supplier_name AS supplierName,total,paid,status FROM purchases WHERE id=?",
        )
        .bind(purchaseId)
        .first<{
          id: string;
          code: string;
          supplierName: string;
          total: number;
          paid: number;
          status: string;
        }>();
      if (!purchase || purchase.status === "purchase_returned") return Response.json({ error: "Phiếu nhập không hợp lệ để thanh toán thêm." }, { status: 400 });
      const alreadyPaid = Math.max(0, Number(purchase.paid) || 0);
      const total = Math.max(0, Number(purchase.total) || 0);
      const remaining = Math.max(0, total - alreadyPaid);
      if (!paymentAmount || paymentAmount > remaining) return Response.json({ error: `Số tiền thanh toán phải lớn hơn 0 và không vượt quá ${remaining}.` }, { status: 400 });
      const paid = alreadyPaid + paymentAmount;
      const status = paid >= total ? "completed" : "partial";
      const debt = await db.prepare("SELECT id FROM debts WHERE partner_type='supplier' AND reference=? AND settlement_type='expense' ORDER BY created_at DESC LIMIT 1").bind(purchase.code).first<{ id: string }>();
      const statements = [
        db.prepare("UPDATE purchases SET paid=?,status=? WHERE id=?").bind(paid, status, purchase.id),
        db.prepare("INSERT INTO cash_transactions (id,type,category,note,amount,expected_amount,payment_method,status,partner_type,partner_name,reference,source_type,source_id) VALUES (?,'expense','Nhập hàng',?,?,?,?,'completed','supplier',?,?,'purchase',?)").bind(crypto.randomUUID(), `Thanh toán thêm phiếu ${purchase.code}`, paymentAmount, paymentAmount, paymentMethod, purchase.supplierName, purchase.code, purchase.id),
      ];
      if (debt)
        statements.push(
          db
            .prepare(
              "UPDATE debts SET total=?,paid=?,status=?,settlement_type='expense' WHERE id=?",
            )
            .bind(total, paid, status === "completed" ? "paid" : "partial", debt.id),
        );
      else if (paid < total)
        statements.push(
          db
            .prepare(
              "INSERT INTO debts (id,partner_type,partner_name,reference,total,paid,due_date,status,settlement_type) VALUES (?,'supplier',?,?,?,?,?,?,'expense')",
            )
            .bind(
              crypto.randomUUID(),
              purchase.supplierName,
              purchase.code,
              total,
              paid,
              "",
              "partial",
            ),
        );
      await db.batch(statements);
      return Response.json({ ok: true, paid, remaining: total - paid });
    }

    if (action === "purchase-return-payment") {
      const purchaseId = text(body.purchaseId);
      const paymentAmount = amount(body.paymentAmount);
      const paymentMethod = body.paymentMethod === "cash" ? "cash" : "transfer";
      const row = await db.prepare("SELECT pr.purchase_id AS purchaseId,pr.purchase_code AS purchaseCode,pr.supplier_name AS supplierName,pr.amount,pr.paid FROM purchase_returns pr WHERE pr.purchase_id=?").bind(purchaseId).first<{ purchaseId: string; purchaseCode: string; supplierName: string; amount: number; paid: number }>();
      if (!row) return Response.json({ error: "Không tìm thấy phiếu hoàn trả nhà cung cấp." }, { status: 404 });
      const remaining = Math.max(0, row.amount - row.paid);
      if (!paymentAmount || paymentAmount > remaining) return Response.json({ error: `Số tiền thu phải lớn hơn 0 và không vượt quá ${remaining}.` }, { status: 400 });
      const paid = row.paid + paymentAmount;
      const debt = await db.prepare("SELECT id FROM debts WHERE partner_type='supplier' AND reference=? AND settlement_type='income' ORDER BY created_at DESC LIMIT 1").bind(row.purchaseCode).first<{ id: string }>();
      const statements = [
        db.prepare("UPDATE purchase_returns SET paid=? WHERE purchase_id=?").bind(paid, row.purchaseId),
        db.prepare("UPDATE purchases SET returned_amount=? WHERE id=?").bind(paid, row.purchaseId),
        db.prepare("INSERT INTO cash_transactions (id,type,category,note,amount,expected_amount,payment_method,status,partner_type,partner_name,reference,source_type,source_id) VALUES (?,'income','Hoàn trả nhập hàng',?,?,?,?,'completed','supplier',?,?,'purchase_return',?)").bind(crypto.randomUUID(), `Nhận hoàn tiền thêm phiếu ${row.purchaseCode}`, paymentAmount, paymentAmount, paymentMethod, row.supplierName, row.purchaseCode, row.purchaseId),
      ];
      if (debt) statements.push(db.prepare("UPDATE debts SET paid=?,status=? WHERE id=?").bind(paid, paid >= row.amount ? "paid" : "partial", debt.id));
      await db.batch(statements);
      return Response.json({ ok: true, paid, remaining: row.amount - paid });
    }

    if (action === "return") {
      const orderId = text(body.orderId);
      const reason = text(body.reason).slice(0, 500);
      if (!orderId || !reason)
        return Response.json(
          { error: "Vui lòng chọn đơn hàng và nhập lý do đổi trả." },
          { status: 400 },
        );
      const order = await db
        .prepare(
          "SELECT id,code,customer_name AS customerName,status,payment_method AS paymentMethod FROM orders WHERE id=?",
        )
        .bind(orderId)
        .first<{
          id: string;
          code: string;
          customerName: string;
          status: string;
          paymentMethod: string;
        }>();
      if (!order || order.status === "cancelled")
        return Response.json(
          { error: "Đơn hàng không hợp lệ để đổi trả." },
          { status: 400 },
        );
      const rawItems = Array.isArray(body.items) ? (body.items as Json[]) : [];
      if (!rawItems.length)
        return Response.json(
          { error: "Chưa chọn sản phẩm trả." },
          { status: 400 },
        );
      const previousReturns = await db
        .prepare("SELECT items_json AS itemsJson FROM returns WHERE order_id = ?")
        .bind(orderId)
        .all<{ itemsJson: string }>();
      // Old return records may have malformed/empty item details.  They must
      // not make a new return request fail silently at JSON.parse().
      const returnedItems = previousReturns.results.flatMap((row) => {
        try {
          const parsed = JSON.parse(row.itemsJson || "[]");
          return Array.isArray(parsed)
            ? (parsed as Array<{
                itemId: number;
                quantity: number;
                serials?: string[];
              }>)
            : [];
        } catch {
          return [];
        }
      });
      const returnCode = await nextShortCode(db, "return");
      let total = 0;
      const statements = [];
      const savedItems = [];
      for (const raw of rawItems) {
        const itemId = Number(raw.itemId);
        const qty = Math.max(1, Math.trunc(Number(raw.quantity) || 0));
        const item = await db
          .prepare(
            "SELECT id,product_id AS productId,product_name AS productName,quantity,unit_price AS unitPrice,serials_json AS serialsJson FROM order_items WHERE id=? AND order_id=?",
          )
          .bind(itemId, orderId)
          .first<{
            id: number;
            productId: number;
            productName: string;
            quantity: number;
            unitPrice: number;
            serialsJson: string;
          }>();
        if (!item)
          return Response.json(
            { error: "Sản phẩm được chọn không còn thuộc đơn hàng này." },
            { status: 400 },
          );
        const alreadyReturned = returnedItems
          .filter((row) => row.itemId === itemId)
          .reduce((sum, row) => sum + Math.max(0, Number(row.quantity) || 0), 0);
        if (qty > item.quantity - alreadyReturned)
          return Response.json(
            { error: "Số lượng trả vượt quá số lượng còn có thể đổi trả." },
            { status: 400 },
          );
        total += qty * item.unitPrice;
        statements.push(
          db
            .prepare("UPDATE products SET stock=stock+? WHERE id=?")
            .bind(qty, item.productId),
        );
        statements.push(
          db
            .prepare(
              "INSERT INTO inventory_movements (id,product_id,product_name,type,quantity,reference,note) VALUES (?,?,?,'return',?,?,?)",
            )
            .bind(
              crypto.randomUUID(),
              item.productId,
              item.productName,
              qty,
              returnCode,
              reason,
            ),
        );
        const returnedSerials = new Set(
          returnedItems.flatMap((row) => row.serials ?? []),
        );
        const serials = (JSON.parse(item.serialsJson || "[]") as string[])
          .filter((serial) => !returnedSerials.has(serial))
          .slice(0, qty);
        for (const serial of serials)
          statements.push(
            db
              .prepare(
                "UPDATE serials SET status='available',order_id=NULL WHERE serial=? AND order_id=?",
              )
              .bind(serial, orderId),
          );
        savedItems.push({
          itemId,
          productName: item.productName,
          quantity: qty,
          serials,
        });
      }
      const refundPaid = amount(body.refundPaid);
      if (refundPaid > total)
        return Response.json({ error: "Số tiền hoàn không được vượt quá giá trị phiếu đổi trả." }, { status: 400 });
      const refundMethod = body.refundMethod === "cash" ? "cash" : "transfer";
      const returnId = crypto.randomUUID();
      statements.push(
        db
          .prepare(
            "INSERT INTO returns (id,code,order_id,order_code,customer_name,amount,paid,reason,items_json,status) VALUES (?,?,?,?,?,?,?,?,?,?)",
          )
          .bind(
            returnId,
            returnCode,
            order.id,
            order.code,
            order.customerName,
            total,
            refundPaid,
            reason,
            JSON.stringify(savedItems),
            refundPaid >= total ? "completed" : refundPaid > 0 ? "partial" : "pending",
          ),
      );
      if (refundPaid > 0)
        statements.push(
          db
            .prepare(
              "INSERT INTO cash_transactions (id,type,category,note,amount,expected_amount,payment_method,status,partner_type,partner_name,reference,source_type,source_id,order_id) VALUES (?,'expense','Hoàn tiền',?,?,?,?,'completed','customer',?,?,'return',?,?)",
            )
            .bind(
              crypto.randomUUID(),
              `Hoàn tiền ${returnCode}`,
              refundPaid,
              refundPaid,
              refundMethod,
              order.customerName,
              returnCode,
              returnId,
              orderId,
            ),
        );
      if (refundPaid < total)
        statements.push(
          db.prepare("INSERT INTO debts (id,partner_type,partner_name,reference,total,paid,due_date,status,settlement_type) VALUES (?,'customer',?,?,?,?,?,'expense')").bind(crypto.randomUUID(), order.customerName, returnCode, total, refundPaid, text(body.dueDate), refundPaid > 0 ? "partial" : "open"),
        );
      await db.batch(statements);
      return Response.json({ ok: true, code: returnCode, amount: total, paid: refundPaid });
    }

    if (action === "return-payment") {
      const returnId = text(body.returnId);
      const paymentAmount = amount(body.paymentAmount);
      const paymentMethod = body.paymentMethod === "cash" ? "cash" : "transfer";
      const row = await db.prepare("SELECT id,code,order_id AS orderId,customer_name AS customerName,amount,paid FROM returns WHERE id=?").bind(returnId).first<{ id: string; code: string; orderId: string; customerName: string; amount: number; paid: number }>();
      if (!row) return Response.json({ error: "Không tìm thấy phiếu đổi trả." }, { status: 404 });
      const remaining = Math.max(0, row.amount - row.paid);
      if (!paymentAmount || paymentAmount > remaining) return Response.json({ error: `Số tiền hoàn phải lớn hơn 0 và không vượt quá ${remaining}.` }, { status: 400 });
      const paid = row.paid + paymentAmount;
      const debt = await db.prepare("SELECT id FROM debts WHERE partner_type='customer' AND reference=? AND settlement_type='expense' ORDER BY created_at DESC LIMIT 1").bind(row.code).first<{ id: string }>();
      const statements = [
        db.prepare("UPDATE returns SET paid=?,status=? WHERE id=?").bind(paid, paid >= row.amount ? "completed" : "partial", row.id),
        db.prepare("INSERT INTO cash_transactions (id,type,category,note,amount,expected_amount,payment_method,status,partner_type,partner_name,reference,source_type,source_id,order_id) VALUES (?,'expense','Hoàn tiền',?,?,?,?,'completed','customer',?,?,'return',?,?)").bind(crypto.randomUUID(), `Hoàn tiền thêm ${row.code}`, paymentAmount, paymentAmount, paymentMethod, row.customerName, row.code, row.id, row.orderId),
      ];
      if (debt) statements.push(db.prepare("UPDATE debts SET paid=?,status=? WHERE id=?").bind(paid, paid >= row.amount ? "paid" : "partial", debt.id));
      await db.batch(statements);
      return Response.json({ ok: true, paid, remaining: row.amount - paid });
    }

    if (action === "warranty-lookup") {
      const serial = text(body.serial);
      if (!serial)
        return Response.json({ error: "Vui lòng nhập Serial / IMEI cần tra cứu." }, { status: 400 });
      const row = await db.prepare(`
        SELECT s.serial, s.status AS serialStatus, s.product_id AS productId,
          p.name AS productName, p.sku AS productSku, p.brand,
          p.warranty_months AS warrantyMonths, s.order_id AS orderId,
          COALESCE(o.code, '') AS orderCode, COALESCE(o.created_at, '') AS soldAt,
          COALESCE(o.note, '') AS orderNote, COALESCE(o.customer_id, '') AS customerId,
          COALESCE(c.name, o.customer_name, '') AS customerName,
          COALESCE(c.phone, '') AS phone, COALESCE(c.address, '') AS address,
          COALESCE(oi.note, '') AS itemNote
        FROM serials s
        JOIN products p ON p.id=s.product_id
        LEFT JOIN orders o ON o.id=s.order_id AND o.status<>'cancelled'
        LEFT JOIN customers c ON c.id=o.customer_id
        LEFT JOIN order_items oi ON oi.order_id=o.id AND oi.product_id=s.product_id
        WHERE LOWER(s.serial)=LOWER(?)
        ORDER BY oi.id LIMIT 1
      `).bind(serial).first<Record<string, string | number>>();
      if (!row) return Response.json({ ok: true, found: false, serial });
      const warrantyMonths = Number(row.warrantyMonths || 0);
      const soldAt = String(row.soldAt || "");
      let warrantyUntil = "";
      let coverageStatus: "in_warranty" | "out_of_warranty" | "unknown" = "unknown";
      if (soldAt && warrantyMonths > 0) {
        const expiry = new Date(soldAt);
        expiry.setMonth(expiry.getMonth() + warrantyMonths);
        warrantyUntil = expiry.toISOString().slice(0, 10);
        coverageStatus = expiry.getTime() >= Date.now() ? "in_warranty" : "out_of_warranty";
      }
      const saleNote = [String(row.itemNote || ""), String(row.orderNote || "")].filter(Boolean).join(" · ");
      return Response.json({ ok: true, found: true, ...row, warrantyUntil, coverageStatus, saleNote });
    }

    if (action === "warranty-create") {
      const serial = text(body.serial);
      const serviceType = body.serviceType === "repair" ? "repair" : "warranty";
      let lookup: Record<string, string | number> | null = null;
      if (serial) {
        const active = await db.prepare("SELECT code FROM warranties WHERE LOWER(serial)=LOWER(?) AND status NOT IN ('returned','cancelled') LIMIT 1").bind(serial).first<{ code: string }>();
        if (active) return Response.json({ error: `Serial này đang có phiếu ${active.code} chưa kết thúc.` }, { status: 409 });
        lookup = await db.prepare(`
          SELECT s.product_id AS productId, p.name AS productName, p.sku AS productSku,
            p.brand, p.warranty_months AS warrantyMonths, COALESCE(s.order_id,'') AS orderId,
            COALESCE(o.code,'') AS orderCode, COALESCE(o.created_at,'') AS soldAt,
            COALESCE(o.note,'') AS orderNote, COALESCE(o.customer_id,'') AS customerId,
            COALESCE(c.name,o.customer_name,'') AS customerName, COALESCE(c.phone,'') AS phone,
            COALESCE(oi.note,'') AS itemNote
          FROM serials s JOIN products p ON p.id=s.product_id
          LEFT JOIN orders o ON o.id=s.order_id AND o.status<>'cancelled'
          LEFT JOIN customers c ON c.id=o.customer_id
          LEFT JOIN order_items oi ON oi.order_id=o.id AND oi.product_id=s.product_id
          WHERE LOWER(s.serial)=LOWER(?) ORDER BY oi.id LIMIT 1
        `).bind(serial).first<Record<string, string | number>>() || null;
      }
      const soldAt = String(lookup?.soldAt || text(body.soldAt));
      const warrantyMonths = Number(lookup?.warrantyMonths || amount(body.warrantyMonths));
      let warrantyUntil = text(body.warrantyUntil);
      let coverageStatus = text(body.coverageStatus) || "unknown";
      if (soldAt && warrantyMonths > 0) {
        const expiry = new Date(soldAt);
        expiry.setMonth(expiry.getMonth() + warrantyMonths);
        warrantyUntil = expiry.toISOString().slice(0, 10);
        coverageStatus = expiry.getTime() >= Date.now() ? "in_warranty" : "out_of_warranty";
      }
      const customerName = String(
        lookup?.customerId
          ? lookup.customerName
          : text(body.customerName) || lookup?.customerName || "",
      );
      const phone = String(lookup?.phone || text(body.phone));
      const productName = String(lookup?.productName || text(body.productName));
      const issue = text(body.issue);
      if (!customerName || !phone || !productName || !issue)
        return Response.json({ error: "Vui lòng nhập tên, số điện thoại, thiết bị và tình trạng tiếp nhận." }, { status: 400 });
      const id = crypto.randomUUID();
      const warrantyCode = await nextShortCode(db, "warranty");
      const saleNote = lookup
        ? [String(lookup.itemNote || ""), String(lookup.orderNote || "")].filter(Boolean).join(" · ")
        : text(body.saleNote);
      const statements = [db.prepare(`
        INSERT INTO warranties (
          id,code,service_type,source_type,customer_id,customer_name,phone,
          order_id,order_code,product_id,product_name,product_sku,brand,model,serial,
          sold_at,warranty_months,warranty_until,coverage_status,sale_note,issue,status,
          priority,accessories,received_condition,diagnosis,resolution,technician,
          estimated_cost,final_cost,expected_at,note
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'received',?,?,?,?,?,?,?,?,?,?)
      `).bind(
        id, warrantyCode, serviceType, lookup?.orderId ? "sale" : "manual",
        String(lookup?.customerId || text(body.customerId)), customerName, phone,
        String(lookup?.orderId || text(body.orderId)), String(lookup?.orderCode || text(body.orderCode)),
        lookup?.productId || (Number(body.productId) || null), productName,
        String(lookup?.productSku || text(body.productSku)), String(lookup?.brand || text(body.brand)),
        text(body.model), serial, soldAt, warrantyMonths, warrantyUntil, coverageStatus,
        saleNote, issue, text(body.priority) || "normal", text(body.accessories),
        text(body.receivedCondition), text(body.diagnosis), text(body.resolution),
        text(body.technician), amount(body.estimatedCost), amount(body.finalCost),
        text(body.expectedAt), text(body.note),
      )];
      if (lookup?.productId) statements.push(db.prepare("UPDATE serials SET status='warranty' WHERE LOWER(serial)=LOWER(?)").bind(serial));
      await db.batch(statements);
      return Response.json({ ok: true, code: warrantyCode });
    }

    if (action === "warranty-update") {
      const id = text(body.id), status = text(body.status);
      const allowed = ["received", "diagnosing", "waiting_customer", "waiting_parts", "repairing", "completed", "returned", "cancelled"];
      if (!id || !allowed.includes(status))
        return Response.json({ error: "Trạng thái phiếu không hợp lệ." }, { status: 400 });
      const row = await db.prepare("SELECT serial FROM warranties WHERE id=?").bind(id).first<{ serial: string }>();
      if (!row) return Response.json({ error: "Không tìm thấy phiếu bảo hành – sửa chữa." }, { status: 404 });
      const completedAt = status === "completed" ? new Date().toISOString() : text(body.completedAt);
      const returnedAt = status === "returned" ? new Date().toISOString() : text(body.returnedAt);
      const statements = [db.prepare(`
        UPDATE warranties SET status=?, priority=?, expected_at=?, technician=?, diagnosis=?,
          resolution=?, estimated_cost=?, final_cost=?, accessories=?, received_condition=?,
          issue=?, note=?, completed_at=?, returned_at=?, updated_at=CURRENT_TIMESTAMP WHERE id=?
      `).bind(
        status, text(body.priority) || "normal", text(body.expectedAt), text(body.technician),
        text(body.diagnosis), text(body.resolution), amount(body.estimatedCost), amount(body.finalCost),
        text(body.accessories), text(body.receivedCondition), text(body.issue), text(body.note),
        completedAt, returnedAt, id,
      )];
      if (row.serial && ["returned", "cancelled"].includes(status))
        statements.push(db.prepare("UPDATE serials SET status='sold' WHERE LOWER(serial)=LOWER(?) AND status='warranty'").bind(row.serial));
      await db.batch(statements);
      return Response.json({ ok: true });
    }

    if (action === "debt-create") {
      const partnerName = text(body.partnerName),
        total = amount(body.total),
        paid = Math.min(total, amount(body.paid));
      if (!partnerName || !total)
        return Response.json(
          { error: "Vui lòng nhập đối tác và số tiền công nợ." },
          { status: 400 },
        );
      await db
        .prepare(
          "INSERT INTO debts (id,partner_type,partner_name,reference,total,paid,due_date,status,settlement_type) VALUES (?,?,?,?,?,?,?,?,?)",
        )
        .bind(
          crypto.randomUUID(),
          body.partnerType === "supplier" ? "supplier" : "customer",
          partnerName,
          text(body.reference),
          total,
          paid,
          text(body.dueDate),
          paid >= total ? "paid" : paid > 0 ? "partial" : "open",
          body.settlementType === "expense"
            ? "expense"
            : body.settlementType === "income"
              ? "income"
              : body.partnerType === "supplier"
                ? "expense"
                : "income",
        )
        .run();
      return Response.json({ ok: true });
    }

    if (action === "cash-confirm") {
      const id = text(body.id);
      const transaction = await db
        .prepare(
          `SELECT id,type,category,note,amount,
             CASE WHEN expected_amount > 0 THEN expected_amount ELSE amount END AS expectedAmount,
             partner_type AS partnerType,partner_name AS partnerName,reference,
             source_type AS sourceType,source_id AS sourceId,order_id AS orderId,status
           FROM cash_transactions WHERE id=?`,
        )
        .bind(id)
        .first<{
          id: string;
          type: "income" | "expense";
          category: string;
          note: string;
          amount: number;
          expectedAmount: number;
          partnerType: "customer" | "supplier" | null;
          partnerName: string;
          reference: string;
          sourceType: string;
          sourceId: string;
          orderId: string | null;
          status: string;
        }>();
      if (!transaction)
        return Response.json(
          { error: "Khoản thu/chi không tồn tại." },
          { status: 404 },
        );
      if (transaction.status !== "pending")
        return Response.json(
          { error: "Khoản này đã được xác nhận trước đó." },
          { status: 409 },
        );

      const expected = transaction.expectedAmount;
      const settled = Math.min(expected, amount(body.amount));
      const remaining = expected - settled;
      const paymentMethod =
        body.paymentMethod === "cash" ? "cash" : "transfer";
      if (remaining > 0 && (!transaction.partnerType || !transaction.partnerName))
        return Response.json(
          { error: "Khoản này thiếu thông tin đối tác nên chưa thể chuyển phần còn lại vào công nợ." },
          { status: 409 },
        );

      const nextStatus =
        remaining === 0 ? "completed" : settled > 0 ? "partial" : "deferred";
      const statements = [
        db
          .prepare(
            "UPDATE cash_transactions SET amount=?,payment_method=?,status=?,settled_at=CURRENT_TIMESTAMP WHERE id=? AND status='pending'",
          )
          .bind(settled, paymentMethod, nextStatus, transaction.id),
      ];
      if (remaining > 0)
        statements.push(
          db
            .prepare(
              "INSERT INTO debts (id,partner_type,partner_name,reference,total,paid,due_date,status,settlement_type,source_transaction_id) VALUES (?,?,?,?,?,0,'','open',?,?)",
            )
            .bind(
              crypto.randomUUID(),
              transaction.partnerType,
              transaction.partnerName,
              transaction.reference,
              remaining,
              transaction.type,
              transaction.id,
            ),
        );
      if (transaction.sourceType === "order_cancel" && transaction.sourceId)
        statements.push(
          db
            .prepare("UPDATE orders SET refunded=? WHERE id=?")
            .bind(settled, transaction.sourceId),
        );
      await db.batch(statements);
      return Response.json({ ok: true, settled, remaining, status: nextStatus });
    }

    if (action === "debt-pay") {
      const id = text(body.id),
        pay = amount(body.amount);
      const debt = await db
        .prepare(
          "SELECT id,partner_type AS partnerType,partner_name AS partnerName,total,paid,reference,settlement_type AS settlementType,source_transaction_id AS sourceTransactionId FROM debts WHERE id=?",
        )
        .bind(id)
        .first<{
          id: string;
          partnerType: string;
          partnerName: string;
          total: number;
          paid: number;
          reference: string;
          settlementType: "income" | "expense";
          sourceTransactionId: string;
        }>();
      if (!debt || !pay)
        return Response.json(
          { error: "Khoản thanh toán không hợp lệ." },
          { status: 400 },
        );
      const next = Math.min(debt.total, debt.paid + pay),
        actual = next - debt.paid;
      const paymentMethod =
        body.paymentMethod === "cash" ? "cash" : "transfer";
      const statements = [
        db
          .prepare("UPDATE debts SET paid=?,status=? WHERE id=?")
          .bind(next, next >= debt.total ? "paid" : "partial", id),
        db
          .prepare(
            "INSERT INTO cash_transactions (id,type,category,note,amount,expected_amount,payment_method,status,partner_type,partner_name,reference,source_type,source_id) VALUES (?,?,?,?,?,?,?,'completed',?,?,?,'debt',?)",
          )
          .bind(
            crypto.randomUUID(),
            debt.settlementType,
            "Công nợ",
            `${debt.settlementType === "income" ? "Thu" : "Trả"} công nợ ${debt.reference || debt.partnerName}`,
            actual,
            actual,
            paymentMethod,
            debt.partnerType,
            debt.partnerName,
            debt.reference,
            debt.id,
          ),
      ];
      // Keep every source document in sync when an older or manually opened
      // debt is settled from the Công nợ screen.
      if (debt.partnerType === "supplier" && debt.settlementType === "expense")
        statements.push(
          db.prepare("UPDATE purchases SET paid=MIN(total,paid+?),status=CASE WHEN MIN(total,paid+?)>=total THEN 'completed' ELSE 'partial' END WHERE code=? AND status<>'purchase_returned'").bind(actual, actual, debt.reference),
        );
      if (debt.partnerType === "customer" && debt.settlementType === "expense")
        statements.push(
          db.prepare("UPDATE returns SET paid=MIN(amount,paid+?),status=CASE WHEN MIN(amount,paid+?)>=amount THEN 'completed' ELSE 'partial' END WHERE code=?").bind(actual, actual, debt.reference),
        );
      if (debt.partnerType === "supplier" && debt.settlementType === "income")
        statements.push(
          db.prepare("UPDATE purchase_returns SET paid=MIN(amount,paid+?) WHERE purchase_code=?").bind(actual, debt.reference),
          db.prepare("UPDATE purchases SET returned_amount=MIN(total,returned_amount+?) WHERE code=? AND status='purchase_returned'").bind(actual, debt.reference),
        );
      if (debt.partnerType === "customer" && debt.settlementType === "income")
        statements.push(
          db.prepare("UPDATE orders SET paid=MIN(total,paid+?),status=CASE WHEN MIN(total,paid+?)>=total THEN 'completed' ELSE 'processing' END WHERE code=? AND status<>'cancelled'").bind(actual, actual, debt.reference),
        );
      if (debt.sourceTransactionId) {
        const source = await db
          .prepare("SELECT source_type AS sourceType,source_id AS sourceId FROM cash_transactions WHERE id=?")
          .bind(debt.sourceTransactionId)
          .first<{ sourceType: string; sourceId: string }>();
        if (source?.sourceType === "order_cancel" && source.sourceId)
          statements.push(
            db
              .prepare("UPDATE orders SET refunded=MIN(paid,refunded+?) WHERE id=?")
              .bind(actual, source.sourceId),
          );
      }
      await db.batch(statements);
      return Response.json({ ok: true });
    }

    if (action === "settings") {
      await db
        .prepare(
          "INSERT INTO store_settings (id,store_name,phone,address,tax_code,receipt_footer,print_title,print_regulations,print_customer_signer,print_sales_signer,print_accountant_signer,print_footer,allow_negative_stock,auto_print,low_stock_alert,updated_at) VALUES (1,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET store_name=excluded.store_name,phone=excluded.phone,address=excluded.address,tax_code=excluded.tax_code,receipt_footer=excluded.receipt_footer,print_title=excluded.print_title,print_regulations=excluded.print_regulations,print_customer_signer=excluded.print_customer_signer,print_sales_signer=excluded.print_sales_signer,print_accountant_signer=excluded.print_accountant_signer,print_footer=excluded.print_footer,allow_negative_stock=excluded.allow_negative_stock,auto_print=excluded.auto_print,low_stock_alert=excluded.low_stock_alert,updated_at=CURRENT_TIMESTAMP",
        )
        .bind(
          text(body.storeName) || "Tiến Computer",
          text(body.phone),
          text(body.address),
          text(body.taxCode),
          text(body.receiptFooter) || "Cảm ơn quý khách!",
          text(body.printTitle) || "PHIẾU XUẤT KHO KIÊM BẢO HÀNH",
          text(body.printRegulations),
          text(body.printCustomerSigner) || "Khách hàng",
          text(body.printSalesSigner) || "Nhân viên KD",
          text(body.printAccountantSigner) || "Kế toán",
          text(body.printFooter),
          body.allowNegativeStock ? 1 : 0,
          body.autoPrint ? 1 : 0,
          body.lowStockAlert ? 1 : 0,
        )
        .run();
      return Response.json({ ok: true });
    }

    if (action === "settings-sales") {
      const columns = {
        allowNegativeStock: "allow_negative_stock",
        autoPrint: "auto_print",
        lowStockAlert: "low_stock_alert",
      } as const;
      const key = text(body.key) as keyof typeof columns;
      if (!columns[key])
        return Response.json(
          { error: "Thiết lập bán hàng không hợp lệ." },
          { status: 400 },
        );
      await db
        .prepare(
          `UPDATE store_settings SET ${columns[key]} = ?, updated_at = CURRENT_TIMESTAMP WHERE id = 1`,
        )
        .bind(body.value ? 1 : 0)
        .run();
      return Response.json({ ok: true, key, value: Boolean(body.value) });
    }

    return Response.json(
      { error: "Thao tác không được hỗ trợ." },
      { status: 400 },
    );
  } catch (error) {
    const message =
      error instanceof Error && error.message.includes("UNIQUE")
        ? "Mã hoặc serial đã tồn tại."
        : error instanceof Error
          ? error.message
          : "Không thể thực hiện thao tác";
    return Response.json({ error: message }, { status: 500 });
  }
}
