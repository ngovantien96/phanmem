"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  CartItem,
  Customer,
  Order,
  OrderItem,
  Product,
  StoreData,
  formatDate,
  inventoryValue,
  money,
} from "./types";
import {
  Chart,
  Empty,
  Field,
  Kpi,
  MoneyInput,
  Modal,
  OrderTable,
  PanelTitle,
  ProductImage,
  SpinnerButton,
  Status,
} from "./ui";

export type ViewProps = {
  data: StoreData;
  products: Product[];
  cart: CartItem[];
  setCart: React.Dispatch<React.SetStateAction<CartItem[]>>;
  add: (p: Product) => void;
  setActive: (s: string) => void;
  notify: (s: string) => void;
  reload: () => Promise<void>;
  api: (
    body: Record<string, unknown>,
    url?: string,
    method?: string,
  ) => Promise<Record<string, unknown>>;
  productDraft: string | null;
  openProductForm: (name?: string) => void;
  clearProductDraft: () => void;
  openOrders: () => Promise<void>;
  purchaseFormRequested: boolean;
  openPurchaseForm: () => void;
  consumePurchaseFormRequest: () => void;
  openDocument: (type: "order" | "purchase", id: string) => void;
  documentToOpen: { type: "order" | "purchase"; id: string } | null;
  consumeDocumentToOpen: () => void;
};

export function Dashboard(p: ViewProps) {
  const [revenuePeriod, setRevenuePeriod] = useState<"day" | "month" | "year">("day");
  const now = new Date();
  const valid = p.data.orders.filter((o) => o.status !== "cancelled");
  const periodOrders = valid.filter((order) => {
    const date = new Date(order.createdAt);
    if (revenuePeriod === "year") return date.getFullYear() === now.getFullYear();
    if (revenuePeriod === "month")
      return date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth();
    return date.toDateString() === now.toDateString();
  });
  const revenue = periodOrders.reduce((s, o) => s + o.total, 0);
  const profit = p.data.orderItems
    .filter((i) => periodOrders.some((o) => o.id === i.orderId))
    .reduce(
      (s, i) =>
        s + (i.unitPrice - i.unitCost) * i.quantity - i.discount,
      0,
    );
  const low = p.data.settings.lowStockAlert
    ? p.data.products.filter((x) => x.stock <= x.min)
    : [];
  const periodLabel = revenuePeriod === "day" ? "hôm nay" : revenuePeriod === "month" ? "tháng này" : "năm nay";
  const chartTitle = revenuePeriod === "day" ? "Doanh thu 7 ngày qua" : revenuePeriod === "month" ? "Doanh thu 30 ngày qua" : "Doanh thu 12 tháng qua";
  return (
    <>
      <div className="quick">
        <button className="primary" onClick={() => p.setActive("Bán hàng")}>
          ＋ Tạo đơn bán
        </button>
        <button onClick={p.openPurchaseForm}>⇩ Nhập hàng</button>
        <button onClick={() => p.openProductForm()}>◇ Thêm sản phẩm</button>
        <button onClick={() => p.setActive("Bảo hành – Sửa chữa")}>
          ♧ Tiếp nhận bảo hành
        </button>
      </div>
      <div className="dashboard-period" aria-label="Kỳ xem doanh thu">
        {(["day", "month", "year"] as const).map((period) => (
          <button
            type="button"
            key={period}
            className={revenuePeriod === period ? "selected" : ""}
            onClick={() => setRevenuePeriod(period)}
          >
            {{ day: "Ngày", month: "Tháng", year: "Năm" }[period]}
          </button>
        ))}
      </div>
      <div className="kpis">
        <Kpi
          icon="₫"
          label={`Doanh thu ${periodLabel}`}
          value={money(revenue)}
          tone="blue"
        />
        <Kpi
          icon="↗"
          label={`Lợi nhuận gộp ${periodLabel}`}
          value={money(profit)}
          tone="green"
        />
        <Kpi
          icon="▤"
          label={`Đơn ${periodLabel}`}
          value={String(periodOrders.length)}
          tone="purple"
        />
        <Kpi
          icon="!"
          label="Sắp hết hàng"
          value={String(low.length)}
          tone="orange"
        />
      </div>
      <div className="dash">
        <div className="left">
          <article className="panel">
            <PanelTitle
              text={chartTitle}
              sub="Không tính đơn đã hủy"
            />
            <Chart orders={p.data.orders} period={revenuePeriod} />
          </article>
          <article className="panel compact-list">
            <PanelTitle
              text="Cảnh báo tồn kho"
              action="Xem kho"
              onAction={() => p.setActive("Kho & serial")}
            />
            {low.length ? (
              low.slice(0, 6).map((x) => (
                <button key={x.id} onClick={() => p.setActive("Nhập hàng")}>
                  <span>
                    <b>{x.name}</b>
                    <small>{x.sku}</small>
                  </span>
                  <strong>
                    {x.stock} {x.unit}
                  </strong>
                </button>
              ))
            ) : (
              <Empty text="Kho đang ổn định" />
            )}
          </article>
        </div>
        <article className="panel">
          <PanelTitle
            text="Đơn hàng gần đây"
            action="Xem tất cả"
            onAction={() => p.setActive("Đơn hàng")}
          />
          <OrderTable
            orders={p.data.orders.slice(0, 8)}
            onOpen={() => p.setActive("Đơn hàng")}
          />
        </article>
      </div>
    </>
  );
}

export function POS(p: ViewProps) {
  const [category, setCategory] = useState("Tất cả");
  const [productQuery, setProductQuery] = useState("");
  const [productPickerOpen, setProductPickerOpen] = useState(false);
  const productPickerRef = useRef<HTMLDivElement>(null);
  const [busy, setBusy] = useState(false);
  const [customerPickerOpen, setCustomerPickerOpen] = useState(false);
  const customerPickerRef = useRef<HTMLDivElement>(null);
  const [customerQuery, setCustomerQuery] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(
    null,
  );
  const [customerModal, setCustomerModal] = useState(false);
  const [savingCustomer, setSavingCustomer] = useState(false);
  const [quickProduct, setQuickProduct] = useState<{
    name: string;
    sku: string;
    category: string;
    brand: string;
    tracking: "serial" | "quantity";
    cost: string;
    price: string;
    stock: string;
  } | null>(null);
  const [savingQuickProduct, setSavingQuickProduct] = useState(false);
  const [customer, setCustomer] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
  });
  const [newCustomer, setNewCustomer] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
  });
  const [method, setMethod] = useState("transfer");
  const [paid, setPaid] = useState(0);
  const normalizedProductQuery = productQuery.trim().toLowerCase();
  const items = p.data.products
    .filter(
      (x) =>
        (category === "Tất cả" || x.category === category) &&
        (!normalizedProductQuery ||
          `${x.name} ${x.sku} ${x.brand} ${x.category}`
            .toLowerCase()
            .includes(normalizedProductQuery)),
    )
    .sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime() ||
        b.id - a.id,
    );
  const normalizedCustomerQuery = customerQuery.trim().toLowerCase();
  const customerMatches = p.data.customers
    .filter(
      (x) =>
        !normalizedCustomerQuery ||
        `${x.name} ${x.phone} ${x.email}`
          .toLowerCase()
          .includes(normalizedCustomerQuery),
    )
    .slice(0, 6);
  const subtotal = p.cart.reduce((s, x) => s + x.unitPrice * x.qty, 0);
  const discount = p.cart.reduce(
    (sum, item) =>
      sum + Math.min(item.lineDiscount, item.unitPrice * item.qty),
    0,
  );
  const total = Math.max(0, subtotal - discount);
  const actualPaid = Math.min(total, Math.max(0, paid));
  const remaining = Math.max(0, total - actualPaid);
  const serialSelectionComplete = p.cart.every(
    (item) =>
      item.tracking !== "serial" ||
      (item.selectedSerials.length === item.qty &&
        item.selectedSerials.every(Boolean)),
  );
  useEffect(() => {
    const closePickers = (event: PointerEvent) => {
      if (!productPickerRef.current?.contains(event.target as Node)) {
        setProductPickerOpen(false);
      }
      if (!customerPickerRef.current?.contains(event.target as Node)) {
        setCustomerPickerOpen(false);
      }
    };
    document.addEventListener("pointerdown", closePickers);
    return () => document.removeEventListener("pointerdown", closePickers);
  }, []);
  const availableSerials = (productId: number) =>
    p.data.serials.filter(
      (serial) =>
        serial.productId === productId && serial.status === "available",
    );
  const canSellProduct = (product: Product) =>
    product.tracking === "quantity"
      ? p.data.settings.allowNegativeStock || product.stock > 0
      : availableSerials(product.id).length > 0;
  const sellableProductLabel = (product: Product) =>
    product.tracking === "quantity" && p.data.settings.allowNegativeStock
      ? "Cho phép bán âm"
      : String(
          product.tracking === "serial"
            ? availableSerials(product.id).length
            : Math.max(0, product.stock),
        );
  const selectSerial = (productId: number, index: number, serial: string) =>
    p.setCart((current) =>
      current.map((item) => {
        if (item.id !== productId) return item;
        const selectedSerials = [...item.selectedSerials];
        selectedSerials[index] = serial;
        return { ...item, selectedSerials };
      }),
    );
  const updateLine = (
    productId: number,
    changes: Partial<Pick<CartItem, "unitPrice" | "lineDiscount" | "lineNote">>,
  ) =>
    p.setCart((current) =>
      current.map((item) => {
        if (item.id !== productId) return item;
        const next = { ...item, ...changes };
        return {
          ...next,
          unitPrice: Math.max(0, next.unitPrice),
          lineDiscount: Math.min(
            Math.max(0, next.lineDiscount),
            Math.max(0, next.unitPrice * next.qty),
          ),
        };
      }),
    );
  const pay = async () => {
    if (!selectedCustomer) {
      p.notify("Vui lòng chọn hoặc tạo khách hàng trước khi hoàn tất đơn bán.");
      return;
    }
    const cartSnapshot = [...p.cart];
    const customerSnapshot = selectedCustomer;
    const shouldAutoPrint = p.data.settings.autoPrint;
    const printPopup = shouldAutoPrint
      ? window.open("", "_blank", "width=900,height=1100")
      : null;
    if (printPopup) {
      printPopup.opener = null;
      printPopup.document.write("<!doctype html><html lang=\"vi\"><head><meta charset=\"utf-8\"><title>Đang tạo hóa đơn…</title></head><body style=\"font-family:Arial;padding:24px\">Đang tạo hóa đơn…</body></html>");
      printPopup.document.close();
    }
    setBusy(true);
    try {
      const result = await p.api(
        {
          customerId: selectedCustomer.id,
          customer,
          paymentMethod: method,
          discount: 0,
          paid: actualPaid,
          items: cartSnapshot.map((x) => ({
            productId: x.id,
            quantity: x.qty,
            serials: x.selectedSerials,
            unitPrice: x.unitPrice,
            discount: x.lineDiscount,
            note: x.lineNote,
          })),
        },
        "/api/orders",
      );
      const createdOrder = result.order as Order;
      const printableItems: OrderItem[] = cartSnapshot.map((item, index) => ({
        id: -(index + 1),
        orderId: createdOrder.id,
        productId: item.id,
        productName: item.name,
        sku: item.sku,
        quantity: item.qty,
        unitPrice: item.unitPrice,
        unitCost: item.cost,
        discount: item.lineDiscount,
        note: item.lineNote,
        serialsJson: JSON.stringify(item.selectedSerials),
      }));
      if (shouldAutoPrint && printPopup) {
        printOrderA4(p, createdOrder, {
          popup: printPopup,
          items: printableItems,
          customer: customerSnapshot,
        });
      }
      p.setCart([]);
      setSelectedCustomer(null);
      setCustomer({ name: "", phone: "", email: "", address: "" });
      setPaid(0);
      setMethod("transfer");
      p.notify(
        shouldAutoPrint && !printPopup
          ? `Đã tạo đơn ${createdOrder.code}, nhưng trình duyệt đang chặn cửa sổ in. Hãy cho phép pop-up để tự động in.`
          : `Đã thanh toán đơn ${createdOrder.code}. Kho và sổ quỹ đã cập nhật.`,
      );
      await p.openOrders();
    } catch (error) {
      printPopup?.close();
      p.notify(error instanceof Error ? error.message : "Không thể hoàn tất đơn bán.");
    } finally {
      setBusy(false);
    }
  };
  const chooseCustomer = (item: Customer) => {
    setSelectedCustomer(item);
    setCustomer({
      name: item.name,
      phone: item.phone,
      email: item.email,
      address: item.address,
    });
    setCustomerQuery("");
    setCustomerPickerOpen(false);
  };
  const openNewCustomer = () => {
    const typed = customerQuery.trim();
    const looksLikePhone = /^[+\d\s.-]{7,}$/.test(typed);
    setNewCustomer({
      name: looksLikePhone ? "" : typed,
      phone: looksLikePhone ? typed.replace(/[\s.-]/g, "") : "",
      email: "",
      address: "",
    });
    setCustomerPickerOpen(false);
    setCustomerModal(true);
  };
  const saveCustomer = async () => {
    setSavingCustomer(true);
    try {
      const result = await p.api({ action: "customer", ...newCustomer });
      const created: Customer = {
        ...newCustomer,
        id: String(result.id),
        code: String(result.code),
        createdAt: new Date().toISOString(),
      };
      chooseCustomer(created);
      setCustomerModal(false);
      p.notify(`Đã thêm và chọn khách hàng ${created.name}.`);
      await p.reload();
    } finally {
      setSavingCustomer(false);
    }
  };
  const openQuickProduct = () => {
    setQuickProduct({
      name: productQuery.trim(),
      sku: "",
      category: "Chưa phân loại",
      brand: "",
      tracking: "quantity",
      cost: "",
      price: "",
      stock: "0",
    });
    setProductPickerOpen(false);
  };
  const saveQuickProduct = async () => {
    if (!quickProduct?.name.trim()) {
      p.notify("Tên sản phẩm là thông tin bắt buộc.");
      return;
    }
    setSavingQuickProduct(true);
    try {
      await p.api(
        {
          ...quickProduct,
          cost: Number(quickProduct.cost) || 0,
          price: Number(quickProduct.price) || 0,
          stock:
            quickProduct.tracking === "quantity"
              ? Number(quickProduct.stock) || 0
              : 0,
          min: 0,
          serials: [],
        },
        "/api/products",
      );
      setQuickProduct(null);
      setProductQuery("");
      await p.reload();
      setProductPickerOpen(true);
      p.notify("Đã thêm sản phẩm. Chọn sản phẩm để đưa vào đơn bán.");
    } finally {
      setSavingQuickProduct(false);
    }
  };
  return (
    <>
      <div className="pos pos-stacked">
        <article className="panel sale-order">
          <PanelTitle
            text="Thông tin đơn bán mới"
            sub={`${p.cart.reduce((s, x) => s + x.qty, 0)} sản phẩm`}
            action="Xóa đơn"
            onAction={() => {
              p.setCart([]);
              setPaid(0);
            }}
          />
          <div className="order-customer-row">
            <div className="pos-customer-picker" ref={customerPickerRef}>
              <span className="picker-label">Khách hàng</span>
            {selectedCustomer ? (
              <div className="selected-customer">
                <i>{selectedCustomer.name.slice(0, 1).toUpperCase()}</i>
                <span>
                  <b>{selectedCustomer.name}</b>
                  <small>{selectedCustomer.phone}</small>
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedCustomer(null);
                    setCustomer({
                      name: "",
                      phone: "",
                      email: "",
                      address: "",
                    });
                  }}
                  aria-label="Bỏ chọn khách hàng"
                >
                  ×
                </button>
              </div>
            ) : (
              <>
                <label className="customer-search">
                  <span>⌕</span>
                  <input
                    value={customerQuery}
                    onFocus={() => {
                      setProductPickerOpen(false);
                      setCustomerPickerOpen(true);
                    }}
                    onChange={(e) => {
                      setCustomerQuery(e.target.value);
                      setProductPickerOpen(false);
                      setCustomerPickerOpen(true);
                    }}
                    onKeyDown={(event) => {
                      if (event.key === "Escape")
                        setCustomerPickerOpen(false);
                    }}
                    placeholder="Tìm tên hoặc số điện thoại..."
                    aria-label="Tìm khách hàng"
                    aria-expanded={customerPickerOpen}
                    aria-controls="pos-customer-results"
                    autoComplete="off"
                  />
                </label>
                {customerPickerOpen && (
                  <div className="customer-results" id="pos-customer-results">
                    {customerMatches.map((x) => (
                      <button
                        type="button"
                        className="customer-result"
                        key={x.id}
                        onClick={() => chooseCustomer(x)}
                      >
                        <i>{x.name.slice(0, 1).toUpperCase()}</i>
                        <span>
                          <b>{x.name}</b>
                          <small>
                            {x.phone}
                            {x.email ? ` · ${x.email}` : ""}
                          </small>
                        </span>
                      </button>
                    ))}
                    {!customerMatches.length && (
                      <p>Không có khách hàng phù hợp.</p>
                    )}
                    <button
                      type="button"
                      className="add-customer-result"
                      onClick={openNewCustomer}
                    >
                      ＋ Thêm khách hàng mới
                    </button>
                  </div>
                )}
              </>
            )}
            </div>
            <div className="order-code-preview">
              <span>Phiếu bán</span>
              <b>Tự động tạo mã khi hoàn tất</b>
            </div>
          </div>
          <div className="order-product-picker" ref={productPickerRef}>
            <div className="product-picker-heading">
              <div>
                <b>Thông tin sản phẩm</b>
                <small>Tìm theo tên, SKU hoặc thương hiệu rồi nhấn để thêm vào phiếu</small>
              </div>
              <div className="suggestion-chips product-picker-chips">
                {["Tất cả", "Laptop", "Linh kiện", "Phụ kiện"].map((x) => (
                  <button
                    type="button"
                    key={x}
                    className={category === x ? "sel" : ""}
                    onClick={() => setCategory(x)}
                  >
                    {x}
                  </button>
                ))}
              </div>
            </div>
            <label className="product-picker-search">
              <span>⌕</span>
              <input
                value={productQuery}
                onFocus={() => {
                  setCustomerPickerOpen(false);
                  setProductPickerOpen(true);
                }}
                onChange={(event) => {
                  setProductQuery(event.target.value);
                  setCustomerPickerOpen(false);
                  setProductPickerOpen(true);
                }}
                onKeyDown={(event) => {
                  if (event.key === "Escape") setProductPickerOpen(false);
                }}
                placeholder="Tìm theo tên sản phẩm, mã SKU hoặc thương hiệu..."
                aria-label="Tìm và chọn sản phẩm"
                aria-expanded={productPickerOpen}
                aria-controls="pos-product-results"
                autoComplete="off"
              />
              {productQuery && (
                <button type="button" onClick={() => setProductQuery("")} aria-label="Xóa nội dung tìm kiếm">
                  ×
                </button>
              )}
            </label>
            {productPickerOpen && <div className="product-picker-results" id="pos-product-results">
              <button
                className="product-search-create"
                type="button"
                onClick={openQuickProduct}
              >
                <i aria-hidden="true">＋</i>
                <span>
                  <b>Thêm mới sản phẩm</b>
                  <small>
                    {productQuery.trim()
                      ? `Tạo sản phẩm “${productQuery.trim()}”`
                      : "Tạo sản phẩm nếu chưa có trong danh sách"}
                  </small>
                </span>
              </button>
              {items.length ? (
                items.map((x) => {
                  const sellable = canSellProduct(x);
                  return <button
                    className="product-picker-item product-search-row"
                    type="button"
                    key={x.id}
                    onClick={() => {
                      p.add(x);
                      setProductQuery("");
                      setProductPickerOpen(false);
                    }}
                    disabled={!sellable}
                  >
                    <ProductImage
                      imageKey={x.imageKey}
                      alt={x.name}
                      className="product-search-thumb"
                      fallback={x.category === "Laptop" ? "▱" : "◇"}
                    />
                    <span className="product-search-main">
                      <strong>{x.name}</strong>
                      <small>
                        {x.sku} · {x.unit || "Chiếc"}
                        {x.brand ? ` · ${x.brand}` : ""}
                      </small>
                    </span>
                    <span className="product-search-value">
                      <b>{money(x.price)}</b>
                      <small>Tồn: {x.stock} | Có thể bán: {sellableProductLabel(x)}</small>
                    </span>
                  </button>;
                })
              ) : (
                <div className="product-picker-empty">
                  <span>Không tìm thấy “{productQuery.trim()}”.</span>
                </div>
              )}
            </div>}
          </div>
          <div className="sale-lines">
            <div className="sale-line sale-line-head">
              <span>Sản phẩm</span>
              <span>Serial (nếu có)</span>
              <span>Ghi chú</span>
              <span>Số lượng</span>
              <span>Đơn giá</span>
              <span>Chiết khấu</span>
              <span>Thành tiền</span>
            </div>
            {p.cart.length ? (
              p.cart.map((x) => (
                <div className="sale-line" key={x.id}>
                  <div className="sale-product-info">
                    <b>{x.name}</b>
                    <small>{x.sku} · Tồn {x.stock}</small>
                    <button
                      className="remove-line"
                      type="button"
                      onClick={() =>
                        p.setCart((current) =>
                          current.filter((item) => item.id !== x.id),
                        )
                      }
                    >
                      Xóa
                    </button>
                  </div>
                  <div className="line-serials">
                    {x.tracking === "serial" ? (
                      Array.from({ length: x.qty }, (_, index) => (
                        <select
                          key={index}
                          value={x.selectedSerials[index] || ""}
                          aria-label={`Chọn serial ${index + 1} cho ${x.name}`}
                          onChange={(event) =>
                            selectSerial(x.id, index, event.target.value)
                          }
                        >
                          <option value="">Chọn serial #{index + 1}</option>
                          {availableSerials(x.id).map((serial) => {
                            const chosenElsewhere = x.selectedSerials.some(
                              (selected, selectedIndex) =>
                                selectedIndex !== index &&
                                selected === serial.serial,
                            );
                            return (
                              <option
                                key={serial.id}
                                value={serial.serial}
                                disabled={chosenElsewhere}
                              >
                                {serial.serial}
                              </option>
                            );
                          })}
                        </select>
                      ))
                    ) : (
                      <small>Không quản lý serial</small>
                    )}
                  </div>
                  <input
                    className="line-note"
                    value={x.lineNote}
                    maxLength={500}
                    placeholder="Ghi chú sản phẩm..."
                    aria-label={`Ghi chú cho ${x.name}`}
                    onChange={(event) =>
                      updateLine(x.id, { lineNote: event.target.value })
                    }
                  />
                  <div className="line-quantity">
                    <button
                      type="button"
                      onClick={() =>
                        p.setCart((c) =>
                          c.flatMap((i) =>
                            i.id === x.id
                              ? i.qty === 1
                                ? []
                                : [
                                    {
                                      ...i,
                                      qty: i.qty - 1,
                                      selectedSerials: i.selectedSerials.slice(
                                        0,
                                        i.qty - 1,
                                      ),
                                      lineDiscount: Math.min(
                                        i.lineDiscount,
                                        i.unitPrice * (i.qty - 1),
                                      ),
                                    },
                                  ]
                              : [i],
                          ),
                        )
                      }
                    >
                      −
                    </button>
                    <b>{x.qty}</b>
                    <button type="button" onClick={() => p.add(x)}>＋</button>
                  </div>
                  <MoneyInput
                    className="line-money-input"
                    value={x.unitPrice}
                    ariaLabel={`Đơn giá ${x.name}`}
                    onValueChange={(unitPrice) =>
                      updateLine(x.id, { unitPrice })
                    }
                  />
                  <MoneyInput
                    className="line-money-input"
                    max={x.unitPrice * x.qty}
                    value={x.lineDiscount}
                    ariaLabel={`Chiết khấu ${x.name}`}
                    onValueChange={(lineDiscount) =>
                      updateLine(x.id, {
                        lineDiscount,
                      })
                    }
                  />
                  <strong className="line-total">
                    {money(x.unitPrice * x.qty - x.lineDiscount)}
                  </strong>
                </div>
              ))
            ) : (
              <div className="empty sale-empty">
                ▤<b>Chưa có sản phẩm</b>
                <p>Tìm và chọn sản phẩm ở phía trên để thêm vào phiếu</p>
              </div>
            )}
          </div>
          <div className="sale-payment">
            <div className="payment-entry">
              <span className="picker-label">Hình thức khách đã trả</span>
              <div className="payment-methods compact-payment-methods">
                <button
                  type="button"
                  className={method === "cash" ? "selected" : ""}
                  onClick={() => setMethod("cash")}
                >
                  <i>₫</i>
                  <span>Tiền mặt</span>
                </button>
                <button
                  type="button"
                  className={method === "transfer" ? "selected" : ""}
                  onClick={() => setMethod("transfer")}
                >
                  <i>⇄</i>
                  <span>Chuyển khoản</span>
                </button>
              </div>
            </div>
            <label className="paid-entry">
              <span>Khách đã trả</span>
              <div>
                <MoneyInput
                  max={total}
                  value={actualPaid}
                  ariaLabel="Khách đã trả"
                  onValueChange={setPaid}
                />
                <button type="button" onClick={() => setPaid(total)}>
                  Trả đủ
                </button>
              </div>
              <small>Có thể nhập lại số tiền thực tế khách thanh toán</small>
            </label>
            <div className="sale-totals">
              <p>
                <span>Tổng tiền</span>
                <b>{money(subtotal)}</b>
              </p>
              {discount > 0 && (
                <p>
                  <span>Tổng chiết khấu</span>
                  <b>− {money(discount)}</b>
                </p>
              )}
              <p className="customer-payable">
                <span>Khách phải trả</span>
                <b>{money(total)}</b>
              </p>
              <p>
                <span>Khách đã trả</span>
                <b>{money(actualPaid)}</b>
              </p>
              <p className="remaining-payment">
                <span>Còn phải trả</span>
                <b>{money(remaining)}</b>
              </p>
            </div>
          </div>
          <div className="sale-submit">
            {!serialSelectionComplete && (
              <p className="serial-warning">
                Vui lòng chọn đủ serial trước khi thanh toán.
              </p>
            )}
            <SpinnerButton
              type="button"
              className="primary"
              busy={busy}
              disabled={!p.cart.length || !selectedCustomer || !serialSelectionComplete}
              onClick={pay}
            >
              Hoàn tất đơn bán
            </SpinnerButton>
          </div>
        </article>
      </div>
      {customerModal && (
        <Modal
          title="Thêm khách hàng mới"
          onClose={() => setCustomerModal(false)}
        >
          <div className="form-grid">
            <Field label="Tên khách hàng">
              <input
                autoFocus
                value={newCustomer.name}
                onChange={(e) =>
                  setNewCustomer({ ...newCustomer, name: e.target.value })
                }
                placeholder="Nguyễn Văn A"
              />
            </Field>
            <Field label="Số điện thoại">
              <input
                value={newCustomer.phone}
                onChange={(e) =>
                  setNewCustomer({ ...newCustomer, phone: e.target.value })
                }
                placeholder="09xxxxxxxx"
              />
            </Field>
            <Field label="Email">
              <input
                type="email"
                value={newCustomer.email}
                onChange={(e) =>
                  setNewCustomer({ ...newCustomer, email: e.target.value })
                }
                placeholder="email@example.com"
              />
            </Field>
            <Field label="Địa chỉ">
              <input
                value={newCustomer.address}
                onChange={(e) =>
                  setNewCustomer({ ...newCustomer, address: e.target.value })
                }
              />
            </Field>
          </div>
          <SpinnerButton
            className="primary modal-submit"
            busy={savingCustomer}
            disabled={!newCustomer.name.trim() || !newCustomer.phone.trim()}
            onClick={saveCustomer}
          >
            Lưu và chọn khách hàng
          </SpinnerButton>
        </Modal>
      )}
      {quickProduct && (
        <Modal
          title="Thêm sản phẩm mới"
          onClose={() => {
            if (!savingQuickProduct) setQuickProduct(null);
          }}
          wide
        >
          <div className="form-grid">
            <Field label="Tên sản phẩm *">
              <input
                autoFocus
                value={quickProduct.name}
                onChange={(event) =>
                  setQuickProduct({ ...quickProduct, name: event.target.value })
                }
                placeholder="Ví dụ: Chuột Logitech M185"
              />
            </Field>
            <Field label="Mã SKU">
              <input
                value={quickProduct.sku}
                onChange={(event) =>
                  setQuickProduct({ ...quickProduct, sku: event.target.value })
                }
                placeholder="Để trống để tự tạo"
              />
            </Field>
            <Field label="Nhóm hàng">
              <input
                value={quickProduct.category}
                onChange={(event) =>
                  setQuickProduct({ ...quickProduct, category: event.target.value })
                }
                placeholder="Laptop, linh kiện..."
              />
            </Field>
            <Field label="Thương hiệu">
              <input
                value={quickProduct.brand}
                onChange={(event) =>
                  setQuickProduct({ ...quickProduct, brand: event.target.value })
                }
              />
            </Field>
            <Field label="Giá vốn">
              <input
                type="number"
                min="0"
                value={quickProduct.cost}
                onChange={(event) =>
                  setQuickProduct({ ...quickProduct, cost: event.target.value })
                }
                placeholder="0"
              />
            </Field>
            <Field label="Giá bán">
              <input
                type="number"
                min="0"
                value={quickProduct.price}
                onChange={(event) =>
                  setQuickProduct({ ...quickProduct, price: event.target.value })
                }
                placeholder="0"
              />
            </Field>
            <Field label="Quản lý hàng">
              <select
                value={quickProduct.tracking}
                onChange={(event) =>
                  setQuickProduct({
                    ...quickProduct,
                    tracking: event.target.value === "serial" ? "serial" : "quantity",
                  })
                }
              >
                <option value="quantity">Theo số lượng</option>
                <option value="serial">Theo serial / IMEI</option>
              </select>
            </Field>
            {quickProduct.tracking === "quantity" ? (
              <Field label="Tồn kho ban đầu">
                <input
                  type="number"
                  min="0"
                  value={quickProduct.stock}
                  onChange={(event) =>
                    setQuickProduct({ ...quickProduct, stock: event.target.value })
                  }
                />
              </Field>
            ) : (
              <p className="quick-product-return-note">
                Serial / IMEI sẽ được nhập khi lập phiếu nhập hàng.
              </p>
            )}
          </div>
          <div className="modal-actions">
            <button
              type="button"
              disabled={savingQuickProduct}
              onClick={() => setQuickProduct(null)}
            >
              Hủy
            </button>
            <SpinnerButton
              className="primary"
              busy={savingQuickProduct}
              disabled={!quickProduct.name.trim()}
              onClick={saveQuickProduct}
            >
              Lưu sản phẩm
            </SpinnerButton>
          </div>
        </Modal>
      )}
    </>
  );
}

type ProductForm = {
  id?: number;
  sku: string;
  name: string;
  category: string;
  brand: string;
  imageKey: string;
  imageFile?: File;
  removeImage?: boolean;
  description: string;
  unit: string;
  warrantyMonths: string;
  tracking: "serial" | "quantity";
  cost: string;
  price: string;
  stock: string;
  min: string;
  serials: string;
};
const freshProduct: ProductForm = {
  sku: "",
  name: "",
  category: "Laptop",
  brand: "",
  imageKey: "",
  description: "",
  unit: "Chiếc",
  warrantyMonths: "0",
  tracking: "serial",
  cost: "",
  price: "",
  stock: "",
  min: "0",
  serials: "",
};

type ProductColumnKey =
  | "product"
  | "sku"
  | "category"
  | "brand"
  | "tracking"
  | "cost"
  | "price"
  | "stock"
  | "status"
  | "createdAt";

type ProductColumnSettings = {
  visible: ProductColumnKey[];
  filterable: ProductColumnKey[];
};

type ProductFilterValue = { value: string; to: string };
type ProductSort = { key: ProductColumnKey; direction: "asc" | "desc" };

const PRODUCT_COLUMNS: Array<{
  key: ProductColumnKey;
  label: string;
  kind: "text" | "select" | "number" | "date";
}> = [
  { key: "product", label: "Sản phẩm", kind: "text" },
  { key: "sku", label: "SKU", kind: "text" },
  { key: "category", label: "Nhóm hàng", kind: "select" },
  { key: "brand", label: "Thương hiệu", kind: "select" },
  { key: "tracking", label: "Quản lý", kind: "select" },
  { key: "cost", label: "Giá vốn", kind: "number" },
  { key: "price", label: "Giá bán", kind: "number" },
  { key: "stock", label: "Tồn kho", kind: "number" },
  { key: "status", label: "Trạng thái", kind: "select" },
  { key: "createdAt", label: "Ngày khởi tạo", kind: "date" },
];

const DEFAULT_PRODUCT_COLUMN_SETTINGS: ProductColumnSettings = {
  visible: [
    "product",
    "sku",
    "tracking",
    "cost",
    "price",
    "stock",
    "status",
    "createdAt",
  ],
  filterable: PRODUCT_COLUMNS.map((column) => column.key),
};

const emptyProductFilters = () =>
  PRODUCT_COLUMNS.reduce(
    (filters, column) => ({
      ...filters,
      [column.key]: { value: "", to: "" },
    }),
    {} as Record<ProductColumnKey, ProductFilterValue>,
  );

export function Products(p: ViewProps) {
  const [form, setForm] = useState<ProductForm | null>(() =>
    p.productDraft === null
      ? null
      : { ...freshProduct, name: p.productDraft },
  );
  const [busy, setBusy] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [localOptions, setLocalOptions] = useState(p.data.productOptions);
  const [addingOption, setAddingOption] = useState<"category" | "brand" | null>(
    null,
  );
  const [newOptionName, setNewOptionName] = useState("");
  const [savingOption, setSavingOption] = useState(false);
  const [columnSettings, setColumnSettings] =
    useState<ProductColumnSettings>(DEFAULT_PRODUCT_COLUMN_SETTINGS);
  const [columnSettingsDraft, setColumnSettingsDraft] =
    useState<ProductColumnSettings | null>(null);
  const [columnSettingsLoaded, setColumnSettingsLoaded] = useState(false);
  const [activeFilter, setActiveFilter] = useState<ProductColumnKey | null>(null);
  const [activeSortMenu, setActiveSortMenu] = useState<ProductColumnKey | null>(
    null,
  );
  const [productSort, setProductSort] = useState<ProductSort>({
    key: "createdAt",
    direction: "desc",
  });
  const [productFilters, setProductFilters] = useState(emptyProductFilters);

  useEffect(() => {
    let cancelled = false;
    queueMicrotask(() => {
      if (cancelled) return;
      try {
        const saved = window.localStorage.getItem("tien-product-columns-v1");
        if (saved) {
          const parsed = JSON.parse(saved) as Partial<ProductColumnSettings>;
          const validKeys = new Set(PRODUCT_COLUMNS.map((column) => column.key));
          const visible = (parsed.visible || []).filter((key) =>
            validKeys.has(key),
          );
          const filterable = (parsed.filterable || []).filter((key) =>
            validKeys.has(key),
          );
          if (visible.length) setColumnSettings({ visible, filterable });
        }
      } catch {
        // Keep the defaults when an older browser preference is invalid.
      } finally {
        setColumnSettingsLoaded(true);
      }
    });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!columnSettingsLoaded) return;
    window.localStorage.setItem(
      "tien-product-columns-v1",
      JSON.stringify(columnSettings),
    );
  }, [columnSettings, columnSettingsLoaded]);
  const optionNames = (type: "category" | "brand") => {
    const fromProducts = p.data.products.map((product) => product[type]);
    const current = form?.[type] ? [form[type]] : [];
    return [...new Set([
      ...p.data.productOptions
        .filter((option) => option.type === type)
        .map((option) => option.name),
      ...localOptions
        .filter((option) => option.type === type)
        .map((option) => option.name),
      ...fromProducts,
      ...current,
    ].map((name) => name.trim()).filter(Boolean))].sort((a, b) =>
      a.localeCompare(b, "vi", { sensitivity: "base" }),
    );
  };
  const categoryOptions = optionNames("category");
  const brandOptions = optionNames("brand");
  const openAddOption = (type: "category" | "brand") => {
    setAddingOption(type);
    setNewOptionName("");
  };
  const saveOption = async () => {
    if (!addingOption || !newOptionName.trim() || !form) return;
    setSavingOption(true);
    try {
      const result = await p.api(
        { type: addingOption, name: newOptionName },
        "/api/product-options",
      );
      const option = result.option as {
        id: number;
        type: "category" | "brand";
        name: string;
      };
      setLocalOptions((current) =>
        current.some(
          (item) =>
            item.type === option.type &&
            item.name.localeCompare(option.name, "vi", { sensitivity: "base" }) === 0,
        )
          ? current
          : [...current, option],
      );
      setForm({ ...form, [addingOption]: option.name });
      setAddingOption(null);
      setNewOptionName("");
      p.notify(
        result.created
          ? `Đã thêm ${addingOption === "category" ? "nhóm hàng" : "thương hiệu"}.`
          : "Tùy chọn này đã có trong danh sách.",
      );
    } finally {
      setSavingOption(false);
    }
  };
  const save = async () => {
    if (!form) return;
    setBusy(true);
    try {
      let imageKey = form.removeImage ? "" : form.imageKey;
      if (form.imageFile) {
        const imageData = new FormData();
        imageData.append("image", form.imageFile);
        const upload = await fetch("/api/product-image", {
          method: "POST",
          body: imageData,
        });
        const uploadResult = (await upload.json()) as { key?: string; error?: string };
        if (!upload.ok || !uploadResult.key)
          throw new Error(uploadResult.error || "Không thể tải ảnh lên.");
        imageKey = uploadResult.key;
      }
      const payload = {
        ...form,
        id: form.id,
        action: form.id ? "edit" : undefined,
        cost: Number(form.cost),
        price: Number(form.price),
        stock: Number(form.stock),
        min: Number(form.min),
        warrantyMonths: Number(form.warrantyMonths),
        serials: form.serials.split(/[,\n]/),
        imageKey,
      };
      await p.api(payload, "/api/products", form.id ? "PATCH" : "POST");
      setForm(null);
      setImagePreview(null);
      p.clearProductDraft();
      p.notify(
        form.id ? "Đã cập nhật sản phẩm." : "Đã thêm sản phẩm và nhập kho.",
      );
      await p.reload();
    } finally {
      setBusy(false);
    }
  };
  const edit = (x: Product) => {
    if (imagePreview?.startsWith("blob:")) URL.revokeObjectURL(imagePreview);
    setImagePreview(null);
    setForm({
      id: x.id,
      sku: x.sku,
      name: x.name,
      category: x.category,
      brand: x.brand,
      imageKey: x.imageKey || "",
      description: x.description,
      unit: x.unit,
      warrantyMonths: String(x.warrantyMonths),
      tracking: x.tracking,
      cost: String(x.cost),
      price: String(x.price),
      stock: String(x.stock),
      min: String(x.min),
      serials: "",
    });
  };
  const archive = async (x: Product) => {
    if (!confirm(`Ngừng kinh doanh ${x.name}?`)) return;
    await p.api({ id: x.id, action: "archive" }, "/api/products", "PATCH");
    p.notify("Đã chuyển sản phẩm sang ngừng kinh doanh.");
    await p.reload();
  };
  const remove = async (x: Pick<Product, "id" | "name">) => {
    if (!confirm(`Xóa sản phẩm ${x.name}?\n\nChỉ sản phẩm chưa phát sinh giao dịch mới được phép xóa.`)) return;
    setBusy(true);
    try {
      await p.api({ id: x.id }, "/api/products", "DELETE");
      if (form?.id === x.id) {
        setForm(null);
        p.clearProductDraft();
      }
      p.notify(`Đã xóa sản phẩm ${x.name}.`);
      await p.reload();
    } catch (error) {
      p.notify(error instanceof Error ? error.message : "Không thể xóa sản phẩm.");
    } finally {
      setBusy(false);
    }
  };

  const visibleColumns = PRODUCT_COLUMNS.filter((column) =>
    columnSettings.visible.includes(column.key),
  );
  const activeFilterDefinition = PRODUCT_COLUMNS.find(
    (column) => column.key === activeFilter,
  );
  const activeSortDefinition = PRODUCT_COLUMNS.find(
    (column) => column.key === activeSortMenu,
  );
  const selectOptions = (key: ProductColumnKey) => {
    if (key === "tracking")
      return [
        ["serial", "Theo serial"],
        ["quantity", "Theo số lượng"],
      ];
    if (key === "status")
      return [
        ["available", "Đủ hàng"],
        ["low", "Sắp hết hàng"],
      ];
    if (key === "category" || key === "brand")
      return [
        ...new Set(
          p.data.products.map((product) => product[key]).filter(Boolean),
        ),
      ]
        .sort((a, b) => a.localeCompare(b, "vi"))
        .map((value) => [value, value]);
    return [];
  };
  const filteredProducts = useMemo(() => {
    const textIncludes = (source: string, query: string) =>
      source.toLocaleLowerCase("vi").includes(query.toLocaleLowerCase("vi"));
    return [...p.products]
      .filter((product) =>
        PRODUCT_COLUMNS.every((column) => {
          const filter = productFilters[column.key];
          if (!filter.value && !filter.to) return true;
          if (column.key === "product")
            return textIncludes(
              `${product.name} ${product.description}`,
              filter.value,
            );
          if (column.key === "sku") return textIncludes(product.sku, filter.value);
          if (column.key === "category" || column.key === "brand")
            return product[column.key] === filter.value;
          if (column.key === "tracking") return product.tracking === filter.value;
          if (column.key === "status")
            return filter.value === "low"
              ? product.stock <= product.min
              : product.stock > product.min;
          if (["cost", "price", "stock"].includes(column.key)) {
            const amount = product[column.key as "cost" | "price" | "stock"];
            return (
              (!filter.value || amount >= Number(filter.value)) &&
              (!filter.to || amount <= Number(filter.to))
            );
          }
          const created = new Date(product.createdAt).getTime();
          const from = filter.value
            ? new Date(`${filter.value}T00:00:00`).getTime()
            : 0;
          const to = filter.to
            ? new Date(`${filter.to}T23:59:59.999`).getTime()
            : Number.POSITIVE_INFINITY;
          return created >= from && created <= to;
        }),
      )
      .sort((a, b) => {
        const multiplier = productSort.direction === "asc" ? 1 : -1;
        const key = productSort.key;
        let result = 0;
        if (key === "product")
          result = a.name.localeCompare(b.name, "vi", { sensitivity: "base" });
        else if (key === "sku")
          result = a.sku.localeCompare(b.sku, "vi", { sensitivity: "base" });
        else if (key === "category" || key === "brand")
          result = a[key].localeCompare(b[key], "vi", { sensitivity: "base" });
        else if (key === "tracking")
          result = a.tracking.localeCompare(b.tracking, "vi");
        else if (key === "status")
          result = Number(a.stock <= a.min) - Number(b.stock <= b.min);
        else if (key === "createdAt")
          result = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
        else result = a[key] - b[key];
        return result * multiplier || b.id - a.id;
      });
  }, [p.products, productFilters, productSort]);
  const activeFilterCount = PRODUCT_COLUMNS.filter((column) => {
    const filter = productFilters[column.key];
    return filter.value || filter.to;
  }).length;
  const updateProductFilter = (
    key: ProductColumnKey,
    field: keyof ProductFilterValue,
    value: string,
  ) =>
    setProductFilters((current) => ({
      ...current,
      [key]: { ...current[key], [field]: value },
    }));
  const sortLabels = (column: (typeof PRODUCT_COLUMNS)[number]) => {
    if (column.kind === "number") return ["Giá trị thấp đến cao", "Giá trị cao đến thấp"];
    if (column.kind === "date") return ["Cũ nhất trước", "Mới nhất trước"];
    return ["A đến Z", "Z đến A"];
  };
  const renderProductCell = (x: Product, key: ProductColumnKey) => {
    switch (key) {
      case "product":
        return (
          <div className="product-catalog-identity">
            <ProductImage
              imageKey={x.imageKey}
              alt={x.name}
              className="product-catalog-image"
              fallback={x.category === "Laptop" ? "▱" : "◇"}
            />
            <span>
              <b
                className="product-name-tooltip"
                title={x.name}
                aria-label={`Tên đầy đủ: ${x.name}`}
              >
                {x.name}
              </b>
              <small>{x.brand || x.category}</small>
            </span>
          </div>
        );
      case "sku":
        return x.sku;
      case "category":
        return x.category;
      case "brand":
        return x.brand || "—";
      case "tracking":
        return (
          <span className="tag">
            {x.tracking === "serial" ? "Theo serial" : "Theo số lượng"}
          </span>
        );
      case "cost":
        return money(x.cost);
      case "price":
        return money(x.price);
      case "stock":
        return (
          <>
            <b>{x.stock}</b> {x.unit}
          </>
        );
      case "status":
        return <Status value={x.stock <= x.min ? "pending" : "available"} />;
      case "createdAt":
        return formatDate(x.createdAt);
    }
  };
  return (
    <>
      <article className="panel page product-catalog-page">
        <div className="section-title product-list-title">
          <div>
            <h2>Danh sách sản phẩm</h2>
            <p>
              {activeFilterCount
                ? `${filteredProducts.length}/${p.data.products.length} mặt hàng · ${activeFilterCount} bộ lọc`
                : `${p.data.products.length} mặt hàng đang kinh doanh`}
            </p>
          </div>
          <div className="product-title-actions">
            <button
              className="product-settings-button"
              onClick={() =>
                setColumnSettingsDraft({
                  visible: [...columnSettings.visible],
                  filterable: [...columnSettings.filterable],
                })
              }
            >
              ⚙ Cài đặt cột
            </button>
            <button
              className="primary"
              onClick={() => {
                p.clearProductDraft();
                if (imagePreview?.startsWith("blob:")) URL.revokeObjectURL(imagePreview);
                setImagePreview(null);
                setForm({ ...freshProduct });
              }}
            >
              ＋ Thêm sản phẩm
            </button>
          </div>
        </div>
        <div className="product-table-toolbar">
          <span>
            ⇅ {productSort.key === "createdAt" && productSort.direction === "desc"
              ? "Mới khởi tạo trước"
              : `Đang sắp xếp: ${PRODUCT_COLUMNS.find((column) => column.key === productSort.key)?.label}`}
          </span>
          <label>
            <span>⌕</span>
            <select
              value={activeFilter || ""}
              onChange={(event) =>
                setActiveFilter(
                  (event.target.value || null) as ProductColumnKey | null,
                )
              }
            >
              <option value="">Chọn cột để lọc</option>
              {PRODUCT_COLUMNS.filter((column) =>
                columnSettings.filterable.includes(column.key),
              ).map((column) => (
                <option value={column.key} key={column.key}>
                  {column.label}
                </option>
              ))}
            </select>
          </label>
          {activeFilterCount > 0 && (
            <button
              type="button"
              onClick={() => {
                setProductFilters(emptyProductFilters());
                setActiveFilter(null);
              }}
            >
              Xóa tất cả bộ lọc
            </button>
          )}
        </div>
        {activeFilter && activeFilterDefinition && (
          <div className="product-filter-panel">
            <b>Lọc theo {activeFilterDefinition.label}</b>
            {activeFilterDefinition.kind === "select" ? (
              <select
                autoFocus
                value={productFilters[activeFilter].value}
                onChange={(event) =>
                  updateProductFilter(activeFilter, "value", event.target.value)
                }
              >
                <option value="">Tất cả</option>
                {selectOptions(activeFilter).map(([value, label]) => (
                  <option value={value} key={value}>
                    {label}
                  </option>
                ))}
              </select>
            ) : activeFilterDefinition.kind === "number" ? (
              <div className="product-filter-range">
                {activeFilter === "cost" || activeFilter === "price" ? (
                  <MoneyInput
                    autoFocus
                    placeholder="Từ"
                    allowEmpty
                    value={Number(productFilters[activeFilter].value) || 0}
                    ariaLabel={`Lọc ${activeFilterDefinition.label} từ`}
                    onValueChange={(value) => updateProductFilter(activeFilter, "value", value ? String(value) : "")}
                  />
                ) : <input
                  autoFocus
                  type="number"
                  min="0"
                  placeholder="Từ"
                  value={productFilters[activeFilter].value}
                  onChange={(event) =>
                    updateProductFilter(activeFilter, "value", event.target.value)
                  }
                />}
                <span>đến</span>
                {activeFilter === "cost" || activeFilter === "price" ? (
                  <MoneyInput
                    placeholder="Đến"
                    allowEmpty
                    value={Number(productFilters[activeFilter].to) || 0}
                    ariaLabel={`Lọc ${activeFilterDefinition.label} đến`}
                    onValueChange={(value) => updateProductFilter(activeFilter, "to", value ? String(value) : "")}
                  />
                ) : <input
                  type="number"
                  min="0"
                  placeholder="Đến"
                  value={productFilters[activeFilter].to}
                  onChange={(event) =>
                    updateProductFilter(activeFilter, "to", event.target.value)
                  }
                />}
              </div>
            ) : activeFilterDefinition.kind === "date" ? (
              <div className="product-filter-range">
                <input
                  autoFocus
                  type="date"
                  aria-label="Từ ngày"
                  value={productFilters[activeFilter].value}
                  onChange={(event) =>
                    updateProductFilter(activeFilter, "value", event.target.value)
                  }
                />
                <span>đến</span>
                <input
                  type="date"
                  aria-label="Đến ngày"
                  value={productFilters[activeFilter].to}
                  onChange={(event) =>
                    updateProductFilter(activeFilter, "to", event.target.value)
                  }
                />
              </div>
            ) : (
              <input
                autoFocus
                value={productFilters[activeFilter].value}
                onChange={(event) =>
                  updateProductFilter(activeFilter, "value", event.target.value)
                }
                placeholder={`Nhập ${activeFilterDefinition.label.toLocaleLowerCase("vi")}...`}
              />
            )}
            <button
              type="button"
              onClick={() => {
                setProductFilters((current) => ({
                  ...current,
                  [activeFilter]: { value: "", to: "" },
                }));
                setActiveFilter(null);
              }}
            >
              Xóa lọc cột này
            </button>
            <button
              className="product-filter-close"
              type="button"
              aria-label="Đóng bộ lọc"
              onClick={() => setActiveFilter(null)}
            >
              ×
            </button>
          </div>
        )}
        {activeSortMenu && activeSortDefinition && (
          <div className="product-sort-panel">
            <b>Sắp xếp {activeSortDefinition.label}</b>
            <div className="product-sort-options">
              {(["asc", "desc"] as const).map((direction, index) => (
                <button
                  type="button"
                  key={direction}
                  className={
                    productSort.key === activeSortMenu &&
                    productSort.direction === direction
                      ? "active"
                      : ""
                  }
                  onClick={() => {
                    setProductSort({ key: activeSortMenu, direction });
                    setActiveSortMenu(null);
                  }}
                >
                  {sortLabels(activeSortDefinition)[index]}
                </button>
              ))}
              {columnSettings.filterable.includes(activeSortMenu) && (
                <button
                  type="button"
                  onClick={() => {
                    setActiveFilter(activeSortMenu);
                    setActiveSortMenu(null);
                  }}
                >
                  Lọc chi tiết…
                </button>
              )}
            </div>
            <button
              className="product-sort-close"
              type="button"
              aria-label="Đóng menu sắp xếp"
              onClick={() => setActiveSortMenu(null)}
            >
              ×
            </button>
          </div>
        )}
        <div className="table product-catalog-table">
          <table>
            <colgroup>
              {visibleColumns.map((column) => (
                <col className={`product-col-${column.key}`} key={column.key} />
              ))}
              <col className="product-col-actions" />
            </colgroup>
            <thead>
              <tr>
                {visibleColumns.map((column) => (
                  <th key={column.key}>
                    <span className="product-column-heading">
                      {column.label}
                      {columnSettings.filterable.includes(column.key) && (
                        <button
                          type="button"
                          className={
                            productFilters[column.key].value ||
                            productFilters[column.key].to
                              ? "active"
                              : ""
                          }
                          title={`Sắp xếp hoặc lọc theo ${column.label}`}
                          aria-label={`Sắp xếp hoặc lọc theo ${column.label}`}
                          onClick={() => {
                            setActiveSortMenu((current) =>
                              current === column.key ? null : column.key,
                            );
                            setActiveFilter(null);
                          }}
                        >
                          {productSort.key === column.key
                            ? productSort.direction === "asc"
                              ? "↑"
                              : "↓"
                            : "⇅"}
                        </button>
                      )}
                    </span>
                  </th>
                ))}
                <th className="product-actions-heading">Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {filteredProducts.map((x) => (
                <tr key={x.id}>
                  {visibleColumns.map((column) => (
                    <td key={column.key}>{renderProductCell(x, column.key)}</td>
                  ))}
                  <td>
                    <div className="row-actions">
                      <button onClick={() => edit(x)}>Sửa</button>
                      <button
                        className="danger-link"
                        onClick={() => archive(x)}
                      >
                        Ngừng bán
                      </button>
                      <button
                        className="danger-link"
                        disabled={busy}
                        onClick={() => void remove(x)}
                      >
                        Xóa
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {!filteredProducts.length && (
                <tr>
                  <td
                    className="product-filter-empty"
                    colSpan={visibleColumns.length + 1}
                  >
                    Không có sản phẩm phù hợp với bộ lọc hiện tại.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </article>
      {columnSettingsDraft && (
        <Modal
          title="Cài đặt cột sản phẩm"
          onClose={() => setColumnSettingsDraft(null)}
          wide
          className="product-columns-modal"
        >
          <p className="product-columns-note">
            Chọn cột muốn hiển thị và những cột được phép dùng làm bộ lọc.
          </p>
          <div className="product-columns-grid product-columns-grid-head">
            <b>Thông tin sản phẩm</b>
            <b>Hiển thị</b>
            <b>Cho phép lọc</b>
          </div>
          <div className="product-columns-list">
            {PRODUCT_COLUMNS.map((column) => (
              <label className="product-columns-grid" key={column.key}>
                <span>{column.label}</span>
                <input
                  type="checkbox"
                  checked={columnSettingsDraft.visible.includes(column.key)}
                  onChange={(event) =>
                    setColumnSettingsDraft({
                      ...columnSettingsDraft,
                      visible: event.target.checked
                        ? [...columnSettingsDraft.visible, column.key]
                        : columnSettingsDraft.visible.filter(
                            (key) => key !== column.key,
                          ),
                    })
                  }
                />
                <input
                  type="checkbox"
                  checked={columnSettingsDraft.filterable.includes(column.key)}
                  onChange={(event) =>
                    setColumnSettingsDraft({
                      ...columnSettingsDraft,
                      filterable: event.target.checked
                        ? [...columnSettingsDraft.filterable, column.key]
                        : columnSettingsDraft.filterable.filter(
                            (key) => key !== column.key,
                          ),
                    })
                  }
                />
              </label>
            ))}
          </div>
          <div className="modal-actions product-columns-actions">
            <button
              type="button"
              onClick={() =>
                setColumnSettingsDraft({
                  visible: [...DEFAULT_PRODUCT_COLUMN_SETTINGS.visible],
                  filterable: [...DEFAULT_PRODUCT_COLUMN_SETTINGS.filterable],
                })
              }
            >
              Khôi phục mặc định
            </button>
            <button type="button" onClick={() => setColumnSettingsDraft(null)}>
              Thoát
            </button>
            <button
              className="primary"
              type="button"
              onClick={() => {
                if (!columnSettingsDraft.visible.length) {
                  p.notify("Cần chọn ít nhất một cột để hiển thị.");
                  return;
                }
                setColumnSettings(columnSettingsDraft);
                if (
                  activeFilter &&
                  !columnSettingsDraft.filterable.includes(activeFilter)
                )
                  setActiveFilter(null);
                setColumnSettingsDraft(null);
                p.notify("Đã lưu cài đặt cột sản phẩm.");
              }}
            >
              Lưu
            </button>
          </div>
        </Modal>
      )}
      {form && (
        <Modal
          title={form.id ? "Sửa sản phẩm" : "Thêm sản phẩm và nhập kho"}
          onClose={() => {
            if (imagePreview?.startsWith("blob:")) URL.revokeObjectURL(imagePreview);
            setImagePreview(null);
            setForm(null);
            p.clearProductDraft();
          }}
          wide
        >
          <div className="form-grid">
            <Field label="Ảnh minh họa">
              <div className="product-image-upload">
                {imagePreview ? (
                  <img className="product-form-image preview" src={imagePreview} alt="Ảnh xem trước" />
                ) : (
                  <ProductImage
                    imageKey={form.removeImage ? "" : form.imageKey}
                    alt={form.name || "Ảnh sản phẩm"}
                    className="product-form-image"
                  />
                )}
                <div>
                  <label className="image-file-button">
                    Chọn ảnh
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp,image/gif"
                      onChange={(event) => {
                        const file = event.target.files?.[0];
                        if (!file) return;
                        if (file.size > 5 * 1024 * 1024) {
                          p.notify("Ảnh tối đa 5 MB.");
                          event.currentTarget.value = "";
                          return;
                        }
                        if (imagePreview?.startsWith("blob:")) URL.revokeObjectURL(imagePreview);
                        setImagePreview(URL.createObjectURL(file));
                        setForm({ ...form, imageFile: file, removeImage: false });
                      }}
                    />
                  </label>
                  <small>JPG, PNG, WEBP hoặc GIF · tối đa 5 MB</small>
                  {(form.imageKey || form.imageFile) && !form.removeImage && (
                    <button
                      type="button"
                      className="image-remove-button"
                      onClick={() => {
                        if (imagePreview?.startsWith("blob:")) URL.revokeObjectURL(imagePreview);
                        setImagePreview(null);
                        setForm({ ...form, imageFile: undefined, removeImage: true });
                      }}
                    >
                      Bỏ ảnh
                    </button>
                  )}
                </div>
              </div>
            </Field>
            <Field label="Tên sản phẩm *">
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </Field>
            <Field label="SKU">
              <input
                value={form.sku}
                onChange={(e) => setForm({ ...form, sku: e.target.value })}
              />
            </Field>
            <Field label="Nhóm hàng">
              <div className="catalog-option-control">
                <select
                  value={form.category}
                  onChange={(e) =>
                    setForm({ ...form, category: e.target.value })
                  }
                  aria-label="Chọn nhóm hàng"
                >
                  <option value="" disabled>Chọn nhóm hàng</option>
                  {categoryOptions.map((name) => (
                    <option key={name} value={name}>{name}</option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => openAddOption("category")}
                  title="Thêm nhóm hàng mới"
                  aria-label="Thêm nhóm hàng mới"
                >
                  ＋
                </button>
              </div>
            </Field>
            <Field label="Thương hiệu">
              <div className="catalog-option-control">
                <select
                  value={form.brand}
                  onChange={(e) => setForm({ ...form, brand: e.target.value })}
                  aria-label="Chọn thương hiệu"
                >
                  <option value="">Chưa chọn thương hiệu</option>
                  {brandOptions.map((name) => (
                    <option key={name} value={name}>{name}</option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => openAddOption("brand")}
                  title="Thêm thương hiệu mới"
                  aria-label="Thêm thương hiệu mới"
                >
                  ＋
                </button>
              </div>
            </Field>
            <Field label="Đơn vị">
              <input
                value={form.unit}
                onChange={(e) => setForm({ ...form, unit: e.target.value })}
              />
            </Field>
            <Field label="Quản lý kho">
              <select
                disabled={Boolean(form.id)}
                value={form.tracking}
                onChange={(e) =>
                  setForm({
                    ...form,
                    tracking: e.target.value as "serial" | "quantity",
                  })
                }
              >
                <option value="serial">Theo serial</option>
                <option value="quantity">Theo số lượng</option>
              </select>
            </Field>
            <Field label="Tồn tối thiểu">
              <input
                type="number"
                value={form.min}
                onChange={(e) => setForm({ ...form, min: e.target.value })}
              />
            </Field>
            <Field label="Giá vốn">
              <MoneyInput value={Number(form.cost)} ariaLabel="Giá vốn sản phẩm" onValueChange={(cost) => setForm({ ...form, cost: String(cost) })} />
            </Field>
            <Field label="Giá bán">
              <MoneyInput value={Number(form.price)} ariaLabel="Giá bán sản phẩm" onValueChange={(price) => setForm({ ...form, price: String(price) })} />
            </Field>
            {!form.id &&
              (form.tracking === "quantity" ? (
                <Field label="Số lượng nhập">
                  <input
                    type="number"
                    value={form.stock}
                    onChange={(e) =>
                      setForm({ ...form, stock: e.target.value })
                    }
                  />
                </Field>
              ) : (
                <Field label="Danh sách serial" wide>
                  <textarea
                    value={form.serials}
                    onChange={(e) =>
                      setForm({ ...form, serials: e.target.value })
                    }
                    placeholder="Mỗi serial một dòng"
                  />
                </Field>
              ))}
            <Field label="Mô tả sản phẩm" wide>
              <textarea
                value={form.description}
                onChange={(e) =>
                  setForm({ ...form, description: e.target.value })
                }
              />
            </Field>
          </div>
          <div className={`people-modal-actions ${form.id ? "has-delete" : ""}`}>
            {form.id && (
              <button
                type="button"
                className="danger-button"
                disabled={busy}
                onClick={() =>
                  void remove({ id: form.id as number, name: form.name })
                }
              >
                Xóa sản phẩm
              </button>
            )}
            <SpinnerButton
              className="primary"
              busy={busy}
              disabled={!form.name.trim()}
              onClick={save}
            >
              Lưu sản phẩm
            </SpinnerButton>
          </div>
        </Modal>
      )}
      {addingOption && (
        <Modal
          title={`Thêm ${addingOption === "category" ? "nhóm hàng" : "thương hiệu"} mới`}
          onClose={() => {
            if (!savingOption) setAddingOption(null);
          }}
        >
          <Field
            label={addingOption === "category" ? "Tên nhóm hàng" : "Tên thương hiệu"}
          >
            <input
              autoFocus
              value={newOptionName}
              maxLength={80}
              placeholder={addingOption === "category" ? "Ví dụ: Máy tính để bàn" : "Ví dụ: Lenovo"}
              onChange={(e) => setNewOptionName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  void saveOption();
                }
              }}
            />
          </Field>
          <SpinnerButton
            className="primary modal-submit"
            busy={savingOption}
            disabled={!newOptionName.trim()}
            onClick={saveOption}
          >
            Lưu và chọn
          </SpinnerButton>
        </Modal>
      )}
    </>
  );
}

type InventoryTab = "stock" | "serial" | "movement";
type InventoryColumnKey =
  | "stockProduct"
  | "stockSku"
  | "stockCategory"
  | "stockBrand"
  | "stockUnit"
  | "stockTracking"
  | "stockCost"
  | "stockPrice"
  | "stockQuantity"
  | "stockMin"
  | "stockValue"
  | "serialNumber"
  | "serialProduct"
  | "serialSku"
  | "serialCategory"
  | "serialBrand"
  | "serialUnit"
  | "serialTracking"
  | "serialCost"
  | "serialPrice"
  | "serialStatus";
type InventoryColumn = {
  key: InventoryColumnKey;
  label: string;
  kind: "text" | "number" | "select";
};
type InventoryColumnSettings = {
  visible: InventoryColumnKey[];
  filterable: InventoryColumnKey[];
};
type InventorySort = { key: InventoryColumnKey; direction: "asc" | "desc" };
type InventoryFilter = { value: string; to: string };

const STOCK_COLUMNS: InventoryColumn[] = [
  { key: "stockProduct", label: "Sản phẩm", kind: "text" },
  { key: "stockSku", label: "SKU", kind: "text" },
  { key: "stockCategory", label: "Nhóm hàng", kind: "text" },
  { key: "stockBrand", label: "Thương hiệu", kind: "text" },
  { key: "stockUnit", label: "Đơn vị tính", kind: "text" },
  { key: "stockTracking", label: "Quản lý", kind: "text" },
  { key: "stockCost", label: "Giá nhập", kind: "number" },
  { key: "stockPrice", label: "Giá bán", kind: "number" },
  { key: "stockQuantity", label: "Tồn thực tế", kind: "number" },
  { key: "stockMin", label: "Tồn tối thiểu", kind: "number" },
  { key: "stockValue", label: "Giá trị tồn", kind: "number" },
];
const SERIAL_COLUMNS: InventoryColumn[] = [
  { key: "serialNumber", label: "Serial / IMEI", kind: "text" },
  { key: "serialProduct", label: "Sản phẩm", kind: "text" },
  { key: "serialSku", label: "SKU", kind: "text" },
  { key: "serialCategory", label: "Nhóm hàng", kind: "text" },
  { key: "serialBrand", label: "Thương hiệu", kind: "text" },
  { key: "serialUnit", label: "Đơn vị tính", kind: "text" },
  { key: "serialTracking", label: "Quản lý", kind: "text" },
  { key: "serialCost", label: "Giá nhập", kind: "number" },
  { key: "serialPrice", label: "Giá bán", kind: "number" },
  { key: "serialStatus", label: "Trạng thái", kind: "select" },
];
const defaultInventoryColumns = (columns: InventoryColumn[]): InventoryColumnSettings => ({
  visible: columns.map((column) => column.key),
  filterable: columns.map((column) => column.key),
});
const emptyInventoryFilters = () =>
  [...STOCK_COLUMNS, ...SERIAL_COLUMNS].reduce(
    (filters, column) => ({ ...filters, [column.key]: { value: "", to: "" } }),
    {} as Record<InventoryColumnKey, InventoryFilter>,
  );

export function Inventory(p: ViewProps) {
  const [product, setProduct] = useState<Product | null>(null);
  const [adjustment, setAdjustment] = useState(0);
  const [reason, setReason] = useState("");
  const [serials, setSerials] = useState("");
  const [tab, setTab] = useState<InventoryTab>("stock");
  const [stockColumns, setStockColumns] = useState<InventoryColumnSettings>(() =>
    defaultInventoryColumns(STOCK_COLUMNS),
  );
  const [serialColumns, setSerialColumns] = useState<InventoryColumnSettings>(() =>
    defaultInventoryColumns(SERIAL_COLUMNS),
  );
  const [columnsDraft, setColumnsDraft] = useState<{
    tab: "stock" | "serial";
    settings: InventoryColumnSettings;
  } | null>(null);
  const [activeFilter, setActiveFilter] = useState<InventoryColumnKey | null>(null);
  const [filters, setFilters] = useState(emptyInventoryFilters);
  const [stockSort, setStockSort] = useState<InventorySort>({
    key: "stockProduct",
    direction: "asc",
  });
  const [serialSort, setSerialSort] = useState<InventorySort>({
    key: "serialNumber",
    direction: "asc",
  });
  const currentColumns = tab === "stock" ? STOCK_COLUMNS : SERIAL_COLUMNS;
  const currentSettings = tab === "stock" ? stockColumns : serialColumns;
  const currentSort = tab === "stock" ? stockSort : serialSort;
  const visibleColumns = currentColumns.filter((column) =>
    currentSettings.visible.includes(column.key),
  );
  const activeFilterDefinition = currentColumns.find(
    (column) => column.key === activeFilter,
  );
  const activeFilterCount = currentColumns.filter((column) => {
    const filter = filters[column.key];
    return filter.value || filter.to;
  }).length;
  useEffect(() => {
    try {
      const saved = window.localStorage.getItem("tien-inventory-columns-v1");
      if (!saved) return;
      const parsed = JSON.parse(saved) as Partial<Record<"stock" | "serial", InventoryColumnSettings>>;
      const valid = (columns: InventoryColumn[], value?: InventoryColumnSettings) => {
        if (!value) return null;
        const keys = new Set(columns.map((column) => column.key));
        const visible = value.visible.filter((key) => keys.has(key));
        const filterable = value.filterable.filter((key) => keys.has(key));
        return visible.length ? { visible, filterable } : null;
      };
      const stock = valid(STOCK_COLUMNS, parsed.stock);
      const serial = valid(SERIAL_COLUMNS, parsed.serial);
      if (stock) setStockColumns(stock);
      if (serial) setSerialColumns(serial);
    } catch {
      // Keep defaults when a browser preference is no longer valid.
    }
  }, []);
  useEffect(() => {
    window.localStorage.setItem(
      "tien-inventory-columns-v1",
      JSON.stringify({ stock: stockColumns, serial: serialColumns }),
    );
  }, [stockColumns, serialColumns]);
  const updateFilter = (key: InventoryColumnKey, field: keyof InventoryFilter, value: string) =>
    setFilters((current) => ({ ...current, [key]: { ...current[key], [field]: value } }));
  const sortBy = (key: InventoryColumnKey) => {
    const setter = tab === "stock" ? setStockSort : setSerialSort;
    setter((current) => ({
      key,
      direction: current.key === key && current.direction === "asc" ? "desc" : "asc",
    }));
  };
  const textMatch = (source: string, query: string) =>
    source.toLocaleLowerCase("vi").includes(query.toLocaleLowerCase("vi"));
  const productById = useMemo(
    () => new Map(p.products.map((item) => [item.id, item])),
    [p.products],
  );
  const stockTextValue = (item: Product, key: InventoryColumnKey) => {
    if (key === "stockProduct") return `${item.name} ${item.category} ${item.brand}`;
    if (key === "stockSku") return item.sku;
    if (key === "stockCategory") return item.category;
    if (key === "stockBrand") return item.brand;
    if (key === "stockUnit") return item.unit;
    if (key === "stockTracking") return item.tracking === "serial" ? "Theo serial" : "Theo số lượng";
    return "";
  };
  const stockNumberValue = (item: Product, key: InventoryColumnKey) => {
    if (key === "stockCost") return item.cost;
    if (key === "stockPrice") return item.price;
    if (key === "stockQuantity") return item.stock;
    if (key === "stockMin") return item.min;
    return inventoryValue(item);
  };
  const serialTextValue = (item: (typeof p.data.serials)[number], key: InventoryColumnKey) => {
    const linkedProduct = productById.get(item.productId);
    if (key === "serialNumber") return item.serial;
    if (key === "serialProduct") return item.productName;
    if (key === "serialSku") return item.sku;
    if (key === "serialCategory") return linkedProduct?.category || "";
    if (key === "serialBrand") return linkedProduct?.brand || "";
    if (key === "serialUnit") return linkedProduct?.unit || "";
    if (key === "serialTracking") return linkedProduct?.tracking === "serial" ? "Theo serial" : linkedProduct ? "Theo số lượng" : "";
    return item.status;
  };
  const serialNumberValue = (item: (typeof p.data.serials)[number], key: InventoryColumnKey) => {
    const linkedProduct = productById.get(item.productId);
    return key === "serialCost" ? linkedProduct?.cost || 0 : linkedProduct?.price || 0;
  };
  const filteredStock = useMemo(() =>
    [...p.products]
      .filter((item) => STOCK_COLUMNS.every((column) => {
        const filter = filters[column.key];
        if (!filter.value && !filter.to) return true;
        if (column.kind === "text") return textMatch(stockTextValue(item, column.key), filter.value);
        const value = stockNumberValue(item, column.key);
        return (!filter.value || value >= Number(filter.value)) && (!filter.to || value <= Number(filter.to));
      }))
      .sort((a, b) => {
        const multiplier = stockSort.direction === "asc" ? 1 : -1;
        const result = STOCK_COLUMNS.find((column) => column.key === stockSort.key)?.kind === "text"
          ? stockTextValue(a, stockSort.key).localeCompare(stockTextValue(b, stockSort.key), "vi")
          : stockNumberValue(a, stockSort.key) - stockNumberValue(b, stockSort.key);
        return result * multiplier || b.id - a.id;
      }),
    [p.products, filters, stockSort],
  );
  const filteredSerials = useMemo(() =>
    [...p.data.serials]
      .filter((item) => SERIAL_COLUMNS.every((column) => {
        const filter = filters[column.key];
        if (!filter.value && !filter.to) return true;
        if (column.kind === "number") {
          const value = serialNumberValue(item, column.key);
          return (!filter.value || value >= Number(filter.value)) && (!filter.to || value <= Number(filter.to));
        }
        return column.kind === "select"
          ? item.status === filter.value
          : textMatch(serialTextValue(item, column.key), filter.value);
      }))
      .sort((a, b) => {
        const multiplier = serialSort.direction === "asc" ? 1 : -1;
        const column = SERIAL_COLUMNS.find((item) => item.key === serialSort.key);
        const result = column?.kind === "number"
          ? serialNumberValue(a, serialSort.key) - serialNumberValue(b, serialSort.key)
          : serialTextValue(a, serialSort.key).localeCompare(serialTextValue(b, serialSort.key), "vi");
        return result * multiplier || b.id - a.id;
      }),
    [p.data.serials, filters, serialSort, productById],
  );
  const adjust = async () => {
    if (!product) return;
    await p.api(
      {
        id: product.id,
        action: "adjust",
        adjustment,
        reason,
        serials: serials.split(/[,\n]/),
      },
      "/api/products",
      "PATCH",
    );
    setProduct(null);
    p.notify("Đã điều chỉnh và ghi nhận lịch sử kho.");
    await p.reload();
  };
  return (
    <>
      <div className="three">
        <Kpi
          icon="▣"
          label="Tổng tồn"
          value={String(p.data.products.reduce((s, x) => s + x.stock, 0))}
        />
        <Kpi
          icon="▱"
          label="Serial sẵn sàng"
          value={String(
            p.data.serials.filter((x) => x.status === "available").length,
          )}
          tone="green"
        />
        <Kpi
          icon="!"
          label="Cần nhập thêm"
          value={String(p.data.products.filter((x) => x.stock <= x.min).length)}
          tone="orange"
        />
      </div>
      <article className="panel page">
        <div className="chips tabs">
          {[
            ["stock", "Tồn kho"],
            ["serial", "Serial / IMEI"],
            ["movement", "Lịch sử kho"],
          ].map(([id, label]) => (
            <button
              key={id}
              className={tab === id ? "sel" : ""}
              onClick={() => setTab(id as typeof tab)}
            >
              {label}
            </button>
          ))}
        </div>
        {tab !== "movement" && (
          <div className="inventory-table-toolbar product-table-toolbar">
            <span>
              ⇅ Đang sắp xếp: {currentColumns.find((column) => column.key === currentSort.key)?.label}
            </span>
            <label>
              <span>⌕</span>
              <select
                value={activeFilter || ""}
                onChange={(event) => setActiveFilter((event.target.value || null) as InventoryColumnKey | null)}
              >
                <option value="">Chọn cột để lọc</option>
                {currentColumns.filter((column) => currentSettings.filterable.includes(column.key)).map((column) => (
                  <option value={column.key} key={column.key}>{column.label}</option>
                ))}
              </select>
            </label>
            {activeFilterCount > 0 && (
              <button type="button" onClick={() => { setFilters(emptyInventoryFilters()); setActiveFilter(null); }}>
                Xóa tất cả bộ lọc
              </button>
            )}
            <button
              className="product-settings-button"
              type="button"
              onClick={() => setColumnsDraft({
                tab,
                settings: { visible: [...currentSettings.visible], filterable: [...currentSettings.filterable] },
              })}
            >
              ⚙ Cài đặt cột
            </button>
          </div>
        )}
        {activeFilter && activeFilterDefinition && tab !== "movement" && (
          <div className="product-filter-panel">
            <b>Lọc theo {activeFilterDefinition.label}</b>
            {activeFilterDefinition.kind === "select" ? (
              <select autoFocus value={filters[activeFilter].value} onChange={(event) => updateFilter(activeFilter, "value", event.target.value)}>
                <option value="">Tất cả</option>
                <option value="available">Sẵn sàng</option>
                <option value="sold">Đã bán</option>
                <option value="warranty">Bảo hành</option>
              </select>
            ) : activeFilterDefinition.kind === "number" ? (
              <div className="product-filter-range">
                <input autoFocus type="number" min="0" placeholder="Từ" value={filters[activeFilter].value} onChange={(event) => updateFilter(activeFilter, "value", event.target.value)} />
                <span>đến</span>
                <input type="number" min="0" placeholder="Đến" value={filters[activeFilter].to} onChange={(event) => updateFilter(activeFilter, "to", event.target.value)} />
              </div>
            ) : (
              <input autoFocus value={filters[activeFilter].value} onChange={(event) => updateFilter(activeFilter, "value", event.target.value)} placeholder={`Nhập ${activeFilterDefinition.label.toLocaleLowerCase("vi")}...`} />
            )}
            <button type="button" onClick={() => { setFilters((current) => ({ ...current, [activeFilter]: { value: "", to: "" } })); setActiveFilter(null); }}>
              Xóa lọc cột này
            </button>
            <button className="product-filter-close" type="button" aria-label="Đóng bộ lọc" onClick={() => setActiveFilter(null)}>×</button>
          </div>
        )}
        {tab === "stock" && (
          <div className="table inventory-configurable-table">
            <table className="inventory-stock-table">
              <thead>
                <tr>
                  {visibleColumns.map((column) => (
                    <th key={column.key}>
                      <span className="product-column-heading">
                        {column.label}
                        <button type="button" aria-label={`Sắp xếp theo ${column.label}`} onClick={() => sortBy(column.key)}>
                          {stockSort.key === column.key ? stockSort.direction === "asc" ? "↑" : "↓" : "⇅"}
                        </button>
                      </span>
                    </th>
                  ))}
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {filteredStock.map((x) => (
                  <tr key={x.id}>
                    {visibleColumns.map((column) => (
                      <td key={column.key}>
                        {column.key === "stockProduct" ? <span className="product-name-cell" title={x.name}><b>{x.name}</b></span>
                          : column.key === "stockSku" ? x.sku
                          : column.key === "stockCategory" ? x.category || "—"
                          : column.key === "stockBrand" ? x.brand || "—"
                          : column.key === "stockUnit" ? x.unit || "—"
                          : column.key === "stockTracking" ? x.tracking === "serial" ? "Theo serial" : "Theo số lượng"
                          : column.key === "stockCost" ? money(x.cost)
                          : column.key === "stockPrice" ? money(x.price)
                          : column.key === "stockQuantity" ? <>{x.stock} {x.unit}</>
                          : column.key === "stockMin" ? x.min
                          : money(inventoryValue(x))}
                      </td>
                    ))}
                    <td>
                      <button
                        className="link-button"
                        onClick={() => {
                          setProduct(x);
                          setAdjustment(0);
                          setReason("");
                          setSerials("");
                        }}
                      >
                        Điều chỉnh
                      </button>
                    </td>
                  </tr>
                ))}
                {!filteredStock.length && <tr><td colSpan={visibleColumns.length + 1} className="product-filter-empty">Không có sản phẩm phù hợp.</td></tr>}
              </tbody>
            </table>
          </div>
        )}
        {tab === "serial" && (
          <div className="table inventory-configurable-table">
            <table className="inventory-serial-table">
              <thead>
                <tr>
                  {visibleColumns.map((column) => (
                    <th key={column.key}>
                      <span className="product-column-heading">
                        {column.label}
                        <button type="button" aria-label={`Sắp xếp theo ${column.label}`} onClick={() => sortBy(column.key)}>
                          {serialSort.key === column.key ? serialSort.direction === "asc" ? "↑" : "↓" : "⇅"}
                        </button>
                      </span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filteredSerials.map((x) => (
                  <tr key={x.id}>
                    {visibleColumns.map((column) => (
                      <td key={column.key}>
                        {column.key === "serialNumber" ? <span className="link">{x.serial}</span>
                          : column.key === "serialProduct" ? <span className="product-name-cell" title={x.productName}><b>{x.productName}</b></span>
                          : column.key === "serialSku" ? x.sku
                          : column.key === "serialCategory" ? productById.get(x.productId)?.category || "—"
                          : column.key === "serialBrand" ? productById.get(x.productId)?.brand || "—"
                          : column.key === "serialUnit" ? productById.get(x.productId)?.unit || "—"
                          : column.key === "serialTracking" ? productById.get(x.productId)?.tracking === "serial" ? "Theo serial" : "Theo số lượng"
                          : column.key === "serialCost" ? money(productById.get(x.productId)?.cost || 0)
                          : column.key === "serialPrice" ? money(productById.get(x.productId)?.price || 0)
                          : <Status value={x.status} />}
                      </td>
                    ))}
                  </tr>
                ))}
                {!filteredSerials.length && <tr><td colSpan={visibleColumns.length} className="product-filter-empty">Không có serial phù hợp.</td></tr>}
              </tbody>
            </table>
          </div>
        )}
        {tab === "movement" && (
          <div className="table">
            <table className="inventory-movement-table">
              <thead>
                <tr>
                  <th>Thời gian</th>
                  <th>Sản phẩm</th>
                  <th>Loại</th>
                  <th>Số lượng</th>
                  <th>Tham chiếu</th>
                  <th>Ghi chú</th>
                </tr>
              </thead>
              <tbody>
                {p.data.inventoryMovements.map((x) => (
                  <tr key={x.id}>
                    <td>{formatDate(x.createdAt)}</td>
                    <td className="product-name-cell" title={x.productName}>
                      <b>{x.productName}</b>
                    </td>
                    <td>
                      {
                        (
                          {
                            purchase: "Nhập hàng",
                            sale: "Bán hàng",
                            return: "Trả hàng",
                            adjustment: "Điều chỉnh",
                          } as Record<string, string>
                        )[x.type]
                      }
                    </td>
                    <td className={x.quantity > 0 ? "green" : "red"}>
                      {x.quantity > 0 ? "+" : ""}
                      {x.quantity}
                    </td>
                    <td>{x.reference}</td>
                    <td>{x.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </article>
      {columnsDraft && (
        <Modal
          title={`Cài đặt cột · ${columnsDraft.tab === "stock" ? "Tồn kho" : "Serial / IMEI"}`}
          onClose={() => setColumnsDraft(null)}
          wide
          className="product-columns-modal"
        >
          <p className="product-columns-note">
            Chọn cột hiển thị và các cột được phép dùng để lọc.
          </p>
          <div className="product-columns-grid product-columns-grid-head">
            <b>Thông tin</b><b>Hiển thị</b><b>Cho phép lọc</b>
          </div>
          <div className="product-columns-list">
            {(columnsDraft.tab === "stock" ? STOCK_COLUMNS : SERIAL_COLUMNS).map((column) => (
              <label className="product-columns-grid" key={column.key}>
                <span>{column.label}</span>
                <input
                  type="checkbox"
                  checked={columnsDraft.settings.visible.includes(column.key)}
                  onChange={(event) => setColumnsDraft((current) => current && ({
                    ...current,
                    settings: {
                      ...current.settings,
                      visible: event.target.checked
                        ? [...current.settings.visible, column.key]
                        : current.settings.visible.filter((key) => key !== column.key),
                    },
                  }))}
                />
                <input
                  type="checkbox"
                  checked={columnsDraft.settings.filterable.includes(column.key)}
                  onChange={(event) => setColumnsDraft((current) => current && ({
                    ...current,
                    settings: {
                      ...current.settings,
                      filterable: event.target.checked
                        ? [...current.settings.filterable, column.key]
                        : current.settings.filterable.filter((key) => key !== column.key),
                    },
                  }))}
                />
              </label>
            ))}
          </div>
          <div className="people-modal-actions product-columns-actions">
            <button type="button" onClick={() => setColumnsDraft(null)}>Hủy</button>
            <button
              type="button"
              className="primary"
              disabled={!columnsDraft.settings.visible.length}
              onClick={() => {
                if (columnsDraft.tab === "stock") setStockColumns(columnsDraft.settings);
                else setSerialColumns(columnsDraft.settings);
                setActiveFilter(null);
                setColumnsDraft(null);
              }}
            >
              Lưu cài đặt
            </button>
          </div>
        </Modal>
      )}
      {product && (
        <Modal
          title={`Điều chỉnh tồn: ${product.name}`}
          onClose={() => setProduct(null)}
        >
          <Field label="Tăng / giảm số lượng">
            <input
              type="number"
              value={adjustment}
              onChange={(e) => setAdjustment(Number(e.target.value))}
            />
          </Field>
          {product.tracking === "serial" && adjustment > 0 && (
            <Field label={`Nhập đúng ${adjustment} serial`}>
              <textarea
                value={serials}
                onChange={(e) => setSerials(e.target.value)}
                placeholder="Mỗi serial một dòng"
              />
            </Field>
          )}
          <Field label="Lý do">
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Kiểm kê thực tế, hàng hỏng..."
            />
          </Field>
          <button className="primary modal-submit" onClick={adjust}>
            Lưu điều chỉnh
          </button>
        </Modal>
      )}
    </>
  );
}

type OrderEditLine = {
  productId: number;
  productName: string;
  sku: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  note: string;
  serials: string[];
};

const parseSerials = (value: string) => {
  try {
    return JSON.parse(value || "[]") as string[];
  } catch {
    return [];
  }
};

const toDateTimeLocal = (value: string) => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 16);
};

function OrderEditor({
  p,
  order,
  onClose,
}: {
  p: ViewProps;
  order: Order;
  onClose: () => void;
}) {
  const originalItems = p.data.orderItems.filter(
    (item) => item.orderId === order.id,
  );
  const existingCustomer =
    p.data.customers.find((customer) => customer.id === order.customerId) || null;
  const [customerId, setCustomerId] = useState(existingCustomer?.id || "");
  const [customer, setCustomer] = useState({
    name: existingCustomer?.name || order.customerName,
    phone: existingCustomer?.phone || "",
    email: existingCustomer?.email || "",
    address: existingCustomer?.address || order.shippingAddress || "",
  });
  const [channel, setChannel] = useState(order.channel === "online" ? "online" : "pos");
  const [createdAt, setCreatedAt] = useState(toDateTimeLocal(order.createdAt));
  const [shippingAddress, setShippingAddress] = useState(order.shippingAddress || "");
  const [note, setNote] = useState(order.note || "");
  const [productQuery, setProductQuery] = useState("");
  const [productResultsOpen, setProductResultsOpen] = useState(false);
  const [multiSelect, setMultiSelect] = useState(false);
  const [selectedProductIds, setSelectedProductIds] = useState<number[]>([]);
  const productSearchRef = useRef<HTMLDivElement>(null);
  const [busy, setBusy] = useState(false);
  const [lines, setLines] = useState<OrderEditLine[]>(() =>
    originalItems.map((item) => ({
      productId: item.productId,
      productName: item.productName,
      sku: item.sku,
      quantity: item.quantity,
      unitPrice: item.unitPrice,
      discount: item.discount,
      note: item.note,
      serials: parseSerials(item.serialsJson),
    })),
  );
  const oldQuantity = (productId: number) =>
    originalItems
      .filter((item) => item.productId === productId)
      .reduce((sum, item) => sum + item.quantity, 0);
  const maxQuantity = (productId: number) => {
    const product = p.data.products.find((item) => item.id === productId);
    if (
      product?.tracking === "quantity" &&
      p.data.settings.allowNegativeStock
    )
      return Number.MAX_SAFE_INTEGER;
    return Math.max(0, (product?.stock || 0) + oldQuantity(productId));
  };
  const maxQuantityLabel = (product: Product) =>
    product.tracking === "quantity" && p.data.settings.allowNegativeStock
      ? "Cho phép bán âm"
      : String(maxQuantity(product.id));
  const serialOptions = (productId: number) =>
    p.data.serials.filter(
      (serial) =>
        serial.productId === productId &&
        (serial.status === "available" || serial.orderId === order.id),
    );
  const subtotal = lines.reduce(
    (sum, line) => sum + line.unitPrice * line.quantity,
    0,
  );
  const discount = lines.reduce(
    (sum, line) =>
      sum + Math.min(line.discount, line.unitPrice * line.quantity),
    0,
  );
  const total = Math.max(0, subtotal - discount);
  const normalizedQuery = productQuery.trim().toLowerCase();
  const productMatches = p.data.products
    .filter(
      (product) =>
        product.active &&
        (!normalizedQuery ||
          `${product.name} ${product.sku} ${product.brand}`
            .toLowerCase()
            .includes(normalizedQuery)),
    )
    .sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime() ||
        b.id - a.id,
    );

  useEffect(() => {
    const closeProductResults = (event: PointerEvent) => {
      if (!productSearchRef.current?.contains(event.target as Node)) {
        setProductResultsOpen(false);
      }
    };
    document.addEventListener("pointerdown", closeProductResults);
    return () => document.removeEventListener("pointerdown", closeProductResults);
  }, []);

  const chooseCustomer = (id: string) => {
    setCustomerId(id);
    const selectedCustomer = p.data.customers.find((item) => item.id === id);
    if (!selectedCustomer) return;
    setCustomer({
      name: selectedCustomer.name,
      phone: selectedCustomer.phone,
      email: selectedCustomer.email,
      address: selectedCustomer.address,
    });
    if (!shippingAddress) setShippingAddress(selectedCustomer.address);
  };
  const addProduct = (product: Product) => {
    setLines((current) => {
      const existing = current.find((line) => line.productId === product.id);
      if (existing)
        return current.map((line) =>
          line.productId === product.id
            ? {
                ...line,
                quantity: Math.min(
                  maxQuantity(product.id),
                  line.quantity + 1,
                ),
              }
            : line,
        );
      if (!maxQuantity(product.id)) return current;
      return [
        ...current,
        {
          productId: product.id,
          productName: product.name,
          sku: product.sku,
          quantity: 1,
          unitPrice: product.price,
          discount: 0,
          note: "",
          serials: [],
        },
      ];
    });
    // Each selection is a separate search action.  Close the suggestions so
    // the user deliberately reopens the search before choosing another item.
    setProductQuery("");
    setProductResultsOpen(false);
  };
  const toggleSelectedProduct = (productId: number) => {
    setSelectedProductIds((current) => current.includes(productId)
      ? current.filter((id) => id !== productId)
      : [...current, productId]);
  };
  const addSelectedProducts = () => {
    selectedProductIds.forEach((id) => {
      const product = p.data.products.find((item) => item.id === id);
      if (product && maxQuantity(product.id)) addProduct(product);
    });
    setSelectedProductIds([]);
    setMultiSelect(false);
    setProductQuery("");
    setProductResultsOpen(false);
  };
  const updateLine = (productId: number, changes: Partial<OrderEditLine>) =>
    setLines((current) =>
      current.map((line) => {
        if (line.productId !== productId) return line;
        const next = { ...line, ...changes };
        next.quantity = Math.max(
          1,
          Math.min(maxQuantity(productId), Math.round(next.quantity || 1)),
        );
        next.unitPrice = Math.max(0, Math.round(next.unitPrice || 0));
        next.discount = Math.min(
          next.unitPrice * next.quantity,
          Math.max(0, Math.round(next.discount || 0)),
        );
        next.serials = next.serials.slice(0, next.quantity);
        return next;
      }),
    );
  const selectSerial = (productId: number, index: number, value: string) =>
    setLines((current) =>
      current.map((line) => {
        if (line.productId !== productId) return line;
        const serials = [...line.serials];
        serials[index] = value;
        return { ...line, serials };
      }),
    );
  const stockIsValid = () =>
    lines.every((line) => {
      const product = p.data.products.find((item) => item.id === line.productId);
      return (
        line.quantity <= maxQuantity(line.productId) &&
        (product?.tracking !== "serial" ||
          (line.serials.length === line.quantity &&
            line.serials.every(Boolean) &&
            new Set(line.serials).size === line.quantity))
      );
    });
  const checkStock = () => {
    p.notify(
      stockIsValid()
        ? "Tồn kho và serial của đơn hàng đang hợp lệ."
        : "Có sản phẩm thiếu tồn kho hoặc chưa chọn đủ serial.",
    );
  };
  const save = async () => {
    if (!customerId) {
      p.notify("Vui lòng chọn khách hàng trước khi lưu đơn bán.");
      return;
    }
    if (!lines.length) {
      p.notify("Đơn hàng phải có ít nhất một sản phẩm.");
      return;
    }
    if (!stockIsValid()) {
      p.notify("Vui lòng kiểm tra số lượng và chọn đủ serial trước khi lưu.");
      return;
    }
    if (total < order.paid) {
      p.notify("Tổng tiền mới không được thấp hơn số tiền khách đã trả.");
      return;
    }
    setBusy(true);
    try {
      await p.api(
        {
          action: "edit",
          id: order.id,
          customerId,
          customer,
          channel,
          createdAt: createdAt
            ? new Date(createdAt).toISOString()
            : order.createdAt,
          shippingAddress,
          note,
          items: lines.map((line) => ({
            productId: line.productId,
            quantity: line.quantity,
            serials: line.serials,
            unitPrice: line.unitPrice,
            discount: line.discount,
            note: line.note,
          })),
        },
        "/api/orders",
        "PATCH",
      );
      await p.reload();
      p.notify(`Đã lưu thay đổi cho đơn ${order.code}.`);
      onClose();
    } finally {
      setBusy(false);
    }
  };
  useEffect(() => {
    const handleShortcut = (event: KeyboardEvent) => {
      if (event.key !== "F1") return;
      event.preventDefault();
      void save();
    };
    window.addEventListener("keydown", handleShortcut);
    return () => window.removeEventListener("keydown", handleShortcut);
  });

  return (
    <article className="order-editor-page">
      <div className="order-editor-toolbar">
        <button className="editor-back" type="button" onClick={onClose}>
          ‹ Quay lại chi tiết đơn hàng
        </button>
        <div>
          <button className="secondary" type="button" onClick={onClose}>
            Hủy
          </button>
          <SpinnerButton className="primary" busy={busy} onClick={save}>
            Lưu thay đổi (F1)
          </SpinnerButton>
        </div>
      </div>

      <div className="order-editor-heading">
        <div>
          <span>CHỈNH SỬA ĐƠN HÀNG</span>
          <h2>{order.code}</h2>
        </div>
        <div className="order-stage-line" aria-label="Tiến trình đơn hàng">
          {["Đặt hàng", "Duyệt", "Đóng gói", "Xuất kho", "Hoàn thành"].map(
            (stage, index) => (
              <div key={stage} className={index < 4 || order.paid >= total ? "done" : ""}>
                <i>✓</i>
                <b>{stage}</b>
                <small>{index === 4 && order.paid < total ? "Chờ thanh toán đủ" : formatDate(order.createdAt)}</small>
              </div>
            ),
          )}
        </div>
      </div>

      <div className="order-editor-top-grid">
        <section className="editor-card customer-editor-card">
          <h3>Thông tin khách hàng</h3>
          <div className="editor-form-grid">
            <Field label="Chọn khách hàng">
              <select value={customerId} onChange={(event) => chooseCustomer(event.target.value)}>
                <option value="">Chọn khách hàng bắt buộc</option>
                {p.data.customers.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name} - {item.phone}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Tên khách hàng">
              <input value={customer.name} readOnly />
            </Field>
            <Field label="Số điện thoại">
              <input value={customer.phone} readOnly />
            </Field>
            <Field label="Email">
              <input type="email" value={customer.email} readOnly />
            </Field>
            <Field label="Địa chỉ giao hàng" wide>
              <input value={shippingAddress} onChange={(event) => setShippingAddress(event.target.value)} placeholder="Nhập địa chỉ giao hàng" />
            </Field>
          </div>
        </section>
        <section className="editor-card order-info-card">
          <h3>Thông tin đơn hàng</h3>
          <Field label="Kênh bán">
            <select value={channel} onChange={(event) => setChannel(event.target.value)}>
              <option value="pos">Bán tại cửa hàng</option>
              <option value="online">Đơn hàng online</option>
            </select>
          </Field>
          <Field label="Ngày bán">
            <input type="datetime-local" value={createdAt} onChange={(event) => setCreatedAt(event.target.value)} />
          </Field>
          <div className="editor-payment-summary">
            <span>Đã thanh toán</span>
            <b>{money(order.paid)}</b>
            <small>Còn phải trả {money(Math.max(0, total - order.paid))}</small>
          </div>
        </section>
      </div>

      <section className="editor-card order-products-editor">
        <div className="editor-card-heading">
          <div>
            <h3>Thông tin sản phẩm</h3>
            <small>Thêm, xóa hoặc thay đổi hàng xuất trong đơn</small>
          </div>
          <div className="editor-heading-actions">
            <button
              type="button"
              className={multiSelect ? "active" : ""}
              onClick={() => {
                setMultiSelect((value) => !value);
                setSelectedProductIds([]);
              }}
            >
              Chọn nhiều
            </button>
            <button type="button" onClick={checkStock}>Kiểm tra tồn kho</button>
          </div>
        </div>
        <div ref={productSearchRef}>
        <label className="editor-product-search">
          <span>⌕</span>
          <input
            value={productQuery}
            onFocus={() => setProductResultsOpen(true)}
            onChange={(event) => {
              setProductQuery(event.target.value);
              setProductResultsOpen(true);
            }}
            onKeyDown={(event) => {
              if (event.key === "Escape") setProductResultsOpen(false);
            }}
            placeholder="Tìm tên sản phẩm, SKU hoặc thương hiệu để thêm vào đơn..."
            aria-label="Tìm và chọn sản phẩm cho đơn hàng"
            aria-expanded={productResultsOpen}
            aria-controls="editor-product-results"
            autoComplete="off"
          />
          {productQuery && <button type="button" onClick={() => setProductQuery("")}>×</button>}
        </label>
        {productResultsOpen && (
          <div className="editor-product-results" id="editor-product-results">
            <button
              type="button"
              className="product-search-create"
              onClick={() => p.openProductForm(productQuery.trim())}
            >
              <i aria-hidden="true">＋</i>
              <span>
                <b>Thêm mới sản phẩm</b>
                <small>Tạo sản phẩm “{productQuery.trim()}” nếu chưa có</small>
              </span>
            </button>
            {productMatches.map((product) => (
              <button className="product-search-row" type="button" key={product.id} onClick={() => multiSelect ? toggleSelectedProduct(product.id) : addProduct(product)} disabled={!maxQuantity(product.id)}>
                {multiSelect && <input type="checkbox" tabIndex={-1} readOnly checked={selectedProductIds.includes(product.id)} />}
                <i className="product-search-thumb" aria-hidden="true">▧</i>
                <span className="product-search-main">
                  <b>{product.name}</b>
                  <small>{product.sku} · {product.unit || "Chiếc"}{product.brand ? ` · ${product.brand}` : ""}</small>
                </span>
                <span className="product-search-value">
                  <strong>{money(product.price)}</strong>
                  <small>Tồn: {product.stock} | Có thể bán: {maxQuantityLabel(product)}</small>
                </span>
              </button>
            ))}
            {!productMatches.length && <p>Không tìm thấy sản phẩm phù hợp.</p>}
            {multiSelect && productMatches.length > 0 && (
              <div className="product-multi-actions">
                <span>Đã chọn {selectedProductIds.length} sản phẩm</span>
                <button type="button" disabled={!selectedProductIds.length} onClick={addSelectedProducts}>Thêm vào đơn</button>
              </div>
            )}
          </div>
        )}
        </div>
        <div className="editor-lines-wrap">
          <table className="editor-lines-table">
            <thead>
              <tr><th>Sản phẩm</th><th>Serial</th><th>Số lượng</th><th>Đơn giá</th><th>Chiết khấu</th><th>Thành tiền</th><th /></tr>
            </thead>
            <tbody>
              {lines.map((line) => {
                const product = p.data.products.find((item) => item.id === line.productId);
                return (
                  <tr key={line.productId}>
                    <td className="product-name-cell" title={line.productName}>
                      <b>{line.productName}</b>
                      <small>{line.sku}</small>
                      <input className="editor-line-note" value={line.note} onChange={(event) => updateLine(line.productId, { note: event.target.value })} placeholder="Ghi chú sản phẩm" />
                    </td>
                    <td className="editor-serial-cell">
                      {product?.tracking === "serial" ? Array.from({ length: line.quantity }, (_, index) => (
                        <select key={index} value={line.serials[index] || ""} onChange={(event) => selectSerial(line.productId, index, event.target.value)}>
                          <option value="">Chọn serial #{index + 1}</option>
                          {serialOptions(line.productId).map((serial) => (
                            <option key={serial.id} value={serial.serial} disabled={line.serials.some((chosen, chosenIndex) => chosenIndex !== index && chosen === serial.serial)}>
                              {serial.serial}
                            </option>
                          ))}
                        </select>
                      )) : <small>Không quản lý serial</small>}
                    </td>
                    <td><input type="number" min="1" max={maxQuantity(line.productId)} value={line.quantity} onChange={(event) => updateLine(line.productId, { quantity: Number(event.target.value) })} /></td>
                    <td><MoneyInput value={line.unitPrice} ariaLabel={`Đơn giá ${line.productName}`} onValueChange={(unitPrice) => updateLine(line.productId, { unitPrice })} /></td>
                    <td><MoneyInput max={line.unitPrice * line.quantity} value={line.discount} ariaLabel={`Chiết khấu ${line.productName}`} onValueChange={(discount) => updateLine(line.productId, { discount })} /></td>
                    <td><b>{money(line.unitPrice * line.quantity - line.discount)}</b></td>
                    <td><button className="editor-remove-line" type="button" onClick={() => setLines((current) => current.filter((item) => item.productId !== line.productId))}>×</button></td>
                  </tr>
                );
              })}
              {!lines.length && <tr><td colSpan={7}><div className="mini-empty">Chưa có sản phẩm trong đơn</div></td></tr>}
            </tbody>
          </table>
        </div>
        <div className="editor-order-footer">
          <Field label="Ghi chú đơn hàng">
            <textarea value={note} onChange={(event) => setNote(event.target.value)} placeholder="VD: Hàng tặng gói riêng" />
          </Field>
          <div className="editor-totals">
            <p><span>Tổng tiền ({lines.reduce((sum, line) => sum + line.quantity, 0)} sản phẩm)</span><b>{money(subtotal)}</b></p>
            <p><span>Chiết khấu</span><b>− {money(discount)}</b></p>
            <p className="payable"><span>Khách phải trả</span><b>{money(total)}</b></p>
            <p><span>Khách đã trả</span><b>{money(order.paid)}</b></p>
            <p className="remaining"><span>Còn phải trả</span><b>{money(Math.max(0, total - order.paid))}</b></p>
          </div>
        </div>
      </section>

      <div className="order-editor-bottom-actions">
        <button className="secondary" type="button" onClick={onClose}>Hủy</button>
        <SpinnerButton className="primary" busy={busy} onClick={save}>Lưu thay đổi (F1)</SpinnerButton>
      </div>
    </article>
  );
}

const escapePrintHtml = (value: unknown) => String(value ?? "")
  .replaceAll("&", "&amp;")
  .replaceAll("<", "&lt;")
  .replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;")
  .replaceAll("'", "&#039;");

const printNumber = (value: number) => new Intl.NumberFormat("vi-VN").format(Math.max(0, Math.round(value || 0)));

const vietnameseNumber = (value: number) => {
  const digits = ["không", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín"];
  const readTriple = (number: number, full = false) => {
    const hundred = Math.floor(number / 100);
    const ten = Math.floor((number % 100) / 10);
    const unit = number % 10;
    const words: string[] = [];
    if (full || hundred) words.push(`${digits[hundred]} trăm`);
    if (ten > 1) words.push(`${digits[ten]} mươi`);
    else if (ten === 1) words.push("mười");
    else if (unit && (full || hundred)) words.push("lẻ");
    if (unit) words.push(ten > 1 && unit === 1 ? "mốt" : ten > 0 && unit === 5 ? "lăm" : digits[unit]);
    return words.join(" ");
  };
  const amount = Math.max(0, Math.round(value || 0));
  if (!amount) return "Không đồng";
  const groups = ["", "nghìn", "triệu", "tỷ"];
  const triples: number[] = [];
  let rest = amount;
  while (rest) { triples.push(rest % 1000); rest = Math.floor(rest / 1000); }
  const text = triples.map((triple, index) => triple ? `${readTriple(triple, index < triples.length - 1 && triple < 100)} ${groups[index]}`.trim() : "").filter(Boolean).reverse().join(" ");
  return `${text.charAt(0).toUpperCase()}${text.slice(1)} đồng`;
};

function printOrderA4(
  p: ViewProps,
  order: Order,
  options: {
    popup?: Window | null;
    items?: OrderItem[];
    customer?: Customer | null;
  } = {},
) {
  const popup = options.popup ?? window.open("", "_blank", "width=900,height=1100");
  if (!popup) { p.notify("Trình duyệt đang chặn cửa sổ in. Hãy cho phép pop-up rồi thử lại."); return; }
  popup.opener = null;
  popup.document.open();
  const customer = options.customer ?? p.data.customers.find((item) => item.id === order.customerId) ?? p.data.customers.find((item) => item.name === order.customerName);
  const items = options.items ?? p.data.orderItems.filter((item) => item.orderId === order.id);
  const settings = p.data.settings;
  const rows = items.map((item, index) => {
    let serials: string[] = [];
    try { serials = JSON.parse(item.serialsJson || "[]"); } catch { serials = []; }
    const total = item.unitPrice * item.quantity - item.discount;
    return `<tr><td>${index + 1}</td><td>${escapePrintHtml(item.sku)}</td><td class="product"><b>${escapePrintHtml(item.productName)}</b></td><td class="serial">${escapePrintHtml(serials.join(", ") || "—")}</td><td class="warranty">${escapePrintHtml(item.note || "—")}</td><td>${item.quantity}</td><td class="number">${printNumber(item.unitPrice)}</td><td class="number">${printNumber(total)}</td></tr>`;
  }).join("") || "<tr><td colspan=\"8\">Chưa có sản phẩm</td></tr>";
  const created = new Date(order.createdAt);
  const date = Number.isNaN(created.getTime()) ? "—" : new Intl.DateTimeFormat("vi-VN", { day: "2-digit", month: "2-digit", year: "numeric" }).format(created);
  const totalQuantity = items.reduce((sum, item) => sum + item.quantity, 0);
  const paymentDue = Math.max(0, order.total - order.paid);
  popup.document.write(`<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>${escapePrintHtml(order.code)}</title><style>
    @page{size:A4 portrait;margin:10mm 11mm 12mm}*{box-sizing:border-box}html,body{margin:0;padding:0;color:#111;font-family:"Times New Roman",serif;font-size:13px}.page{width:100%;max-width:188mm;margin:0 auto}.top{display:grid;grid-template-columns:1fr 1fr;gap:28px;padding-bottom:14px;border-bottom:1px solid #777}.store b{font-size:15px}.store p,.order-meta p{margin:3px 0;line-height:1.35}.order-meta{text-align:right}.order-meta strong{font-size:14px}.title{text-align:center;font-size:22px;font-weight:700;margin:20px 0 28px;text-transform:uppercase}.customer{display:grid;grid-template-columns:112px 1fr;gap:8px 4px;margin-bottom:24px}.customer b{font-weight:700}.customer span{min-height:18px}table{width:100%;border-collapse:collapse;font-size:12px;table-layout:fixed}th,td{border:1px solid #777;padding:7px 5px;vertical-align:middle;overflow-wrap:anywhere}th{text-align:center;font-weight:700}td{text-align:center}.product{text-align:left;min-width:0}.product b{display:block}.serial,.warranty{text-align:left;min-width:0;white-space:pre-wrap;font-size:11px}.number{text-align:right;white-space:nowrap}.summary{margin-left:auto;width:48%;margin-top:4px}.summary div{display:flex;justify-content:space-between;gap:16px;padding:2px 0}.summary .total{font-size:15px;font-weight:700}.words{margin-top:6px;line-height:1.45}.notes{margin-top:18px;white-space:pre-line}.notes h3{font-size:15px;margin:0 0 4px;text-transform:uppercase}.signatures{display:grid;grid-template-columns:repeat(3,1fr);text-align:center;margin-top:32px;gap:18px}.signatures b,.signatures i{display:block}.signatures i{font-weight:400;margin-top:3px}.sign-space{height:76px}.footer{text-align:center;margin-top:8px;font-style:italic}.print{position:fixed;right:16px;top:16px;padding:9px 14px;border:0;border-radius:6px;background:#0b5cab;color:#fff;font:600 14px Arial;cursor:pointer}@media print{.print{display:none}.page{max-width:none;margin:0}}@media print{body{font-size:13px}.title{margin-top:18px}}
  </style></head><body><button class="print" onclick="window.print()">In phiếu A4</button><main class="page"><section class="top"><div class="store"><b>${escapePrintHtml(settings.storeName)}</b>${settings.address ? `<p>${escapePrintHtml(settings.address)}</p>` : ""}${settings.phone ? `<p><b>Hotline:</b> ${escapePrintHtml(settings.phone)}</p>` : ""}${settings.taxCode ? `<p>MST: ${escapePrintHtml(settings.taxCode)}</p>` : ""}</div><div class="order-meta"><p>Mã đơn hàng: <strong>${escapePrintHtml(order.code)}</strong></p><p>Ngày tạo: <strong>${date}</strong></p></div></section><h1 class="title">${escapePrintHtml(settings.printTitle || "PHIẾU XUẤT KHO KIÊM BẢO HÀNH")}</h1><section class="customer"><b>Khách hàng:</b><span>${escapePrintHtml(order.customerName || "Khách lẻ")}</span><b>Điện thoại:</b><span>${escapePrintHtml(customer?.phone || "")}</span><b>Địa chỉ:</b><span>${escapePrintHtml(customer?.address || order.shippingAddress || "")}</span></section><table><colgroup><col style="width:5%"><col style="width:10%"><col style="width:32%"><col style="width:15%"><col style="width:11%"><col style="width:4%"><col style="width:11%"><col style="width:12%"></colgroup><thead><tr><th>STT</th><th>Mã sản phẩm</th><th>Tên sản phẩm</th><th>Serial / IMEI</th><th>Bảo hành</th><th>SL</th><th>Đơn giá</th><th>Thành tiền</th></tr></thead><tbody>${rows}</tbody></table><section class="summary"><div><span>Tổng số lượng:</span><b>${totalQuantity}</b></div><div><span>Tổng tiền:</span><b>${printNumber(order.total)}</b></div><div><span>Khách đã trả:</span><b>${printNumber(order.paid)}</b></div><div class="total"><span>Khách phải trả:</span><b>${printNumber(order.total)}</b></div>${paymentDue > 0 ? `<div><span>Còn phải trả:</span><b>${printNumber(paymentDue)}</b></div>` : ""}</section><p class="words"><b>Bằng chữ:</b> ${escapePrintHtml(vietnameseNumber(order.total))}</p>${order.note ? `<p class="words"><b>Ghi chú đơn:</b> ${escapePrintHtml(order.note)}</p>` : ""}${settings.printRegulations ? `<section class="notes"><h3>Quy định bảo hành</h3>${escapePrintHtml(settings.printRegulations)}</section>` : ""}<section class="signatures"><div><b>${escapePrintHtml(settings.printCustomerSigner || "Khách hàng")}</b><i>(Ký, ghi rõ họ tên)</i><div class="sign-space"></div></div><div><b>${escapePrintHtml(settings.printSalesSigner || "Nhân viên KD")}</b><i>(Ký, ghi rõ họ tên)</i><div class="sign-space"></div></div><div><b>${escapePrintHtml(settings.printAccountantSigner || "Kế toán")}</b><i>(Ký, ghi rõ họ tên)</i><div class="sign-space"></div></div></section>${settings.printFooter ? `<p class="footer">${escapePrintHtml(settings.printFooter)}</p>` : ""}</main><script>window.onload=()=>setTimeout(()=>window.print(),250)</script></body></html>`);
  popup.document.close();
}

export function Orders(p: ViewProps) {
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [dateRange, setDateRange] = useState("90");
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [paymentOrder, setPaymentOrder] = useState<Order | null>(null);
  const [paymentAmount, setPaymentAmount] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "transfer">("transfer");
  const [paymentBusy, setPaymentBusy] = useState(false);
  const [cancellingOrder, setCancellingOrder] = useState<Order | null>(null);
  const [cancellationReason, setCancellationReason] = useState("");
  const [cancellationBusy, setCancellationBusy] = useState(false);
  const [referenceNow] = useState(() => Date.now());
  const selected = p.data.orders.find((x) => x.id === expandedId) || null;

  useEffect(() => {
    if (p.documentToOpen?.type !== "order") return;
    setExpandedId(p.documentToOpen.id);
    p.consumeDocumentToOpen();
  }, [p.documentToOpen, p.consumeDocumentToOpen]);

  const visualStatus = (order: Order) => {
    if (order.status === "cancelled") return "cancelled";
    if (order.paid >= order.total) return "completed";
    return "partial";
  };
  const paymentPercent = (order: Order) =>
    order.total > 0
      ? Math.min(100, Math.max(0, Math.round((order.paid / order.total) * 100)))
      : 100;
  const remainingPayment = (order: Order) =>
    order.status === "cancelled" ? 0 : Math.max(0, order.total - order.paid);
  const normalizedQuery = query.trim().toLowerCase();
  const orders = p.data.orders.filter((x) => {
    const matchesStatus = filter === "all" || visualStatus(x) === filter;
    const matchesQuery =
      !normalizedQuery ||
      [x.code, x.customerName, x.shippingAddress, x.note]
        .join(" ")
        .toLowerCase()
        .includes(normalizedQuery);
    const age = referenceNow - new Date(x.createdAt).getTime();
    const matchesDate =
      dateRange === "all" ||
      (dateRange === "today"
        ? new Date(x.createdAt).toDateString() === new Date(referenceNow).toDateString()
        : age <= Number(dateRange) * 86400000);
    return matchesStatus && matchesQuery && matchesDate;
  });
  const counts = p.data.orders.reduce(
    (result, order) => {
      result[visualStatus(order)] += 1;
      return result;
    },
    { completed: 0, partial: 0, cancelled: 0 } as Record<string, number>,
  );
  const exportOrders = () => {
    const rows = [
      ["Mã đơn", "Ngày tạo", "Khách hàng", "Tổng tiền", "Đã trả", "Đã hoàn", "Còn phải trả", "Trạng thái", "Lý do hủy"],
      ...orders.map((order) => [
        order.code,
        formatDate(order.createdAt),
        order.customerName,
        order.total,
        order.paid,
        order.refunded,
        remainingPayment(order),
        visualStatus(order) === "completed"
          ? "Đã hoàn thành"
          : visualStatus(order) === "cancelled"
            ? "Đã hủy"
            : "Đang thanh toán",
        order.cancellationReason,
      ]),
    ];
    const csv = "\uFEFF" + rows.map((row) => row.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(",")).join("\n");
    const link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    link.download = `don-hang-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(link.href);
  };
  const update = async (status: string) => {
    if (!selected) return;
    await p.api({ id: selected.id, status }, "/api/orders", "PATCH");
    setExpandedId(null);
    p.notify("Đã cập nhật trạng thái đơn hàng.");
    await p.reload();
  };
  const openCancellation = (order: Order) => {
    setCancellingOrder(order);
    setCancellationReason("Khách yêu cầu hủy đơn");
  };
  const cancelOrder = async () => {
    if (!cancellingOrder) return;
    if (!cancellationReason.trim()) {
      p.notify("Vui lòng nhập lý do hủy đơn.");
      return;
    }
    setCancellationBusy(true);
    try {
      const result = await p.api(
        {
          id: cancellingOrder.id,
          status: "cancelled",
          cancellationReason,
        },
        "/api/orders",
        "PATCH",
      );
      const refundPending = Number(result.refundPending) || 0;
      p.notify(
        refundPending > 0
          ? `Đã hủy ${cancellingOrder.code}, hoàn hàng về kho và tạo yêu cầu trả ${money(refundPending)} trong Sổ thu chi.`
          : `Đã hủy ${cancellingOrder.code} và hoàn hàng về kho.`,
      );
      setCancellingOrder(null);
      setExpandedId(null);
      await p.reload();
    } finally {
      setCancellationBusy(false);
    }
  };
  const openPayment = (order: Order) => {
    setPaymentOrder(order);
    setPaymentAmount(Math.max(0, order.total - order.paid));
    setPaymentMethod("transfer");
  };
  const addPayment = async () => {
    if (!paymentOrder) return;
    setPaymentBusy(true);
    try {
      await p.api(
        {
          action: "payment",
          id: paymentOrder.id,
          paymentAmount,
          paymentMethod,
        },
        "/api/orders",
        "PATCH",
      );
      p.notify(
        `Đã thu thêm ${money(paymentAmount)} cho đơn ${paymentOrder.code} và cập nhật Sổ thu chi.`,
      );
      setPaymentOrder(null);
      await p.reload();
    } finally {
      setPaymentBusy(false);
    }
  };
  const editingOrder = p.data.orders.find((order) => order.id === editingId);
  if (editingOrder)
    return (
      <OrderEditor
        key={editingOrder.id}
        p={p}
        order={editingOrder}
        onClose={() => setEditingId(null)}
      />
    );
  return (
    <>
    <article className="panel page orders-page">
      <div className="orders-actions">
        <button onClick={exportOrders}>⇩ Xuất file</button>
        <button className="primary" onClick={() => p.setActive("Bán hàng")}>
          ＋ Tạo đơn hàng
        </button>
      </div>

      <section className="orders-summary">
        <div className="orders-summary-head">
          <b>ĐƠN HÀNG CẦN XỬ LÝ</b>
          <span>{dateRange === "all" ? "Tất cả thời gian" : dateRange === "today" ? "Hôm nay" : `${dateRange} ngày gần nhất`}</span>
        </div>
        <div className="orders-summary-grid">
          <button onClick={() => setFilter("partial")}>
            <span>Đang thanh toán</span><b>{counts.partial}</b>
          </button>
          <button onClick={() => setFilter("completed")}>
            <span>Đã hoàn thành</span><b>{counts.completed}</b>
          </button>
          <button onClick={() => setFilter("cancelled")}>
            <span>Đã hủy</span><b>{counts.cancelled}</b>
          </button>
        </div>
      </section>

      <div className="orders-tabs">
        <button className="active">Tất cả đơn hàng</button>
        <span>{orders.length} đơn</span>
      </div>
      <div className="orders-filterbar">
        <label className="orders-search">
          <span>⌕</span>
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Tìm theo mã đơn, tên khách hàng, địa chỉ hoặc ghi chú"
          />
          {query && <button onClick={() => setQuery("")}>×</button>}
        </label>
        <select value={dateRange} onChange={(event) => setDateRange(event.target.value)} aria-label="Lọc theo ngày">
          <option value="today">Hôm nay</option>
          <option value="30">30 ngày gần nhất</option>
          <option value="90">90 ngày gần nhất</option>
          <option value="all">Tất cả thời gian</option>
        </select>
        <select value={filter} onChange={(event) => setFilter(event.target.value)} aria-label="Lọc trạng thái">
          <option value="all">Tất cả trạng thái</option>
          <option value="completed">Đã hoàn thành</option>
          <option value="partial">Đang thanh toán</option>
          <option value="cancelled">Đã hủy</option>
        </select>
        {(query || filter !== "all" || dateRange !== "90") && (
          <button className="clear-order-filters" onClick={() => { setQuery(""); setFilter("all"); setDateRange("90"); }}>
            Xóa bộ lọc
          </button>
        )}
      </div>

      <div className="orders-table-wrap">
        <table className="orders-table">
          <thead>
            <tr>
              <th aria-label="Mở chi tiết" />
              <th>Mã đơn hàng</th>
              <th>Ngày tạo đơn</th>
              <th>Tên khách hàng</th>
              <th>Trạng thái đơn</th>
              <th>Thanh toán</th>
              <th>Khách phải trả</th>
              <th>Còn phải trả</th>
            </tr>
          </thead>
          <tbody>
            {orders.length ? orders.map((order) => {
              const expanded = expandedId === order.id;
              const state = visualStatus(order);
              const percent = paymentPercent(order);
              const lineItems = p.data.orderItems.filter((item) => item.orderId === order.id);
              return (
                <React.Fragment key={order.id}>
                  <tr className={`order-main-row${expanded ? " expanded" : ""}${state === "cancelled" ? " cancelled" : ""}`}>
                    <td>
                      <button
                        className={`order-chevron${expanded ? " open" : ""}`}
                        aria-label={expanded ? `Đóng chi tiết ${order.code}` : `Mở chi tiết ${order.code}`}
                        aria-expanded={expanded}
                        onClick={() => setExpandedId(expanded ? null : order.id)}
                      >›</button>
                    </td>
                    <td><button className="order-code" onClick={() => setExpandedId(expanded ? null : order.id)}>{order.code}</button></td>
                    <td>{formatDate(order.createdAt)}</td>
                    <td>{order.customerName}</td>
                    <td><span className={`order-state ${state}`}>{state === "completed" ? "Đã hoàn thành" : state === "cancelled" ? "Đã hủy" : "Đang thanh toán"}</span></td>
                    <td>
                      {state === "cancelled" ? (
                        <span className="cancel-refund">
                          {order.refunded > 0
                            ? `Đã hoàn ${money(order.refunded)}`
                            : order.paid > 0
                              ? `Chờ hoàn ${money(order.paid)}`
                              : "Không thu tiền"}
                        </span>
                      ) : (
                        <span className="payment-progress" title={`Đã thanh toán ${percent}%`}>
                          <i style={{ "--paid": `${percent}%` } as React.CSSProperties} />
                          <b>{percent}%</b>
                        </span>
                      )}
                    </td>
                    <td className="money-cell">{money(order.total)}</td>
                    <td className={remainingPayment(order) > 0 ? "money-cell due" : "money-cell"}>{money(remainingPayment(order))}</td>
                  </tr>
                  {expanded && (
                    <tr className="order-detail-row">
                      <td colSpan={8}>
                        <div className="inline-order-detail">
                          <div className="inline-order-meta">
                            <div><small>Kênh bán</small><b>{order.channel === "pos" ? "Tại quầy" : "Online"}</b></div>
                            <div><small>Phương thức trả</small><b>{order.paymentMethod === "transfer" ? "Chuyển khoản" : "Tiền mặt"}</b></div>
                            <div>
                              <small>{state === "cancelled" ? "Hoàn tiền" : "Đã thanh toán"}</small>
                              <b>
                                {state === "cancelled"
                                  ? order.refunded > 0
                                    ? money(order.refunded)
                                    : order.paid > 0
                                      ? `Chờ hoàn ${money(order.paid)}`
                                      : money(0)
                                  : `${money(order.paid)} / ${money(order.total)}`}
                              </b>
                            </div>
                            <div>
                              <small>{state === "cancelled" ? "Lý do hủy" : "Ghi chú"}</small>
                              <b>{state === "cancelled" ? order.cancellationReason || "Không ghi lý do" : order.note || "Không có ghi chú"}</b>
                            </div>
                          </div>
                          <div className="inline-order-products">
                            <table>
                              <colgroup>
                                <col className="order-product-name-column" />
                                <col className="order-product-sku-column" />
                                <col className="order-product-serial-column" />
                                <col className="order-product-quantity-column" />
                                <col className="order-product-price-column" />
                                <col className="order-product-discount-column" />
                                <col className="order-product-total-column" />
                              </colgroup>
                              <thead><tr><th>Sản phẩm</th><th>SKU</th><th>Serial</th><th>SL</th><th>Đơn giá</th><th>Chiết khấu</th><th>Thành tiền</th></tr></thead>
                              <tbody>
                                {lineItems.map((item) => {
                                  let serials: string[] = [];
                                  try { serials = JSON.parse(item.serialsJson || "[]"); } catch { serials = []; }
                                  return <tr key={item.id}>
                                    <td className="product-name-cell" title={item.productName}><b>{item.productName}</b>{item.note && <small>{item.note}</small>}</td>
                                    <td>{item.sku}</td>
                                    <td>{serials.join(", ") || "—"}</td>
                                    <td>{item.quantity}</td>
                                    <td>{money(item.unitPrice)}</td>
                                    <td>{money(item.discount)}</td>
                                    <td><b>{money(item.unitPrice * item.quantity - item.discount)}</b></td>
                                  </tr>;
                                })}
                                {!lineItems.length && <tr><td colSpan={7}><div className="mini-empty">Chưa có chi tiết sản phẩm</div></td></tr>}
                              </tbody>
                            </table>
                          </div>
                          <div className="inline-order-actions">
                            <button onClick={() => printOrderA4(p, order)}>In đơn A4</button>
                            {order.status !== "cancelled" && (
                              <button onClick={() => setEditingId(order.id)}>
                                Sửa đơn hàng
                              </button>
                            )}
                            {order.status !== "cancelled" && order.paid < order.total && (
                              <button className="primary" onClick={() => openPayment(order)}>
                                Thanh toán thêm
                              </button>
                            )}
                            {order.status === "pending" && <button className="primary" onClick={() => update("processing")}>Xác nhận đơn</button>}
                            {order.status === "processing" && order.paid >= order.total && <button className="primary" onClick={() => update("completed")}>Hoàn thành</button>}
                            {order.status !== "cancelled" && (
                              <button className="danger-button cancel-order-button" onClick={() => openCancellation(order)}>
                                Hủy đơn hàng
                              </button>
                            )}
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            }) : <tr><td colSpan={8}><div className="mini-empty">Không tìm thấy đơn hàng phù hợp</div></td></tr>}
          </tbody>
        </table>
      </div>
    </article>
    {paymentOrder && (
      <Modal
        title={`Thanh toán thêm · ${paymentOrder.code}`}
        onClose={() => setPaymentOrder(null)}
      >
        <div className="additional-payment-summary">
          <p><span>Khách phải trả</span><b>{money(paymentOrder.total)}</b></p>
          <p><span>Đã thanh toán</span><b>{money(paymentOrder.paid)}</b></p>
          <p className="due"><span>Còn phải trả</span><b>{money(Math.max(0, paymentOrder.total - paymentOrder.paid))}</b></p>
        </div>
        <Field label="Số tiền thanh toán thêm">
          <MoneyInput
            autoFocus
            max={Math.max(0, paymentOrder.total - paymentOrder.paid)}
            value={paymentAmount}
            ariaLabel="Số tiền thanh toán thêm"
            onValueChange={setPaymentAmount}
          />
        </Field>
        <span className="picker-label">Ghi vào quỹ</span>
        <div className="payment-methods additional-payment-methods">
          <button type="button" className={paymentMethod === "cash" ? "selected" : ""} onClick={() => setPaymentMethod("cash")}>
            <i>₫</i><span>Tiền mặt</span>
          </button>
          <button type="button" className={paymentMethod === "transfer" ? "selected" : ""} onClick={() => setPaymentMethod("transfer")}>
            <i>⇄</i><span>Chuyển khoản</span>
          </button>
        </div>
        <div className="additional-payment-after">
          Sau giao dịch còn phải trả <b>{money(Math.max(0, paymentOrder.total - paymentOrder.paid - paymentAmount))}</b>
        </div>
        <SpinnerButton
          className="primary modal-submit"
          busy={paymentBusy}
          disabled={paymentAmount <= 0 || paymentAmount > paymentOrder.total - paymentOrder.paid}
          onClick={addPayment}
        >
          Xác nhận thanh toán và ghi Sổ thu chi
        </SpinnerButton>
      </Modal>
    )}
    {cancellingOrder && (
      <Modal
        title={`Hủy đơn hàng · ${cancellingOrder.code}`}
        onClose={() => !cancellationBusy && setCancellingOrder(null)}
        className="cancel-order-modal"
      >
        <div className="cancel-order-warning">
          <b>Thao tác này sẽ thực hiện đồng thời:</b>
          <ul>
            <li>Đánh dấu đơn hàng là Đã hủy.</li>
            <li>Hoàn toàn bộ sản phẩm và serial về kho.</li>
            <li>
              {cancellingOrder.paid > 0
                ? `Ghi khoản hoàn tiền ${money(cancellingOrder.paid)} vào Sổ thu chi.`
                : "Đơn chưa thu tiền nên không phát sinh khoản hoàn."}
            </li>
            <li>Đóng công nợ còn lại của đơn hàng.</li>
          </ul>
        </div>
        <Field label="Lý do hủy đơn">
          <textarea
            autoFocus
            value={cancellationReason}
            maxLength={500}
            onChange={(event) => setCancellationReason(event.target.value)}
            placeholder="Nhập lý do hủy để lưu lịch sử"
          />
        </Field>
        <div className="cancel-order-actions">
          <button
            className="secondary"
            type="button"
            disabled={cancellationBusy}
            onClick={() => setCancellingOrder(null)}
          >
            Quay lại
          </button>
          <SpinnerButton
            className="cancel-order-submit"
            busy={cancellationBusy}
            onClick={cancelOrder}
          >
            Xác nhận hủy đơn
          </SpinnerButton>
        </div>
      </Modal>
    )}
    </>
  );
}
