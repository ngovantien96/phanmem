import { mkdirSync, readFileSync, readdirSync } from "node:fs";
import { unlink } from "node:fs/promises";
import path from "node:path";
import { DatabaseSync, type StatementSync } from "node:sqlite";

type SQLiteValue = null | number | string | Uint8Array;

const normalizeValue = (value: unknown): SQLiteValue => {
  if (value === undefined || value === null) return null;
  if (typeof value === "boolean") return value ? 1 : 0;
  if (typeof value === "number" || typeof value === "string" || value instanceof Uint8Array)
    return value;
  return String(value);
};

class LocalPreparedStatement {
  private values: SQLiteValue[] = [];

  constructor(private readonly statement: StatementSync) {
    statement.setAllowBareNamedParameters(true);
    statement.setReadBigInts(false);
  }

  bind(...values: unknown[]) {
    this.values = values.map(normalizeValue);
    return this;
  }

  async first<T = Record<string, unknown>>(): Promise<T | null> {
    return (this.statement.get(...this.values) as T | undefined) ?? null;
  }

  async all<T = Record<string, unknown>>(): Promise<{ results: T[] }> {
    return { results: this.statement.all(...this.values) as T[] };
  }

  async run() {
    const result = this.statement.run(...this.values);
    return {
      success: true,
      meta: {
        changes: Number(result.changes),
        last_row_id: Number(result.lastInsertRowid),
      },
    };
  }

  runInBatch() {
    return this.statement.run(...this.values);
  }
}

class LocalSQLiteDatabase {
  constructor(private readonly database: DatabaseSync) {}

  prepare(query: string) {
    return new LocalPreparedStatement(this.database.prepare(query));
  }

  async batch(statements: LocalPreparedStatement[]) {
    this.database.exec("BEGIN IMMEDIATE");
    try {
      const results = statements.map((statement) => statement.runInBatch());
      this.database.exec("COMMIT");
      return results;
    } catch (error) {
      this.database.exec("ROLLBACK");
      throw error;
    }
  }
}

export type LocalD1Database = LocalSQLiteDatabase;

declare global {
  type D1Database = LocalD1Database;
  var __TIEN_SQLITE_DB__: LocalSQLiteDatabase | undefined;
}

const dataDirectory = () =>
  path.resolve(
    /* turbopackIgnore: true */ process.env.DATA_DIR || path.join(process.cwd(), "data"),
  );

const migrate = (database: DatabaseSync) => {
  database.exec(`
    CREATE TABLE IF NOT EXISTS _local_migrations (
      name TEXT PRIMARY KEY NOT NULL,
      applied_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL
    )
  `);

  const migrationDirectory = path.join(process.cwd(), "drizzle");
  const applied = new Set(
    (database.prepare("SELECT name FROM _local_migrations").all() as Array<{ name: string }>).map(
      (row) => row.name,
    ),
  );

  for (const name of readdirSync(migrationDirectory).filter((file) => file.endsWith(".sql")).sort()) {
    if (applied.has(name)) continue;
    const sql = readFileSync(path.join(migrationDirectory, name), "utf8");
    database.exec("BEGIN IMMEDIATE");
    try {
      database.exec(sql);
      database.prepare("INSERT INTO _local_migrations (name) VALUES (?)").run(name);
      database.exec("COMMIT");
    } catch (error) {
      database.exec("ROLLBACK");
      throw new Error(`Không thể cập nhật SQLite tại ${name}: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
};

export function getD1(): LocalSQLiteDatabase {
  if (globalThis.__TIEN_SQLITE_DB__) return globalThis.__TIEN_SQLITE_DB__;

  const directory = dataDirectory();
  mkdirSync(directory, { recursive: true });
  const database = new DatabaseSync(path.join(directory, "sale.db"));
  database.exec("PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;");
  migrate(database);

  globalThis.__TIEN_SQLITE_DB__ = new LocalSQLiteDatabase(database);
  return globalThis.__TIEN_SQLITE_DB__;
}

export function getDataDirectory() {
  const directory = dataDirectory();
  mkdirSync(directory, { recursive: true });
  return directory;
}

export async function deleteProductImage(key: string) {
  if (!key.startsWith("product-images/") || key.includes("..")) return;
  try {
    await unlink(path.join(getDataDirectory(), key));
  } catch (error) {
    const code = (error as NodeJS.ErrnoException).code;
    if (code !== "ENOENT") throw error;
  }
}
