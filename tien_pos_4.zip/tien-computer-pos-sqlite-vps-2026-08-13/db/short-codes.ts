type CodeTarget = "customer" | "supplier" | "product" | "order" | "purchase" | "return" | "warranty";

const targets: Record<CodeTarget, { prefix: string }> = {
  customer: { prefix: "KH" },
  supplier: { prefix: "NC" },
  product: { prefix: "SP" },
  order: { prefix: "DH" },
  purchase: { prefix: "PN" },
  return: { prefix: "TH" },
  warranty: { prefix: "BH" },
};

export async function nextShortCode(db: D1Database, target: CodeTarget) {
  const { prefix } = targets[target];
  // The counter is updated atomically, so deleted documents never release a
  // code and simultaneous creates cannot receive the same number.
  const row = await db
    .prepare(
      "INSERT INTO code_counters (kind, last_value) VALUES (?, 1) ON CONFLICT(kind) DO UPDATE SET last_value = code_counters.last_value + 1 RETURNING last_value AS lastValue",
    )
    .bind(target)
    .first<{ lastValue: number }>();
  if (!row) throw new Error("Không thể tạo mã mới.");
  return `${prefix}${String(row.lastValue).padStart(4, "0")}`;
}

export async function reserveShortCode(
  db: D1Database,
  target: CodeTarget,
  code: string,
) {
  const { prefix } = targets[target];
  const suffix = code.trim().toUpperCase().slice(prefix.length);
  if (!code.trim().toUpperCase().startsWith(prefix) || !/^\d+$/.test(suffix))
    return;
  const value = Number(suffix);
  if (!Number.isSafeInteger(value) || value < 1) return;
  await db
    .prepare(
      "INSERT INTO code_counters (kind, last_value) VALUES (?, ?) ON CONFLICT(kind) DO UPDATE SET last_value = MAX(code_counters.last_value, excluded.last_value)",
    )
    .bind(target, value)
    .run();
}
