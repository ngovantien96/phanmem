# Tiến Computer POS — bản SQLite cho Ubuntu/VPS

Đây là bản mã nguồn hiện tại của Tiến Computer POS đã chuyển từ Cloudflare D1
sang SQLite cục bộ để chạy bằng Node.js sau Nginx.

## Yêu cầu

- Ubuntu 22.04/24.04.
- Node.js từ 22.13 trở lên.
- Nginx.

## Chạy thử nhanh

```bash
unzip tien-computer-pos-sqlite-vps-2026-08-13.zip
cd tien-computer-pos-sqlite-vps-2026-08-13
npm ci
npm run build
mkdir -p data
DATA_DIR="$PWD/data" PORT=3000 npm start
```

Mở `http://127.0.0.1:3000`. Lần chạy đầu, hệ thống tự tạo:

- `data/sale.db`: cơ sở dữ liệu SQLite.
- `data/product-images/`: ảnh sản phẩm tải lên.

## Cài trên máy chủ thật

Xem hướng dẫn từng bước tại `deploy/HUONG-DAN-CAI-DAT.md`.

## Nguyên tắc giữ dữ liệu khi cập nhật

Trên máy chủ thật, đặt `DATA_DIR=/var/lib/tien-computer-pos`. Thư mục này nằm
ngoài thư mục code nên có thể thay toàn bộ source mà vẫn giữ nguyên database và
ảnh sản phẩm. Trước mỗi lần cập nhật vẫn nên sao lưu toàn bộ thư mục dữ liệu.

Không chép đè hoặc xóa:

```text
/var/lib/tien-computer-pos/sale.db
/var/lib/tien-computer-pos/product-images/
```
