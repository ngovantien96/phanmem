# Hướng dẫn cài Tiến Computer POS SQLite trên Ubuntu + Nginx

## 1. Cài phần mềm cần thiết

```bash
sudo apt update
sudo apt install -y nginx unzip curl
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
node -v
```

Node.js phải từ `v22.13.0` trở lên.

## 2. Đưa source vào thư mục web

Ví dụ file ZIP nằm trong `/tmp`:

```bash
sudo mkdir -p /var/www/tien-computer-pos
sudo unzip /tmp/tien-computer-pos-sqlite-vps-2026-08-13.zip -d /tmp/tien-pos-release
sudo cp -a /tmp/tien-pos-release/tien-computer-pos-sqlite-vps-2026-08-13/. /var/www/tien-computer-pos/
sudo chown -R www-data:www-data /var/www/tien-computer-pos
```

## 3. Tạo thư mục dữ liệu SQLite nằm ngoài source

```bash
sudo mkdir -p /var/lib/tien-computer-pos
sudo chown -R www-data:www-data /var/lib/tien-computer-pos
sudo chmod 750 /var/lib/tien-computer-pos
```

Database sẽ là `/var/lib/tien-computer-pos/sale.db`.

## 4. Cài thư viện và build

```bash
cd /var/www/tien-computer-pos
sudo -u www-data npm ci
sudo -u www-data npm run build
```

## 5. Cài service

```bash
sudo cp deploy/tien-computer-pos.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now tien-computer-pos
sudo systemctl status tien-computer-pos --no-pager
```

Kiểm tra nội bộ:

```bash
curl -I http://127.0.0.1:3000
```

## 6. Cấu hình Nginx

Sửa `server_name` trong file mẫu thành tên miền thật, sau đó:

```bash
sudo cp deploy/nginx-tien-computer-pos.conf /etc/nginx/sites-available/tien-computer-pos
sudo ln -s /etc/nginx/sites-available/tien-computer-pos /etc/nginx/sites-enabled/tien-computer-pos
sudo nginx -t
sudo systemctl reload nginx
```

## 7. Xem lỗi nếu web chưa chạy

```bash
sudo journalctl -u tien-computer-pos -n 100 --no-pager
sudo journalctl -u tien-computer-pos -f
```

## Cập nhật source nhưng giữ nguyên dữ liệu

Sao lưu trước:

```bash
sudo systemctl stop tien-computer-pos
sudo cp -a /var/lib/tien-computer-pos /var/lib/tien-computer-pos-backup
```

Chép source mới vào `/var/www/tien-computer-pos`, sau đó:

```bash
cd /var/www/tien-computer-pos
sudo -u www-data npm ci
sudo -u www-data npm run build
sudo systemctl start tien-computer-pos
```

Không xóa `/var/lib/tien-computer-pos`. Khi source mới có thay đổi cấu trúc,
hệ thống sẽ tự chạy phần cập nhật database còn thiếu lúc khởi động.
