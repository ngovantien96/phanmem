import Database from "better-sqlite3";
import { existsSync, mkdirSync, readdirSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const databasePath = resolve(process.env.DATABASE_PATH || "./data/sales.db");
const migrationsPath = resolve(root, "drizzle");

if (!existsSync(dirname(databasePath))) mkdirSync(dirname(databasePath), { recursive: true });

const database = new Database(databasePath);
database.pragma("journal_mode = WAL");
database.pragma("foreign_keys = ON");
database.exec(`
  CREATE TABLE IF NOT EXISTS __tien_migrations (
    name TEXT PRIMARY KEY NOT NULL,
    applied_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL
  );
`);

const applied = new Set(
  database.prepare("SELECT name FROM __tien_migrations").all().map((row) => row.name),
);
const files = readdirSync(migrationsPath)
  .filter((name) => /^\d+_.+\.sql$/.test(name))
  .sort();

for (const name of files) {
  if (applied.has(name)) continue;
  const statements = readFileSync(resolve(migrationsPath, name), "utf8")
    .split("--> statement-breakpoint")
    .map((statement) => statement.trim())
    .filter(Boolean);

  database.transaction(() => {
    for (const statement of statements) database.exec(statement);
    database.prepare("INSERT INTO __tien_migrations (name) VALUES (?)").run(name);
  })();
  console.log(`Applied ${name}`);
}

database.close();
