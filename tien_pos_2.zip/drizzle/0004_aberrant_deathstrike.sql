ALTER TABLE `purchase_items` ADD `discount` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `purchase_items` ADD `note` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `purchases` ADD `subtotal` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `purchases` ADD `discount` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `purchases` ADD `other_costs` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `purchases` ADD `tax` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `purchases` ADD `tax_rate` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `purchases` ADD `tags` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `purchases` ADD `costs_json` text DEFAULT '[]' NOT NULL;