ALTER TABLE `cash_transactions` ADD `expected_amount` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `cash_transactions` ADD `status` text DEFAULT 'completed' NOT NULL;--> statement-breakpoint
ALTER TABLE `cash_transactions` ADD `partner_type` text;--> statement-breakpoint
ALTER TABLE `cash_transactions` ADD `partner_name` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `cash_transactions` ADD `reference` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `cash_transactions` ADD `source_type` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `cash_transactions` ADD `source_id` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `cash_transactions` ADD `settled_at` text;--> statement-breakpoint
CREATE INDEX `cash_transactions_status_idx` ON `cash_transactions` (`status`);--> statement-breakpoint
CREATE INDEX `cash_transactions_source_idx` ON `cash_transactions` (`source_type`,`source_id`);--> statement-breakpoint
ALTER TABLE `debts` ADD `settlement_type` text DEFAULT 'income' NOT NULL;--> statement-breakpoint
ALTER TABLE `debts` ADD `source_transaction_id` text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE INDEX `debts_source_transaction_idx` ON `debts` (`source_transaction_id`);
--> statement-breakpoint
UPDATE `cash_transactions` SET `expected_amount` = `amount`;
--> statement-breakpoint
UPDATE `cash_transactions`
SET `status` = 'pending',
    `partner_type` = 'customer',
    `partner_name` = COALESCE((SELECT `customer_name` FROM `orders` WHERE `orders`.`id` = `cash_transactions`.`order_id`), ''),
    `reference` = COALESCE((SELECT `code` FROM `orders` WHERE `orders`.`id` = `cash_transactions`.`order_id`), ''),
    `source_type` = 'order_cancel',
    `source_id` = COALESCE(`order_id`, '')
WHERE `category` = 'Hoàn tiền hủy đơn';
--> statement-breakpoint
UPDATE `orders`
SET `refunded` = 0
WHERE `status` = 'cancelled'
  AND EXISTS (
    SELECT 1 FROM `cash_transactions`
    WHERE `cash_transactions`.`order_id` = `orders`.`id`
      AND `cash_transactions`.`category` = 'Hoàn tiền hủy đơn'
      AND `cash_transactions`.`status` = 'pending'
  );
--> statement-breakpoint
UPDATE `cash_transactions`
SET `status` = 'pending',
    `partner_type` = 'supplier',
    `partner_name` = COALESCE((
      SELECT `supplier_name` FROM `purchase_returns`
      WHERE `cash_transactions`.`note` LIKE '%' || `purchase_returns`.`purchase_code` || '%'
      LIMIT 1
    ), ''),
    `reference` = COALESCE((
      SELECT `purchase_code` FROM `purchase_returns`
      WHERE `cash_transactions`.`note` LIKE '%' || `purchase_returns`.`purchase_code` || '%'
      LIMIT 1
    ), ''),
    `source_type` = 'purchase_return',
    `source_id` = COALESCE((
      SELECT `purchase_id` FROM `purchase_returns`
      WHERE `cash_transactions`.`note` LIKE '%' || `purchase_returns`.`purchase_code` || '%'
      LIMIT 1
    ), '')
WHERE `category` = 'Hoàn trả nhập hàng';
--> statement-breakpoint
UPDATE `debts`
SET `settlement_type` = CASE WHEN `partner_type` = 'supplier' THEN 'expense' ELSE 'income' END;
