CREATE TABLE `product_options` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`type` text NOT NULL,
	`name` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `product_options_type_name_idx` ON `product_options` (`type`,`name`);
--> statement-breakpoint
INSERT OR IGNORE INTO `product_options` (`type`, `name`)
SELECT 'category', TRIM(`category`) FROM `products` WHERE TRIM(`category`) <> '' GROUP BY TRIM(`category`);
--> statement-breakpoint
INSERT OR IGNORE INTO `product_options` (`type`, `name`)
SELECT 'brand', TRIM(`brand`) FROM `products` WHERE TRIM(`brand`) <> '' GROUP BY TRIM(`brand`);
--> statement-breakpoint
INSERT OR IGNORE INTO `product_options` (`type`, `name`) VALUES
('category', 'Laptop'),
('category', 'Linh kiện'),
('category', 'Phụ kiện');
