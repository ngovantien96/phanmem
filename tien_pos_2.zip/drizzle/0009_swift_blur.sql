CREATE TABLE `purchase_returns` (
	`id` text PRIMARY KEY NOT NULL,
	`purchase_id` text NOT NULL,
	`purchase_code` text NOT NULL,
	`supplier_name` text NOT NULL,
	`amount` integer DEFAULT 0 NOT NULL,
	`reason` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`purchase_id`) REFERENCES `purchases`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `purchase_returns_purchase_idx` ON `purchase_returns` (`purchase_id`);--> statement-breakpoint
CREATE INDEX `purchase_returns_created_at_idx` ON `purchase_returns` (`created_at`);--> statement-breakpoint
ALTER TABLE `purchases` ADD `received_at` text;--> statement-breakpoint
ALTER TABLE `purchases` ADD `returned_amount` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `purchases` ADD `return_reason` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `purchases` ADD `returned_at` text;