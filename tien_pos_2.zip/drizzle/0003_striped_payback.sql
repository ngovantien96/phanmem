ALTER TABLE `order_items` ADD `discount` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `order_items` ADD `note` text DEFAULT '' NOT NULL;