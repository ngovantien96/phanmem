ALTER TABLE `store_settings` ADD `print_title` text DEFAULT 'PHIẾU XUẤT KHO KIÊM BẢO HÀNH' NOT NULL;--> statement-breakpoint
ALTER TABLE `store_settings` ADD `print_regulations` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `store_settings` ADD `print_customer_signer` text DEFAULT 'Khách hàng' NOT NULL;--> statement-breakpoint
ALTER TABLE `store_settings` ADD `print_sales_signer` text DEFAULT 'Nhân viên KD' NOT NULL;--> statement-breakpoint
ALTER TABLE `store_settings` ADD `print_accountant_signer` text DEFAULT 'Kế toán' NOT NULL;--> statement-breakpoint
ALTER TABLE `store_settings` ADD `print_footer` text DEFAULT '' NOT NULL;