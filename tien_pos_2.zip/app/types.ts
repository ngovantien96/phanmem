export type Product = {
  id: number;
  sku: string;
  name: string;
  category: string;
  brand: string;
  imageKey: string;
  description: string;
  unit: string;
  warrantyMonths: number;
  tracking: "serial" | "quantity";
  cost: number;
  price: number;
  stock: number;
  min: number;
  active: boolean;
  createdAt: string;
};
export type ProductOption = {
  id: number;
  type: "category" | "brand";
  name: string;
};
export type CartItem = Product & {
  qty: number;
  selectedSerials: string[];
  unitPrice: number;
  lineDiscount: number;
  lineNote: string;
};
export type Order = {
  id: string;
  code: string;
  customerId: string | null;
  customerName: string;
  phone: string;
  subtotal: number;
  discount: number;
  total: number;
  paid: number;
  refunded: number;
  paymentMethod: string;
  status: string;
  channel: string;
  shippingAddress: string;
  note: string;
  cancellationReason: string;
  cancelledAt: string | null;
  createdAt: string;
};
export type OrderItem = {
  id: number;
  orderId: string;
  productId: number;
  productName: string;
  sku: string;
  quantity: number;
  unitPrice: number;
  unitCost: number;
  discount: number;
  note: string;
  serialsJson: string;
};
export type Customer = {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  createdAt: string;
};
export type Serial = {
  id: number;
  productId: number;
  serial: string;
  status: string;
  orderId: string | null;
  productName: string;
  sku: string;
};
export type CashTransaction = {
  id: string;
  type: "income" | "expense";
  category: string;
  note: string;
  amount: number;
  expectedAmount: number;
  paymentMethod: "cash" | "transfer";
  status: "completed" | "pending" | "partial" | "deferred";
  partnerType: "customer" | "supplier" | null;
  partnerName: string;
  reference: string;
  sourceType: string;
  sourceId: string;
  settledAt: string | null;
  orderId: string | null;
  createdAt: string;
};
export type Supplier = {
  id: string;
  code: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  createdAt: string;
};
export type Purchase = {
  id: string;
  code: string;
  supplierId: string;
  supplierName: string;
  total: number;
  paid: number;
  status: string;
  note: string;
  receivedAt: string;
  returnedAmount: number;
  returnReason: string;
  returnedAt: string | null;
  createdAt: string;
};
export type Movement = {
  id: string;
  productId: number;
  productName: string;
  type: string;
  quantity: number;
  reference: string;
  note: string;
  createdAt: string;
};
export type ReturnRow = {
  id: string;
  code: string;
  orderId: string;
  orderCode: string;
  customerName: string;
  amount: number;
  reason: string;
  itemsJson: string;
  status: string;
  createdAt: string;
};
export type Warranty = {
  id: string;
  code: string;
  customerName: string;
  phone: string;
  productName: string;
  serial: string;
  issue: string;
  status: string;
  expectedAt: string;
  note: string;
  createdAt: string;
  updatedAt: string;
};
export type Debt = {
  id: string;
  partnerType: string;
  partnerName: string;
  reference: string;
  total: number;
  paid: number;
  dueDate: string;
  status: string;
  settlementType: "income" | "expense";
  sourceTransactionId: string;
  createdAt: string;
};
export type Settings = {
  id: number;
  storeName: string;
  phone: string;
  address: string;
  taxCode: string;
  receiptFooter: string;
  printTitle: string;
  printRegulations: string;
  printCustomerSigner: string;
  printSalesSigner: string;
  printAccountantSigner: string;
  printFooter: string;
  allowNegativeStock: boolean;
  autoPrint: boolean;
  lowStockAlert: boolean;
  updatedAt: string;
};
export type StoreData = {
  products: Product[];
  productOptions: ProductOption[];
  orders: Order[];
  orderItems: OrderItem[];
  customers: Customer[];
  serials: Serial[];
  cashTransactions: CashTransaction[];
  suppliers: Supplier[];
  purchases: Purchase[];
  inventoryMovements: Movement[];
  returns: ReturnRow[];
  warranties: Warranty[];
  debts: Debt[];
  settings: Settings;
};

export const emptyStore: StoreData = {
  products: [],
  productOptions: [],
  orders: [],
  orderItems: [],
  customers: [],
  serials: [],
  cashTransactions: [],
  suppliers: [],
  purchases: [],
  inventoryMovements: [],
  returns: [],
  warranties: [],
  debts: [],
  settings: {
    id: 1,
    storeName: "Tiến Computer",
    phone: "",
    address: "",
    taxCode: "",
    receiptFooter: "Cảm ơn quý khách!",
    printTitle: "PHIẾU XUẤT KHO KIÊM BẢO HÀNH",
    printRegulations: "- Bảo hành theo tiêu chuẩn của nhà sản xuất.\n- Thiết bị phải còn nguyên tem bảo hành của cửa hàng và nhà cung cấp.\n- Không bảo hành với hư hỏng do rơi vỡ, đính nước hoặc tác động bên ngoài.\n- Không bảo hành khi khách tự sửa chữa hoặc không có phiếu bảo hành.",
    printCustomerSigner: "Khách hàng",
    printSalesSigner: "Nhân viên KD",
    printAccountantSigner: "Kế toán",
    printFooter: "",
    allowNegativeStock: false,
    autoPrint: false,
    lowStockAlert: true,
    updatedAt: "",
  },
};
export const money = (n: number) =>
  new Intl.NumberFormat("vi-VN").format(n || 0) + "đ";

// Giá trị tồn luôn dựa trên giá vốn hiện tại, không dùng giá bán.
export const inventoryValue = (product: Pick<Product, "cost" | "stock">) =>
  Math.max(0, product.cost) * Math.max(0, product.stock);
export const formatDate = (value: string) =>
  value
    ? new Intl.DateTimeFormat("vi-VN", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }).format(new Date(value))
    : "—";
export const statusLabel = (value: string) =>
  ({
    completed: "Hoàn thành",
    processing: "Đang xử lý",
    pending: "Chờ xác nhận",
    cancelled: "Đã hủy",
    available: "Sẵn sàng",
    sold: "Đã bán",
    warranty: "Bảo hành",
    received: "Đã tiếp nhận",
    waiting: "Chờ linh kiện",
    returned: "Đã trả khách",
    purchase_returned: "Đã hoàn trả",
    partial: "Thanh toán một phần",
    unpaid: "Chưa thanh toán",
    open: "Chưa thanh toán",
    paid: "Đã thanh toán",
    purchase: "Nhập hàng",
    sale: "Bán hàng",
    return: "Trả hàng",
    purchase_return: "Trả nhà cung cấp",
    adjustment: "Điều chỉnh",
    deferred: "Đã chuyển công nợ",
  })[value] || value;
