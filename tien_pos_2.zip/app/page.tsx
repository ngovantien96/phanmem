"use client";
import {
  Suspense,
  lazy,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { CartItem, Product, StoreData, emptyStore } from "./types";
import type { ViewProps } from "./views-main";

const Dashboard = lazy(() =>
  import("./views-main").then((module) => ({ default: module.Dashboard })),
);
const Inventory = lazy(() =>
  import("./views-main").then((module) => ({ default: module.Inventory })),
);
const Orders = lazy(() =>
  import("./views-main").then((module) => ({ default: module.Orders })),
);
const POS = lazy(() =>
  import("./views-main").then((module) => ({ default: module.POS })),
);
const Products = lazy(() =>
  import("./views-main").then((module) => ({ default: module.Products })),
);
const Cash = lazy(() =>
  import("./views-ops").then((module) => ({ default: module.Cash })),
);
const Customers = lazy(() =>
  import("./views-ops").then((module) => ({ default: module.Customers })),
);
const Debts = lazy(() =>
  import("./views-ops").then((module) => ({ default: module.Debts })),
);
const OnlineStore = lazy(() =>
  import("./views-ops").then((module) => ({ default: module.OnlineStore })),
);
const Purchases = lazy(() =>
  import("./views-ops").then((module) => ({ default: module.Purchases })),
);
const Reports = lazy(() =>
  import("./views-ops").then((module) => ({ default: module.Reports })),
);
const Returns = lazy(() =>
  import("./views-ops").then((module) => ({ default: module.Returns })),
);
const SettingsView = lazy(() =>
  import("./views-ops").then((module) => ({ default: module.SettingsView })),
);
const Suppliers = lazy(() =>
  import("./views-ops").then((module) => ({ default: module.Suppliers })),
);
const Warranties = lazy(() =>
  import("./views-ops").then((module) => ({ default: module.Warranties })),
);

const navigation = [
  {
    group: "BÁN HÀNG",
    items: [
      ["Tổng quan", "⌂"],
      ["Bán hàng", "▤"],
      ["Đơn hàng", "▧"],
      ["Cửa hàng online", "◫"],
    ],
  },
  {
    group: "HÀNG HÓA",
    items: [
      ["Sản phẩm", "◇"],
      ["Nhập hàng", "⇩"],
      ["Kho & serial", "▣"],
    ],
  },
  {
    group: "VẬN HÀNH",
    items: [
      ["Đổi trả", "↶"],
      ["Bảo hành", "♧"],
      ["Khách hàng", "♙"],
      ["Nhà cung cấp", "▱"],
      ["Công nợ", "₫"],
      ["Thu chi", "↕"],
      ["Báo cáo", "▥"],
    ],
  },
  { group: "QUẢN TRỊ", items: [["Quản trị", "⚙"]] },
];

type StoreScope = keyof StoreData;

const commonScopes: StoreScope[] = ["products", "settings"];
const scopesByView: Record<string, StoreScope[]> = {
  "Tổng quan": ["orders", "orderItems"],
  "Bán hàng": ["orders", "orderItems", "customers", "serials", "cashTransactions"],
  "Đơn hàng": ["orders", "orderItems", "customers", "serials", "cashTransactions"],
  "Cửa hàng online": ["orders", "orderItems"],
  "Sản phẩm": ["serials", "productOptions"],
  "Nhập hàng": [
    "suppliers",
    "purchases",
    "productOptions",
    "debts",
    "serials",
    "cashTransactions",
    "inventoryMovements",
  ],
  "Kho & serial": ["serials", "inventoryMovements"],
  "Đổi trả": [
    "orders",
    "orderItems",
    "returns",
    "serials",
    "cashTransactions",
    "inventoryMovements",
  ],
  "Bảo hành": ["warranties", "serials"],
  "Khách hàng": ["customers", "orders"],
  "Nhà cung cấp": ["suppliers", "purchases"],
  "Công nợ": ["debts"],
  "Thu chi": ["cashTransactions"],
  "Báo cáo": ["orders", "orderItems", "customers", "warranties"],
  "Quản trị": ["orders", "cashTransactions", "purchases", "debts"],
};

const scopesFor = (view: string) => [
  ...new Set([...commonScopes, ...(scopesByView[view] ?? [])]),
];

async function fetchStore(scopes: StoreScope[]) {
  const params = new URLSearchParams({ scope: scopes.join(",") });
  const response = await fetch(`/api/store?${params}`, { cache: "no-store" });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error);
  return result as Partial<StoreData>;
}

export default function Home() {
  const [active, setActive] = useState("Tổng quan");
  const [query, setQuery] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [productDraft, setProductDraft] = useState<string | null>(null);
  const [documentToOpen, setDocumentToOpen] = useState<{
    type: "order" | "purchase";
    id: string;
  } | null>(null);
  const [toast, setToast] = useState("");
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<StoreData>(emptyStore);
  const loadedScopes = useRef(new Set<StoreScope>());
  const loadScopes = useCallback(async (scopes: StoreScope[], force = false) => {
    const pending = force
      ? scopes
      : scopes.filter((scope) => !loadedScopes.current.has(scope));
    if (!pending.length) return;
    setLoading(true);
    try {
      const next = await fetchStore(pending);
      setData((current) => ({ ...current, ...next }));
      pending.forEach((scope) => loadedScopes.current.add(scope));
    } catch (error) {
      setToast(
        error instanceof Error ? error.message : "Không thể tải dữ liệu",
      );
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    void loadScopes(scopesFor(active));
  }, [active, loadScopes]);
  const reload = useCallback(
    () => loadScopes(scopesFor(active), true),
    [active, loadScopes],
  );
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(""), 5000);
    return () => clearTimeout(timer);
  }, [toast]);
  const products = useMemo(
    () =>
      data.products.filter((x) =>
        (x.name + x.sku + x.category + x.brand)
          .toLowerCase()
          .includes(query.toLowerCase()),
      ),
    [data.products, query],
  );
  const add = (product: Product) =>
    setCart((current) => {
      const row = current.find((x) => x.id === product.id);
      return row
        ? current.map((x) =>
            x.id === product.id
              ? { ...x, qty: Math.min(x.qty + 1, x.stock) }
              : x,
          )
        : product.stock
          ? [
              ...current,
              {
                ...product,
                qty: 1,
                selectedSerials: [],
                unitPrice: product.price,
                lineDiscount: 0,
                lineNote: "",
              },
            ]
          : current;
    });
  const api = async (
    body: Record<string, unknown>,
    url = "/api/actions",
    method = "POST",
  ) => {
    const response = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const result = (await response.json()) as Record<string, unknown>;
    if (!response.ok)
      throw new Error(String(result.error || "Không thể thực hiện thao tác"));
    // A write may affect several related views (stock, debt, cashbook, reports).
    // Mark cached scopes stale so the next view always reloads authoritative data.
    loadedScopes.current.clear();
    return result;
  };
  const props: ViewProps = {
    data,
    products,
    cart,
    setCart,
    add,
    setActive,
    notify: setToast,
    reload,
    api,
    productDraft,
    openProductForm: (name = "") => {
      setProductDraft(name);
      setActive("Sản phẩm");
    },
    clearProductDraft: () => setProductDraft(null),
    documentToOpen,
    consumeDocumentToOpen: () => setDocumentToOpen(null),
    openDocument: (type, id) => {
      setDocumentToOpen({ type, id });
      setActive(type === "order" ? "Đơn hàng" : "Nhập hàng");
    },
  };
  const low = data.products.filter((x) => x.stock <= x.min).length;
  return (
    <div className="app">
      <aside>
        <div className="brand">
          <b>TC</b>
          <strong>Tiến Computer</strong>
        </div>
        <nav>
          {navigation.map((section) => (
            <div className="nav-group" key={section.group}>
              <small>{section.group}</small>
              {section.items.map(([name, icon]) => (
                <button
                  key={name}
                  className={active === name ? "on" : ""}
                  onClick={() => setActive(name)}
                >
                  <i>{icon}</i>
                  <span>{name}</span>
                  {name === "Đơn hàng" &&
                    data.orders.filter((x) => x.status === "pending").length >
                      0 && (
                      <em>
                        {
                          data.orders.filter((x) => x.status === "pending")
                            .length
                        }
                      </em>
                    )}
                </button>
              ))}
            </div>
          ))}
        </nav>
        <div className="switch">
          <i>▣</i>
          <span>
            <b>{data.settings.storeName}</b>
            <small>Một cửa hàng · Đang đồng bộ</small>
          </span>
          <span>⌄</span>
        </div>
      </aside>
      <main className={active === "Bán hàng" ? "sales-main" : ""}>
        <header>
          <div>
            <h1>
              {active === "Tổng quan"
                ? "Chào buổi sáng, anh Tiến"
                : active === "Đơn hàng"
                  ? "Danh sách đơn hàng"
                  : active}
            </h1>
            <p>
              {new Intl.DateTimeFormat("vi-VN", {
                weekday: "long",
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
              }).format(new Date())}
            </p>
          </div>
          <div className="head-actions">
            <label className="search">
              ⌕
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Tìm sản phẩm, SKU..."
              />
            </label>
            <button
              className="bell"
              title={`${low} sản phẩm sắp hết`}
              onClick={() => setActive("Kho & serial")}
            >
              ♧{low > 0 && <em>{low}</em>}
            </button>
            <span className="avatar">T</span>
            <span>Anh Tiến</span>
          </div>
        </header>
        <section
          className={`content${active === "Bán hàng" ? " sales-content" : ""}`}
        >
          {loading && (
            <div className="loading">Đang đồng bộ dữ liệu cửa hàng…</div>
          )}
          {toast && (
            <div className="toast">
              {toast}
              <button onClick={() => setToast("")}>×</button>
            </div>
          )}
          <Suspense fallback={<div className="loading">Đang mở màn hình…</div>}>
            <View active={active} props={props} />
          </Suspense>
        </section>
      </main>
    </div>
  );
}

function View({ active, props }: { active: string; props: ViewProps }) {
  switch (active) {
    case "Tổng quan":
      return <Dashboard {...props} />;
    case "Bán hàng":
      return <POS {...props} />;
    case "Sản phẩm":
      return <Products {...props} />;
    case "Nhập hàng":
      return <Purchases {...props} />;
    case "Kho & serial":
      return <Inventory {...props} />;
    case "Đơn hàng":
      return <Orders {...props} />;
    case "Đổi trả":
      return <Returns {...props} />;
    case "Bảo hành":
      return <Warranties {...props} />;
    case "Khách hàng":
      return <Customers {...props} />;
    case "Nhà cung cấp":
      return <Suppliers {...props} />;
    case "Công nợ":
      return <Debts {...props} />;
    case "Thu chi":
      return <Cash {...props} />;
    case "Báo cáo":
      return <Reports {...props} />;
    case "Cửa hàng online":
      return <OnlineStore {...props} />;
    case "Quản trị":
      return <SettingsView {...props} />;
    default:
      return <SettingsView {...props} />;
  }
}
