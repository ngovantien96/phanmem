import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Tiến Computer | Quản lý bán hàng",
  description: "Quản lý bán hàng, kho serial và đơn hàng.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="vi">
      <body>{children}</body>
    </html>
  );
}
