import { getD1 } from "../../../db/runtime";

type OptionType = "category" | "brand";

export async function POST(request: Request) {
  try {
    const db = getD1();
    const body = (await request.json()) as { type?: OptionType; name?: string };
    const type = body.type;
    const name = body.name?.trim().replace(/\s+/g, " ") ?? "";
    if ((type !== "category" && type !== "brand") || !name) {
      return Response.json(
        { error: "Vui lòng nhập tên tùy chọn hợp lệ." },
        { status: 400 },
      );
    }
    if (name.length > 80) {
      return Response.json(
        { error: "Tên tùy chọn không được vượt quá 80 ký tự." },
        { status: 400 },
      );
    }

    const existing = await db
      .prepare(
        "SELECT id, type, name FROM product_options WHERE type = ? AND name = ? COLLATE NOCASE",
      )
      .bind(type, name)
      .first<{ id: number; type: OptionType; name: string }>();
    if (existing) {
      return Response.json({ option: existing, created: false });
    }

    await db
      .prepare("INSERT INTO product_options (type, name) VALUES (?, ?)")
      .bind(type, name)
      .run();
    const option = await db
      .prepare(
        "SELECT id, type, name FROM product_options WHERE type = ? AND name = ? COLLATE NOCASE",
      )
      .bind(type, name)
      .first<{ id: number; type: OptionType; name: string }>();
    return Response.json({ option, created: true }, { status: 201 });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Không thể thêm tùy chọn";
    return Response.json({ error: message }, { status: 500 });
  }
}
