import { getProductImages } from "../../../db/runtime";

const MAX_IMAGE_SIZE = 5 * 1024 * 1024;
const allowedTypes = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);

const validKey = (value: string) =>
  value.startsWith("product-images/") &&
  !value.includes("..") &&
  /^[a-zA-Z0-9/_-]+\.(?:jpe?g|png|webp|gif)$/.test(value);

const extensionFor = (contentType: string) =>
  ({ "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/gif": "gif" })[contentType] || "jpg";

export async function GET(request: Request) {
  const key = new URL(request.url).searchParams.get("key") || "";
  if (!validKey(key)) return new Response("Không tìm thấy ảnh.", { status: 404 });
  const object = await getProductImages().get(key);
  if (!object) return new Response("Không tìm thấy ảnh.", { status: 404 });
  return new Response(new Uint8Array(object.body), {
    headers: {
      "Content-Type": object.httpMetadata?.contentType || "application/octet-stream",
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  });
}

export async function POST(request: Request) {
  try {
    const form = await request.formData();
    const image = form.get("image");
    if (!(image instanceof File)) {
      return Response.json({ error: "Chưa chọn ảnh sản phẩm." }, { status: 400 });
    }
    if (!allowedTypes.has(image.type)) {
      return Response.json({ error: "Chỉ hỗ trợ ảnh JPG, PNG, WEBP hoặc GIF." }, { status: 400 });
    }
    if (!image.size || image.size > MAX_IMAGE_SIZE) {
      return Response.json({ error: "Ảnh tối đa 5 MB." }, { status: 400 });
    }
    const key = `product-images/${crypto.randomUUID()}.${extensionFor(image.type)}`;
    await getProductImages().put(key, await image.arrayBuffer(), {
      httpMetadata: { contentType: image.type, cacheControl: "public, max-age=31536000, immutable" },
    });
    return Response.json({ key }, { status: 201 });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Không thể tải ảnh lên." }, { status: 500 });
  }
}
