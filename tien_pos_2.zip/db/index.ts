import { drizzle } from "drizzle-orm/better-sqlite3";
import * as schema from "./schema";
import { getSQLite } from "./runtime";

export function getDb() {
  return drizzle(getSQLite(), { schema });
}
