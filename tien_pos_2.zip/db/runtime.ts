import Database from "better-sqlite3";
import { existsSync, mkdirSync, promises as fs } from "node:fs";
import { dirname, extname, relative, resolve } from "node:path";

/** Compatibility layer that lets the existing D1 route handlers use local SQLite. */
export class SQLiteStatement {
  private values: unknown[] = [];

  constructor(
    private readonly database: Database.Database,
    private readonly query: string,
  ) {}

  bind(...values: unknown[]) {
    this.values = values;
    return this;
  }

  async all<T = Record<string, unknown>>(): Promise<{ results: T[] }> {
    return { results: this.database.prepare(this.query).all(...this.values) as T[] };
  }

  async first<T = Record<string, unknown>>(): Promise<T | null> {
    return (this.database.prepare(this.query).get(...this.values) as T | undefined) ?? null;
  }

  async run(): Promise<{ success: true; meta: { changes: number; last_row_id: number | bigint } }> {
    const result = this.database.prepare(this.query).run(...this.values);
    return { success: true, meta: { changes: result.changes, last_row_id: result.lastInsertRowid } };
  }

  execute() {
    return this.database.prepare(this.query).run(...this.values);
  }
}

export class SQLiteD1Compat {
  constructor(private readonly database: Database.Database) {}

  prepare(query: string) {
    return new SQLiteStatement(this.database, query);
  }

  async batch(statements: SQLiteStatement[]) {
    const run = this.database.transaction((items: SQLiteStatement[]) =>
      items.map((statement) => statement.execute()),
    );
    return run(statements);
  }
}

let connection: Database.Database | undefined;

export function databasePath() {
  return resolve(process.env.DATABASE_PATH || "./data/sales.db");
}

export function getSQLite() {
  if (!connection) {
    const path = databasePath();
    if (!existsSync(dirname(path))) mkdirSync(dirname(path), { recursive: true });
    connection = new Database(path);
    connection.pragma("journal_mode = WAL");
    connection.pragma("foreign_keys = ON");
    connection.pragma("busy_timeout = 5000");
  }
  return connection;
}

export function getD1() {
  return new SQLiteD1Compat(getSQLite());
}

const imageMimeTypes: Record<string, string> = {
  ".gif": "image/gif",
  ".jpeg": "image/jpeg",
  ".jpg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
};

function imageRoot() {
  return resolve(process.env.PRODUCT_IMAGE_DIR || "./data/product-images");
}

function imagePath(key: string) {
  const root = imageRoot();
  const candidate = resolve(root, key.replace(/^product-images\//, ""));
  if (relative(root, candidate).startsWith("..")) throw new Error("Đường dẫn ảnh không hợp lệ.");
  return candidate;
}

/** Local replacement for the small R2 surface used by product images. */
export function getProductImages() {
  return {
    async get(key: string) {
      try {
        const body = await fs.readFile(imagePath(key));
        return { body, httpMetadata: { contentType: imageMimeTypes[extname(key).toLowerCase()] } };
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code === "ENOENT") return null;
        throw error;
      }
    },
    async put(
      key: string,
      data: ArrayBuffer,
      options: { httpMetadata?: { contentType?: string; cacheControl?: string } } = {},
    ) {
      const path = imagePath(key);
      await fs.mkdir(dirname(path), { recursive: true });
      await fs.writeFile(path, Buffer.from(data));
      return options;
    },
    async delete(key: string) {
      try {
        await fs.unlink(imagePath(key));
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
      }
    },
  };
}
