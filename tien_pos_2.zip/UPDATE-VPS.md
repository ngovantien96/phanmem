# Cập nhật Tiến Computer POS trên VPS

Bản này chạy bằng Next.js + SQLite cục bộ. Database và ảnh sản phẩm đều nằm trong thư mục `data/`:

- `data/sales.db`: dữ liệu bán hàng.
- `data/product-images/`: ảnh sản phẩm.

Khi cập nhật source, phải giữ nguyên hai mục trên và file `.env` hiện tại. Chạy script cập nhật đã tạo trên VPS:

```bash
sudo cp /duong-dan/tien-computer-pos-sqlite-vps-1.1.zip /tmp/tien-pos-update.zip
sudo /usr/local/bin/update-tien-pos.sh
```

Script sẽ cài package mới, chạy migration SQLite và build lại ứng dụng. Migration `0011` và `0012` chỉ bổ sung cột/cấu hình mới, không xóa dữ liệu cũ.

Nếu script cập nhật cũ chưa giữ thư mục ảnh, thêm dòng này bên cạnh `--exclude 'data/'`:

```bash
--exclude 'data/' \
```

Vì toàn bộ `data/` đã được loại trừ, cả database và ảnh cũ đều được giữ nguyên.
