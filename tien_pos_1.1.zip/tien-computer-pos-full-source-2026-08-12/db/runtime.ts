declare global {
  // The worker entry assigns the request-scoped D1 binding before Vinext handles a route.
  var __TIEN_COMPUTER_DB__: D1Database | undefined;
  // The worker entry assigns the request-scoped bucket before Vinext handles a route.
  var __TIEN_COMPUTER_BUCKET__: R2Bucket | undefined;
}

export function getProductImages(): R2Bucket {
  const bucket = globalThis.__TIEN_COMPUTER_BUCKET__;
  if (!bucket) throw new Error("Kho ảnh chưa sẵn sàng. Vui lòng thử tải lại trang.");
  return bucket;
}

export function getD1(): D1Database {
  const db = globalThis.__TIEN_COMPUTER_DB__;
  if (!db) throw new Error("Kho dữ liệu chưa sẵn sàng. Vui lòng thử tải lại trang.");
  return db;
}
