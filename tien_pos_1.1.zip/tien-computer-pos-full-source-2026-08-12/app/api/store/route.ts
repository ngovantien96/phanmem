import { getD1 } from "../../../db/runtime";

const sampleProducts = [
  [
    "LT-ASUS-X1504",
    "ASUS Vivobook 15 X1504VA",
    "Laptop",
    "serial",
    13200000,
    15490000,
    2,
    2,
  ],
  [
    "LT-DELL-5430",
    "Dell Inspiron 14 5430",
    "Laptop",
    "serial",
    16100000,
    18999000,
    2,
    2,
  ],
  [
    "LT-LNV-15IAH8",
    "Lenovo IdeaPad Slim 3 15IAH8",
    "Laptop",
    "serial",
    11200000,
    13490000,
    1,
    2,
  ],
  [
    "LT-ACER-A315",
    "Acer Aspire 3 A315-58",
    "Laptop",
    "serial",
    9800000,
    11990000,
    1,
    2,
  ],
  ["LT-HP-240G10", "HP 240 G10", "Laptop", "serial", 8700000, 10490000, 1, 2],
  [
    "PK-MOUSE-M185",
    "Chuột không dây Logitech M185",
    "Phụ kiện",
    "quantity",
    190000,
    290000,
    18,
    5,
  ],
  [
    "LK-RAM-8D4",
    "RAM laptop DDR4 8GB 3200MHz",
    "Linh kiện",
    "quantity",
    390000,
    590000,
    9,
    3,
  ],
  [
    "PK-BALO-TC15",
    "Balo laptop chống sốc 15.6 inch",
    "Phụ kiện",
    "quantity",
    210000,
    350000,
    12,
    4,
  ],
] as const;

async function seedIfNeeded() {
  const db = getD1();
  await db
    .prepare(
      "INSERT OR IGNORE INTO store_settings (id, store_name, receipt_footer) VALUES (1, 'Tiến Computer', 'Cảm ơn quý khách đã mua hàng!')",
    )
    .run();
  const row = await db
    .prepare("SELECT COUNT(*) AS total FROM products")
    .first<{ total: number }>();
  if ((row?.total ?? 0) > 0) return;

  const inserts = sampleProducts.map((product) =>
    db
      .prepare(
        "INSERT INTO products (sku, name, category, tracking, cost, price, stock, min_stock) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
      )
      .bind(...product),
  );
  await db.batch(inserts);

  const laptops = await db
    .prepare("SELECT id, sku, stock FROM products WHERE tracking = 'serial'")
    .all<{ id: number; sku: string; stock: number }>();
  const serialInserts = laptops.results.flatMap((product) =>
    Array.from({ length: product.stock }, (_, index) =>
      db
        .prepare("INSERT INTO serials (product_id, serial) VALUES (?, ?)")
        .bind(
          product.id,
          `${product.sku.replaceAll("-", "")}-${String(index + 1).padStart(4, "0")}`,
        ),
    ),
  );
  if (serialInserts.length) await db.batch(serialInserts);
}

const scopes = [
  "products",
  "productOptions",
  "orders",
  "orderItems",
  "customers",
  "serials",
  "cashTransactions",
  "suppliers",
  "purchases",
  "inventoryMovements",
  "returns",
  "warranties",
  "debts",
  "settings",
] as const;

type Scope = (typeof scopes)[number];

export async function GET(request: Request) {
  try {
    const requestedParam = new URL(request.url).searchParams.get("scope");
    const requested = new Set<Scope>(
      requestedParam
        ? requestedParam
            .split(",")
            .filter((value): value is Scope => scopes.includes(value as Scope))
        : scopes,
    );

    if (requested.has("products") || requested.has("settings")) {
      await seedIfNeeded();
    }
    const db = getD1();
    const result: Record<string, unknown> = {};
    const queries: Promise<void>[] = [];
    const list = (scope: Scope, sql: string) => {
      if (!requested.has(scope)) return;
      queries.push(
        db
          .prepare(sql)
          .all()
          .then((rows) => {
            result[scope] = rows.results;
          }),
      );
    };

    list(
      "products",
      "SELECT id, sku, name, category, brand, image_key AS imageKey, description, unit, warranty_months AS warrantyMonths, tracking, cost, price, stock, min_stock AS min, active, created_at AS createdAt FROM products WHERE active = 1 ORDER BY created_at DESC, id DESC",
    );
    list(
      "productOptions",
      "SELECT id, type, name FROM product_options ORDER BY type, name COLLATE NOCASE",
    );
    list(
      "orders",
      "SELECT id, code, customer_id AS customerId, customer_name AS customerName, subtotal, discount, total, paid, refunded, payment_method AS paymentMethod, status, channel, shipping_address AS shippingAddress, note, cancellation_reason AS cancellationReason, cancelled_at AS cancelledAt, created_at AS createdAt FROM orders ORDER BY created_at DESC LIMIT 200",
    );
    list(
      "orderItems",
      "SELECT id, order_id AS orderId, product_id AS productId, product_name AS productName, sku, quantity, unit_price AS unitPrice, unit_cost AS unitCost, discount, note, serials_json AS serialsJson FROM order_items ORDER BY id DESC LIMIT 500",
    );
    list(
      "customers",
      "SELECT id, name, phone, email, address, created_at AS createdAt FROM customers ORDER BY created_at DESC LIMIT 100",
    );
    list(
      "serials",
      "SELECT s.id, s.product_id AS productId, s.serial, s.status, s.order_id AS orderId, p.name AS productName, p.sku FROM serials s JOIN products p ON p.id = s.product_id ORDER BY s.id DESC LIMIT 200",
    );
    list(
      "cashTransactions",
      "SELECT id, type, category, note, amount, expected_amount AS expectedAmount, payment_method AS paymentMethod, status, partner_type AS partnerType, partner_name AS partnerName, reference, source_type AS sourceType, source_id AS sourceId, settled_at AS settledAt, order_id AS orderId, created_at AS createdAt FROM cash_transactions ORDER BY created_at DESC LIMIT 100",
    );
    list(
      "suppliers",
      "SELECT id, code, name, phone, email, address, created_at AS createdAt FROM suppliers ORDER BY created_at DESC LIMIT 100",
    );
    list(
      "purchases",
      `SELECT p.id, p.code, p.supplier_id AS supplierId,
        p.supplier_name AS supplierName, p.total,
        CASE
          WHEN p.status = 'purchase_returned' THEN p.returned_amount
          ELSE COALESCE((
            SELECT SUM(ct.amount)
            FROM cash_transactions ct
            WHERE ct.type = 'expense' AND (
              (ct.category = 'Nhập hàng' AND ct.note = 'Thanh toán phiếu ' || p.code)
              OR (ct.category = 'Công nợ' AND ct.note = 'Thanh toán ' || p.code)
            )
          ), p.paid)
        END AS paid,
        p.status, p.note,
        COALESCE(p.received_at, p.created_at) AS receivedAt,
        p.returned_amount AS returnedAmount,
        p.return_reason AS returnReason,
        p.returned_at AS returnedAt,
        p.created_at AS createdAt
      FROM purchases p
      ORDER BY COALESCE(p.received_at, p.created_at) DESC, p.created_at DESC
      LIMIT 100`,
    );
    list(
      "inventoryMovements",
      "SELECT id, product_id AS productId, product_name AS productName, type, quantity, reference, note, created_at AS createdAt FROM inventory_movements ORDER BY created_at DESC LIMIT 300",
    );
    list(
      "returns",
      "SELECT id, code, order_id AS orderId, order_code AS orderCode, customer_name AS customerName, amount, reason, items_json AS itemsJson, status, created_at AS createdAt FROM returns ORDER BY created_at DESC LIMIT 100",
    );
    list(
      "warranties",
      "SELECT id, code, customer_name AS customerName, phone, product_name AS productName, serial, issue, status, expected_at AS expectedAt, note, created_at AS createdAt, updated_at AS updatedAt FROM warranties ORDER BY updated_at DESC LIMIT 100",
    );
    list(
      "debts",
      "SELECT id, partner_type AS partnerType, partner_name AS partnerName, reference, total, paid, due_date AS dueDate, status, settlement_type AS settlementType, source_transaction_id AS sourceTransactionId, created_at AS createdAt FROM debts ORDER BY created_at DESC LIMIT 100",
    );

    if (requested.has("settings")) {
      queries.push(
        db
        .prepare(
          "SELECT id, store_name AS storeName, phone, address, tax_code AS taxCode, receipt_footer AS receiptFooter, print_title AS printTitle, print_regulations AS printRegulations, print_customer_signer AS printCustomerSigner, print_sales_signer AS printSalesSigner, print_accountant_signer AS printAccountantSigner, print_footer AS printFooter, allow_negative_stock AS allowNegativeStock, auto_print AS autoPrint, low_stock_alert AS lowStockAlert, updated_at AS updatedAt FROM store_settings WHERE id = 1",
        )
          .first()
          .then((row) => {
            result.settings = row;
          }),
      );
    }

    await Promise.all(queries);
    return Response.json(result);
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Không thể tải dữ liệu cửa hàng";
    return Response.json({ error: message }, { status: 500 });
  }
}
