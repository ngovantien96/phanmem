"use client";
import React, { useEffect, useRef, useState } from "react";
import { formatDate, money, Order } from "./types";

export function ProductImage({
  imageKey,
  alt,
  className = "",
  fallback = "▧",
}: {
  imageKey?: string;
  alt: string;
  className?: string;
  fallback?: string;
}) {
  const [failed, setFailed] = useState(false);
  const source = imageKey && !failed
    ? `/api/product-image?key=${encodeURIComponent(imageKey)}`
    : "";
  return (
    <span className={`product-image ${className}`.trim()} aria-hidden={!source}>
      {source ? <img src={source} alt={alt} onError={() => setFailed(true)} /> : fallback}
    </span>
  );
}

export function Modal({
  title,
  onClose,
  children,
  wide = false,
  className = "",
}: {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  wide?: boolean;
  className?: string;
}) {
  return (
    <div
      className="modal-backdrop"
      onMouseDown={(e) => {
        if (e.currentTarget === e.target) onClose();
      }}
    >
      <section
        className={`modal ${wide ? "modal-wide" : ""} ${className}`.trim()}
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <div className="modal-head">
          <h2>{title}</h2>
          <button aria-label="Đóng" onClick={onClose}>
            ×
          </button>
        </div>
        <div className="modal-body">{children}</div>
      </section>
    </div>
  );
}
export function Kpi({
  icon,
  label,
  value,
  tone = "blue",
  hint,
}: {
  icon: string;
  label: string;
  value: string;
  tone?: string;
  hint?: string;
}) {
  return (
    <article className="kpi">
      <i className={tone}>{icon}</i>
      <span>
        <p>{label}</p>
        <b>{value}</b>
        {hint && <small>{hint}</small>}
      </span>
    </article>
  );
}
export function PanelTitle({
  text,
  sub,
  action,
  onAction,
}: {
  text: string;
  sub?: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <div className="section-title">
      <div>
        <h2>{text}</h2>
        {sub && <p>{sub}</p>}
      </div>
      {action && <button onClick={onAction}>{action}</button>}
    </div>
  );
}
export function Status({ value }: { value: string }) {
  const good = ["completed", "available", "sold", "paid", "returned"].includes(
    value,
  );
  const bad = ["cancelled", "unpaid", "open", "purchase_returned"].includes(
    value,
  );
  return (
    <span
      className={`status ${good ? "ok" : bad ? "danger" : ["pending", "partial", "waiting"].includes(value) ? "warn" : "info"}`}
    >
      {(
        {
          completed: "Hoàn thành",
          processing: "Đang xử lý",
          pending: "Chờ xác nhận",
          cancelled: "Đã hủy",
          available: "Sẵn sàng",
          sold: "Đã bán",
          warranty: "Bảo hành",
          received: "Đã tiếp nhận",
          waiting: "Chờ linh kiện",
          returned: "Đã trả khách",
          purchase_returned: "Đã hoàn trả",
          partial: "Một phần",
          deferred: "Đã chuyển công nợ",
          unpaid: "Chưa trả",
          open: "Còn nợ",
          paid: "Đã trả",
        } as Record<string, string>
      )[value] || value}
    </span>
  );
}
export function OrderTable({
  orders,
  onOpen,
}: {
  orders: Order[];
  onOpen?: (order: Order) => void;
}) {
  return (
    <div className="table">
      <table>
        <thead>
          <tr>
            <th>Mã đơn</th>
            <th>Khách hàng</th>
            <th>Kênh</th>
            <th>Tổng tiền</th>
            <th>Đã trả</th>
            <th>Thời gian</th>
            <th>Trạng thái</th>
          </tr>
        </thead>
        <tbody>
          {orders.length ? (
            orders.map((o) => (
              <tr
                key={o.id}
                className={onOpen ? "clickable" : ""}
                onClick={() => onOpen?.(o)}
              >
                <td className="link">{o.code}</td>
                <td>{o.customerName}</td>
                <td>{o.channel === "pos" ? "Tại quầy" : "Online"}</td>
                <td>{money(o.total)}</td>
                <td>{money(o.paid)}</td>
                <td>{formatDate(o.createdAt)}</td>
                <td>
                  <Status value={o.status} />
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={7}>
                <div className="mini-empty">Chưa có dữ liệu</div>
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
export function Field({
  label,
  children,
  wide = false,
}: {
  label: string;
  children: React.ReactNode;
  wide?: boolean;
}) {
  return (
    <label className={wide ? "wide" : ""}>
      {label}
      {children}
    </label>
  );
}

const formatMoneyInput = (value: number) =>
  Math.max(0, Math.round(Number.isFinite(value) ? value : 0)).toLocaleString(
    "en-US",
  );

export function MoneyInput({
  value,
  onValueChange,
  className = "",
  max,
  ariaLabel,
  autoFocus = false,
  placeholder,
  allowEmpty = false,
}: {
  value: number;
  onValueChange: (value: number) => void;
  className?: string;
  max?: number;
  ariaLabel: string;
  autoFocus?: boolean;
  placeholder?: string;
  allowEmpty?: boolean;
}) {
  const focused = useRef(false);
  const displayValue = (amount: number) =>
    allowEmpty && amount === 0 ? "" : formatMoneyInput(amount);
  const [draft, setDraft] = useState(() => displayValue(value));

  useEffect(() => {
    if (!focused.current) setDraft(displayValue(value));
  }, [value, allowEmpty]);

  const normalizedMax =
    max === undefined ? Number.POSITIVE_INFINITY : Math.max(0, max);

  return (
    <input
      className={`money-input ${className}`.trim()}
      type="text"
      inputMode="numeric"
      autoComplete="off"
      autoFocus={autoFocus}
      placeholder={placeholder}
      value={draft}
      title={`${formatMoneyInput(value)}đ`}
      aria-label={ariaLabel}
      onFocus={(event) => {
        focused.current = true;
        event.currentTarget.select();
      }}
      onChange={(event) => {
        const digits = event.target.value.replace(/\D/g, "");
        if (!digits) {
          setDraft("");
          onValueChange(0);
          return;
        }
        const next = Math.min(normalizedMax, Number(digits));
        const safeValue = Number.isFinite(next) ? next : 0;
        setDraft(formatMoneyInput(safeValue));
        onValueChange(safeValue);
      }}
      onBlur={() => {
        focused.current = false;
        setDraft(displayValue(value));
      }}
    />
  );
}
export function Empty({ text }: { text: string }) {
  return <div className="mini-empty">{text}</div>;
}
export function SpinnerButton({
  busy,
  children,
  ...props
}: {
  busy?: boolean;
  children: React.ReactNode;
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button {...props} disabled={busy || props.disabled}>
      {busy ? "Đang lưu…" : children}
    </button>
  );
}
export function Chart({
  orders,
  period = "day",
}: {
  orders: Order[];
  period?: "day" | "month" | "year";
}) {
  const today = new Date();
  const buckets =
    period === "year"
      ? Array.from({ length: 12 }, (_, index) => {
          const date = new Date(today.getFullYear(), today.getMonth() - (11 - index), 1);
          return {
            label: `T${date.getMonth() + 1}`,
            matches: (value: Date) =>
              value.getFullYear() === date.getFullYear() && value.getMonth() === date.getMonth(),
          };
        })
      : Array.from({ length: period === "month" ? 30 : 7 }, (_, index, all) => {
          const date = new Date(today);
          date.setHours(0, 0, 0, 0);
          date.setDate(date.getDate() - (all.length - 1 - index));
          return {
            label: period === "month" ? `${date.getDate()}/${date.getMonth() + 1}` : ["CN", "Th 2", "Th 3", "Th 4", "Th 5", "Th 6", "Th 7"][date.getDay()],
            matches: (value: Date) => value.toDateString() === date.toDateString(),
          };
        });
  const values = buckets.map((bucket) =>
    orders
      .filter((order) => order.status !== "cancelled" && bucket.matches(new Date(order.createdAt)))
      .reduce((sum, order) => sum + order.total, 0),
  );
  const max = Math.max(...values, 1);
  return (
    <div className={`bar-chart bar-chart-${period}`}>
      {values.map((v, i) => (
        <div key={i}>
          <span
            style={{ height: `${Math.max(4, (v / max) * 100)}%` }}
            title={money(v)}
          ></span>
          <small>{buckets[i].label}</small>
        </div>
      ))}
    </div>
  );
}
